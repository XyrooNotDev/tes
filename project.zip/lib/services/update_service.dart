import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';

class UpdateInfo {
  final String latestVersion;
  final String currentVersion;
  final String downloadUrl;
  final String desk;
  final String publishedAt;
  final bool forceUpdate;

  UpdateInfo({
    required this.latestVersion,
    required this.currentVersion,
    required this.downloadUrl,
    required this.desk,
    required this.publishedAt,
    required this.forceUpdate,
  });

  bool get hasUpdate => _compareVersion(latestVersion, currentVersion) > 0;

  static int _compareVersion(String a, String b) {
    final va = a.replaceAll(RegExp(r'[^0-9.]'), '').split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final vb = b.replaceAll(RegExp(r'[^0-9.]'), '').split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final len = va.length > vb.length ? va.length : vb.length;
    for (var i = 0; i < len; i++) {
      final x = i < va.length ? va[i] : 0;
      final y = i < vb.length ? vb[i] : 0;
      if (x != y) return x.compareTo(y);
    }
    return 0;
  }
}

class UpdateService {
  static const String repoOwner = 'XyrooNotDev';
  static const String repoName = 'santanic-build-update';
  static const String branch = 'main';

  static String get _latestJsonUrl =>
      'https://raw.githubusercontent.com/$repoOwner/$repoName/$branch/latest.json';

  static const Duration _timeout = Duration(seconds: 20);

  static Future<UpdateInfo?> checkUpdate() async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      final currentVersion = packageInfo.version;

      final res = await http.get(Uri.parse(_latestJsonUrl)).timeout(_timeout);
      if (res.statusCode != 200) {
        debugPrint('Update: HTTP ${res.statusCode}');
        return null;
      }

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final latestVersion = (data['version'] as String? ?? '').replaceAll('v', '');
      final downloadUrl = data['downloadUrl'] as String? ?? '';
      final desk = data['desk'] as String? ?? '';
      final publishedAt = data['publishedAt'] as String? ?? '';
      final forceUpdate = data['forceUpdate'] as bool? ?? false;

      if (latestVersion.isEmpty || downloadUrl.isEmpty) return null;

      return UpdateInfo(
        latestVersion: latestVersion,
        currentVersion: currentVersion,
        downloadUrl: downloadUrl,
        desk: desk,
        publishedAt: publishedAt,
        forceUpdate: forceUpdate,
      );
    } catch (e) {
      debugPrint('Update check error: $e');
      return null;
    }
  }

  static Future<File> downloadApk({
    required String url,
    required void Function(int received, int total) onProgress,
  }) async {
    final dir = await getTemporaryDirectory();
    final filePath = '${dir.path}/santanic-update.apk';
    final existing = File(filePath);
    if (await existing.exists()) await existing.delete();
    final dio = Dio();
    await dio.download(url, filePath, onReceiveProgress: onProgress);
    return File(filePath);
  }

  static Future<void> installApk(File apk) async {
    await OpenFilex.open(apk.path);
  }
}