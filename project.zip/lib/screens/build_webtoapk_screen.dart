import 'package:flutter/material.dart';

import '../models/build_record.dart';
import '../nav.dart';
import '../services/build_controller.dart';
import '../services/github_actions.dart';
import '../services/github_api_exception.dart';
import '../services/github_uploader.dart';
import '../services/notification_service.dart';
import '../services/session_manager.dart';
import '../theme.dart';
import '../widgets/build_progress_view.dart';
import '../widgets/repo_selector.dart';

class BuildWebToApkScreen extends StatefulWidget {
  const BuildWebToApkScreen({super.key, required this.session, required this.controller});
  final SessionManager session;
  final BuildController controller;

  @override
  State<BuildWebToApkScreen> createState() => _BuildWebToApkScreenState();
}

class _BuildWebToApkScreenState extends State<BuildWebToApkScreen> {
  late final TextEditingController _owner = TextEditingController(text: widget.session.username);
  final _repo = TextEditingController();
  final _webUrl = TextEditingController();
  final _appName = TextEditingController();
  final _iconUrl = TextEditingController();
  String? _token;
  bool _busy = false;
  String _busyText = '';

  static const String _workflowName = 'web2apk.yml';
  static const String _assetPath = 'assets/workflows/web2apk.yml';

  @override
  void initState() {
    super.initState();
    _loadToken();
  }

  Future<void> _loadToken() async {
    final t = await widget.session.getToken();
    if (mounted) setState(() => _token = t);
  }

  @override
  void dispose() {
    _owner.dispose();
    _repo.dispose();
    _webUrl.dispose();
    _appName.dispose();
    _iconUrl.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), backgroundColor: kCard, behavior: SnackBarBehavior.floating));
  }

  Future<void> _start() async {
    final owner = _owner.text.trim();
    final repo = _repo.text.trim();
    final webUrl = _webUrl.text.trim();
    final appName = _appName.text.trim();
    final iconUrl = _iconUrl.text.trim();

    if ([owner, repo, webUrl, appName, iconUrl].any((e) => e.isEmpty)) {
      _snack('Lengkapi semua data!');
      return;
    }
    if (widget.controller.isRunning) {
      _snack('Masih ada build berjalan.');
      return;
    }

    setState(() { _busy = true; _busyText = 'Menyiapkan repository...'; });

    try {
      await NotificationService.requestPermission();
      final token = await widget.session.getToken();
      final uploader = GitHubUploader(token, owner, repo);

      final created = await uploader.ensureRepoExists();
      if (created && mounted) {
        setState(() => _busyText = 'Repo baru dibuat, menyiapkan workflow...');
      }

      if (mounted) setState(() => _busyText = 'Mengunggah workflow...');
      final branch = await uploader.uploadBuiltinWorkflowOnly(
        assetWorkflowPath: _assetPath,
        workflowName: _workflowName,
        commitMessage: 'Santanic Build: setup web2apk workflow',
      );

      if (mounted) setState(() => _busyText = 'Memicu workflow...');
      final actions = GitHubActions(token);
      var baseline = 0;
      try { baseline = await actions.latestRunId(owner, repo, _workflowName); } catch (_) {}

      await actions.triggerWorkflowWithInputs(
        owner, repo, _workflowName, branch,
        {'web_url': webUrl, 'app_name': appName, 'icon_url': iconUrl},
      );

      await widget.controller.begin(BuildRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: AppNav.buildWebToApk,
        owner: owner,
        repo: repo,
        workflow: _workflowName,
        startedAt: DateTime.now().millisecondsSinceEpoch,
        baselineRunId: baseline,
        step: 'Menunggu runner GitHub...',
      ));
      _snack('Build Web2APK dimulai!');
    } on GitHubApiException catch (e) {
      _snack('Gagal: ${e.message}');
    } catch (e) {
      _snack('Gagal: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(title: const Text('Build WebToAPK'), backgroundColor: kBg, foregroundColor: Colors.white, elevation: 0),
      body: ListenableBuilder(
        listenable: widget.controller,
        builder: (context, _) {
          final display = widget.controller.display;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (display != null) ...[
                BuildProgressView(controller: widget.controller),
                const SizedBox(height: 16),
              ],
              const Text('Username GitHub', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              TextField(
                controller: _owner,
                readOnly: true,
                decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), filled: true, fillColor: kInputBg),
              ),
              const SizedBox(height: 16),
              const Text('Repository', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              if (_token != null && _token!.isNotEmpty)
                RepoSelector(token: _token!, owner: _owner.text, onRepoChanged: (v) => _repo.text = v)
              else
                const Center(child: CircularProgressIndicator(color: kRed)),
              const SizedBox(height: 20),
              const Text('Detail Web', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              TextField(controller: _webUrl, decoration: const InputDecoration(labelText: 'URL Website', prefixIcon: Icon(Icons.language))),
              const SizedBox(height: 12),
              TextField(controller: _appName, decoration: const InputDecoration(labelText: 'Nama Aplikasi', prefixIcon: Icon(Icons.apps))),
              const SizedBox(height: 12),
              TextField(controller: _iconUrl, decoration: const InputDecoration(labelText: 'URL Icon (PNG)', prefixIcon: Icon(Icons.image_outlined))),
              const SizedBox(height: 24),
              FilledButton.icon(
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56), backgroundColor: kRed, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: _busy ? null : _start,
                icon: _busy
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.rocket_launch, size: 20),
                label: Text(_busy ? _busyText : 'Mulai Build', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ],
          );
        },
      ),
    );
  }
}