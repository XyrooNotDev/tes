import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// === Channel ID ===
const String kProgressChannelId = 'build_progress';
const String kDoneChannelId = 'build_done';
const String kErrorChannelId = 'build_error';
const String kUpdateChannelId = 'app_update';

// === Notif ID ===
const int kProgressNotifId = 888;
const int kDoneNotifId = 889;
const int kErrorNotifId = 890;
const int kUpdateNotifId = 891;

// === Payload ===
const String kPayloadBuildTab = 'tab:build';
const String kPayloadUpdateTab = 'app:update';

const String _kIcon = '@drawable/ic_stat_build';

final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

class NotificationService {
  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> init({DidReceiveNotificationResponseCallback? onTap}) async {
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings(_kIcon),
    );

    await notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: onTap,
    );

    // === Channel: Progress Build ===
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kProgressChannelId,
      'Progress Build',
      description: 'Progress build GitHub Actions yang sedang berjalan',
      importance: Importance.high,
      playSound: false,
      enableVibration: false,
      showBadge: false,
    ));

    // === Channel: Build Selesai ===
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kDoneChannelId,
      'Build Selesai',
      description: 'Pemberitahuan saat build selesai atau gagal',
      importance: Importance.high,
    ));

    // === Channel: Build Error ===
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kErrorChannelId,
      'Build Error',
      description: 'Pemberitahuan saat build gagal dimulai atau error',
      importance: Importance.high,
    ));

    // === Channel: Update Aplikasi ===
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kUpdateChannelId,
      'Update Aplikasi',
      description: 'Pemberitahuan jika ada versi baru Santanic Build',
      importance: Importance.high,
    ));

    await requestPermission();
  }

  static Future<void> requestPermission() async {
    await _android?.requestNotificationsPermission();
  }

  // ============================================
  // PROGRESS BUILD (ongoing)
  // ============================================
  static Future<void> showProgress({
    required String title,
    required String body,
    required int percent,
    required bool indeterminate,
  }) {
    return notifications.show(
      kProgressNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kProgressChannelId,
          'Progress Build',
          channelDescription: 'Progress build GitHub Actions yang sedang berjalan',
          importance: Importance.high,
          priority: Priority.high,
          ongoing: true,
          autoCancel: false,
          onlyAlertOnce: true,
          showProgress: true,
          maxProgress: 100,
          progress: percent,
          indeterminate: indeterminate,
          playSound: false,
          enableVibration: false,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          category: AndroidNotificationCategory.service,
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  static Future<void> cancelProgress() => notifications.cancel(kProgressNotifId);

  // ============================================
  // BUILD SELESAI (sukses/gagal)
  // ============================================
  static Future<void> showDone({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kDoneNotifId,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          kDoneChannelId,
          'Build Selesai',
          channelDescription: 'Pemberitahuan saat build selesai atau gagal',
          importance: Importance.high,
          priority: Priority.high,
          autoCancel: true,
          icon: _kIcon,
          color: Color(0xFFFF0000),
          category: AndroidNotificationCategory.status,
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  // ============================================
  // BUILD ERROR (gagal dimulai / timeout)
  // ============================================
  static Future<void> showError({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kErrorNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kErrorChannelId,
          'Build Error',
          channelDescription: 'Pemberitahuan saat build gagal dimulai atau error',
          importance: Importance.high,
          priority: Priority.high,
          autoCancel: true,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          category: AndroidNotificationCategory.error,
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  static Future<void> cancelError() => notifications.cancel(kErrorNotifId);

  // ============================================
  // UPDATE APLIKASI (versi baru)
  // ============================================
  static Future<void> showUpdateAvailable({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kUpdateNotifId,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          kUpdateChannelId,
          'Update Aplikasi',
          channelDescription: 'Pemberitahuan jika ada versi baru Santanic Build',
          importance: Importance.high,
          priority: Priority.high,
          autoCancel: true,
          icon: _kIcon,
          color: Color(0xFF00E676),
          category: AndroidNotificationCategory.recommendation,
        ),
      ),
      payload: kPayloadUpdateTab,
    );
  }

  static Future<void> cancelUpdate() => notifications.cancel(kUpdateNotifId);

  // ============================================
  // CEK LAUNCH DARI NOTIFIKASI
  // ============================================
  static Future<bool> isLaunchedFromBuildNotif() async {
    final details = await notifications.getNotificationAppLaunchDetails();
    return (details?.didNotificationLaunchApp ?? false) &&
        details?.notificationResponse?.payload == kPayloadBuildTab;
  }

  static Future<bool> isLaunchedFromUpdateNotif() async {
    final details = await notifications.getNotificationAppLaunchDetails();
    return (details?.didNotificationLaunchApp ?? false) &&
        details?.notificationResponse?.payload == kPayloadUpdateTab;
  }
}