# Santanic Build

Aplikasi Android untuk memicu build APK menggunakan GitHub Actions.

## Alur penggunaan
1. Login GitHub dari aplikasi. Browser dibuka otomatis ke URL verifikasi lengkap GitHub (jika didukung oleh OAuth Device Flow), sehingga kode verifikasi tidak perlu diketik manual.
2. Masukkan owner dan nama repository yang sudah memiliki GitHub Actions aktif.
3. Pilih ZIP project dan opsional file `.yml` workflow kustom.
4. Aplikasi mengirim file ZIP sebagai satu file input `source.zip`, bukan mengekstrak lalu mengunggah seluruh file source satu per satu. File workflow `.yml` ditempatkan di `.github/workflows/`.
5. GitHub Actions menjalankan build dan menyimpan APK sebagai artifact.

## Batasan arsitektur
- Tidak menggunakan backend milik aplikasi.
- GitHub Actions hanya dapat menjalankan workflow yang tersimpan di repository. Karena itu repository dan workflow `.yml` tetap diperlukan.
- File ZIP input tetap perlu tersedia bagi runner GitHub Actions. Pada implementasi ini ZIP disimpan sebagai file `source.zip` di repository. Jika source ZIP sama sekali tidak boleh disimpan di repository, diperlukan penyimpanan eksternal (misalnya object storage) dan kredensial aksesnya.
- Login GitHub tetap membutuhkan persetujuan pengguna. GitHub Device Flow dapat membuka halaman verifikasi lengkap secara otomatis, tetapi aplikasi tidak dapat melewati persetujuan OAuth.
- Riwayat disimpan lokal di perangkat dan tidak dibatasi 50 entri. Menghapus data aplikasi akan menghapus riwayat lokal.

## Profil
Developer: Xyroo  
Support: Yoga, Suika, Yanz, Fahmi


## Perbaikan kompatibilitas Android

- Menambahkan `MainActivity.kt` sesuai namespace `com.santanic.build`.
- Melengkapi Gradle Wrapper (`gradlew`, `gradlew.bat`, dan wrapper JAR).
- Menambahkan aset foreground launcher yang sebelumnya direferensikan tetapi belum ada.
- Menjadikan inisialisasi notifikasi dan background service tidak memblokir startup UI jika plugin gagal diinisialisasi.
- Menyinkronkan token ke SharedPreferences agar background isolate dapat membaca token build; secure storage tetap menjadi penyimpanan utama.
- Workflow CI tidak menjalankan dua jenis build sekaligus untuk satu project Flutter.

Catatan: arsip telah diperbaiki secara statis. Build Flutter/Android dan uji buka aplikasi di perangkat belum dapat dijalankan di lingkungan ini karena Flutter SDK dan Android SDK tidak tersedia. Token GitHub PAT tidak disertakan dalam arsip; masukkan melalui mekanisme rahasia yang aman, jangan hardcode ke source code.


## Update v1.2.0

- Tab **Progress** baru: detail penuh build (info run, semua job & step + durasi, log terbaru, diagnosis). Notifikasi membuka tab ini.
- **Download APK langsung dari aplikasi**: artifact GitHub diunduh (pakai token), APK diekstrak, lalu tombol *Install APK* / *Simpan ke folder Download*. Setelah build sukses, unduhan berjalan otomatis di latar belakang.
- Build & pelacakan berjalan di **latar belakang** (foreground service dataSync) dan kompatibel Android 12 sampai 15 (izin notifikasi, install APK, pengecualian baterai, tanpa auto-start saat boot).
- Tombol **Upload .yml** di build Android Studio & Flutter (tidak untuk WebToAPK). Tanpa upload, otomatis memakai workflow bawaan di `assets/workflows/`.
- Perbaikan bug: file workflow sebelumnya tidak ikut ter-upload ke repo, upload file dobel, tab notifikasi salah arah, status "dibatalkan" tercatat sebagai gagal, persen progress bisa turun.
- Workflow bawaan kini menandatangani APK dengan debug key jika belum bertanda tangan (mencegah "paket tidak valid").

## Update v1.2.1

- Perbaikan crash tab Progress: parsing data detail dibuat defensif, error tampilan dicatat dan ditampilkan sebagai *Laporan error* (bisa disalin), service latar belakang tidak lagi dimulai saat app di background (larangan Android 12+).
- **Progress upload terpisah**: kartu *Mengunggah ke GitHub* (izin, repo, project.zip dengan persen & MB, workflow, tunggu workflow, picu build) terpisah dari kartu progress build.
- **Status Build global**: menampilkan semua pengguna Santanic Build (nama GitHub + berhasil / gagal / antrian / berjalan). Hanya repo publik (dan repo milik akun sendiri) yang terhitung.
- Kontak memakai ikon GitHub / WhatsApp / Telegram yang langsung membuka tautannya.
- Ukuran APK: workflow `build.yml` kini membuat APK per-ABI (`app-arm64-v8a` dan `app-armeabi-v7a`), tanpa `--no-shrink`, logo dikecilkan. Pakai `arm64-v8a` untuk hampir semua HP Android 12+.

## Update v1.2.2 (perbaikan force close saat build berjalan)

- Penyusutan resource (`shrinkResources`) dimatikan dan ditambah `res/raw/keep.xml`: ikon notifikasi `ic_stat_build` dirujuk lewat nama dari Dart sehingga bisa terbuang di build release, lalu notifikasi / foreground service membuat aplikasi crash.
- Aturan R8 untuk Gson (`TypeToken`) ditambahkan agar plugin notifikasi tidak crash di build release.
- **Pencatat crash native**: crash/force close (termasuk dari foreground service) disimpan lalu tampil sebagai *Laporan error* di tab Progress (bisa disalin).
- **Mode aman**: sakelar *Pelacak build di latar belakang* di tab Profil. Jika dimatikan (atau otomatis dimatikan setelah crash service terdeteksi), build dipantau di dalam aplikasi tanpa foreground service.
