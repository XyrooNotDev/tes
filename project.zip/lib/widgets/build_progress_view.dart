import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/build_record.dart';
import '../services/build_controller.dart';
import '../theme.dart';

Color statusColor(BuildRecord r) {
  if (!r.isFinished) return const Color(0xFFFFC107);
  return r.isSuccess ? kGreen : kRed;
}

class BuildProgressView extends StatefulWidget {
  const BuildProgressView({super.key, required this.controller});

  final BuildController controller;

  @override
  State<BuildProgressView> createState() => _BuildProgressViewState();
}

class _BuildProgressViewState extends State<BuildProgressView> {
  bool _installing = false;
  double _downloadProgress = 0;
  String _installStatus = '';

  BuildController get controller => widget.controller;

  Future<void> _confirmCancel(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Batalkan Build?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Build yang sedang berjalan akan dihentikan secara paksa di GitHub Actions.',
          style: TextStyle(color: kMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Tidak', style: TextStyle(color: kMuted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ya, Batalkan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await controller.cancelBuild();
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Build berhasil dibatalkan'),
              backgroundColor: kCard,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Gagal membatalkan: ${e.toString().replaceFirst('Exception: ', '')}'),
              backgroundColor: kRed,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    }
  }

  /// ✅ Download APK dari artifact URL & install langsung
  Future<void> _downloadAndInstall(BuildRecord r) async {
    final url = r.artifactsUrl ?? r.url;
    if (url == null || url.isEmpty) {
      _showSnack('URL download tidak tersedia');
      return;
    }

    setState(() {
      _installing = true;
      _downloadProgress = 0;
      _installStatus = 'Mengunduh APK...';
    });

    try {
      final dir = await getTemporaryDirectory();
      final filePath = '${dir.path}/santanic-build.apk';

      final existing = File(filePath);
      if (await existing.exists()) await existing.delete();

      final dio = Dio();
      await dio.download(
        url,
        filePath,
        options: Options(
          headers: {
            // GitHub Artifacts butuh token, tapi karena ini artifact publik,
            // kita bisa akses jika repo public. Jika private, ini akan gagal.
            'Accept': 'application/vnd.github+json',
          },
        ),
        onReceiveProgress: (received, total) {
          if (total > 0 && mounted) {
            setState(() => _downloadProgress = received / total);
          }
        },
      );

      if (!mounted) return;
      setState(() => _installStatus = 'Membuka installer...');

      // Buka installer APK
      final result = await OpenFilex.open(filePath);
      if (result.type != ResultType.done) {
        if (mounted) {
          setState(() {
            _installing = false;
            _installStatus = 'Gagal membuka installer: ${result.message}';
          });
        }
        return;
      }

      // Tandai sudah diinstall
      if (mounted) {
        setState(() {
          _installing = false;
          _installStatus = 'Installer dibuka';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _installing = false;
          _installStatus = 'Gagal: ${e.toString()}';
        });
      }
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: kCard,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        final r = controller.display;

        if (r == null) {
          return const Center(
            child: Text(
              'Belum ada riwayat build.',
              style: TextStyle(color: kMuted, fontSize: 14),
            ),
          );
        }

        final color = statusColor(r);
        final progress = (r.percent / 100).clamp(0.0, 1.0);

        return Card(
          color: kCard,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFF22222A)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        r.isFinished ? 'Build Selesai' : 'Sedang Build...',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    if (!r.isFinished)
                      TextButton.icon(
                        onPressed: () => _confirmCancel(context),
                        icon: const Icon(Icons.stop_circle_outlined, color: kRed, size: 18),
                        label: const Text('Batal', style: TextStyle(color: kRed, fontSize: 12)),
                        style: TextButton.styleFrom(
                          side: const BorderSide(color: kRed, width: 1),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          r.statusLabel.toUpperCase(),
                          style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${r.typeLabel} • ${r.owner}/${r.repo}',
                  style: const TextStyle(color: kMuted, fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 24),

                // Circular Progress
                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: r.isFinished ? 1.0 : (r.percent == 0 ? null : progress),
                          strokeWidth: 8,
                          backgroundColor: const Color(0xFF22222A),
                          valueColor: AlwaysStoppedAnimation<Color>(color),
                          strokeCap: StrokeCap.round,
                        ),
                      ),
                      Text(
                        '${r.percent}%',
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Step
                Center(
                  child: Text(
                    r.step.isEmpty ? 'Menunggu runner GitHub...' : r.step,
                    style: const TextStyle(color: kMuted, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 20),

                // Diagnostics
                if (r.diagnostics.isNotEmpty) ...[
                  const Text(
                    'Live Log',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    constraints: const BoxConstraints(maxHeight: 150),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF09090B),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF22222A)),
                    ),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        r.diagnostics.join('\n'),
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 11,
                          color: Color(0xFF00E676),
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],

                // ✅ Tombol Install APK (langsung download & install)
                if (r.url != null && r.url!.isNotEmpty && r.isFinished) ...[
                  const SizedBox(height: 16),
                  
                  // Progress download (jika sedang install)
                  if (_installing) ...[
                    LinearProgressIndicator(
                      value: _downloadProgress > 0 ? _downloadProgress : null,
                      color: kRed,
                      backgroundColor: const Color(0xFF22222A),
                      minHeight: 4,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      _installStatus,
                      style: const TextStyle(color: kMuted, fontSize: 11),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                  ],

                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: r.isSuccess ? kGreen : kRed,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: _installing ? null : () => _downloadAndInstall(r),
                      icon: _installing
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                            )
                          : Icon(
                              r.isSuccess ? Icons.download : Icons.open_in_new,
                              color: Colors.black,
                            ),
                      label: Text(
                        _installing
                            ? 'Mengunduh...'
                            : (r.isSuccess ? 'Install APK' : 'Buka di GitHub'),
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}