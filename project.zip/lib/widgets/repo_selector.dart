import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../theme.dart';

class RepoSelector extends StatefulWidget {
  final String token;
  final String owner;
  final ValueChanged<String> onRepoChanged;

  const RepoSelector({
    super.key,
    required this.token,
    required this.owner,
    required this.onRepoChanged,
  });

  @override
  State<RepoSelector> createState() => _RepoSelectorState();
}

class _RepoSelectorState extends State<RepoSelector> {
  List<String> _repos = [];
  bool _loading = false;
  bool _isNewRepo = false;
  final _newRepoController = TextEditingController();
  String? _selectedRepo;

  @override
  void initState() {
    super.initState();
    _loadRepos();
  }

  @override
  void dispose() {
    _newRepoController.dispose();
    super.dispose();
  }

  Future<void> _loadRepos() async {
    setState(() => _loading = true);
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/user/repos?per_page=100&sort=updated'),
        headers: {
          'Authorization': 'Bearer ${widget.token}',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final list = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
        setState(() {
          _repos = list.map((e) => e['name'] as String).toList();
        });
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: _buildOptionChip(
                label: 'Repo Existing',
                icon: Icons.folder_outlined,
                selected: !_isNewRepo,
                onTap: () {
                  setState(() => _isNewRepo = false);
                  if (_selectedRepo != null) widget.onRepoChanged(_selectedRepo!);
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildOptionChip(
                label: 'Repo Baru',
                icon: Icons.add_circle_outline,
                selected: _isNewRepo,
                onTap: () {
                  setState(() {
                    _isNewRepo = true;
                    _newRepoController.clear();
                  });
                  widget.onRepoChanged('');
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        if (_isNewRepo)
          TextField(
            controller: _newRepoController,
            onChanged: (v) => widget.onRepoChanged(v.trim()),
            decoration: const InputDecoration(
              labelText: 'Nama Repository Baru',
              hintText: 'contoh: my-flutter-app',
              prefixIcon: Icon(Icons.add),
            ),
          )
        else if (_loading)
          const Center(child: Padding(
            padding: EdgeInsets.all(12),
            child: CircularProgressIndicator(color: kRed, strokeWidth: 2),
          ))
        else if (_repos.isEmpty)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kInputBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kBorder),
            ),
            child: const Text(
              'Tidak ada repository. Buat baru.',
              style: TextStyle(color: kMuted, fontSize: 12),
            ),
          )
        else
          DropdownButtonFormField<String>(
            value: _selectedRepo,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Pilih Repository',
              prefixIcon: Icon(Icons.folder_outlined),
            ),
            items: _repos.map((r) => DropdownMenuItem(
              value: r,
              child: Text(r, overflow: TextOverflow.ellipsis),
            )).toList(),
            onChanged: (v) {
              setState(() => _selectedRepo = v);
              if (v != null) widget.onRepoChanged(v);
            },
          ),

        if (_isNewRepo && _newRepoController.text.isNotEmpty) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: kRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: kRed.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: kRed, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Repo "${_newRepoController.text}" akan dibuat otomatis saat build dimulai.',
                    style: const TextStyle(color: kMuted, fontSize: 11),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildOptionChip({
    required String label,
    required IconData icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? kRed.withOpacity(0.15) : kCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? kRed : kBorder),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: selected ? kRed : kMuted, size: 18),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: selected ? kRed : kMuted,
                fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}