import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/repo_status_service.dart';
import '../services/session_manager.dart';
import '../theme.dart';

class StatusTab extends StatefulWidget {
  const StatusTab({super.key, required this.session});
  final SessionManager session;

  @override
  State<StatusTab> createState() => _StatusTabState();
}

class _StatusTabState extends State<StatusTab> {
  RepoStatusService? _service;
  int _filter = 0;
  bool _buildingAll = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final token = await widget.session.getToken();
    if (token.isEmpty) return;
    _service = RepoStatusService(token: token);
    _service!.addListener(() => setState(() {}));
    await _service!.loadRepos();
    await _service!.loadAllRuns();
  }

  Future<void> _refresh() async {
    if (_service == null) return;
    await _service!.loadRepos();
    await _service!.loadAllRuns();
  }

  Future<void> _buildAll() async {
    if (_service == null) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Build Semua?', style: TextStyle(color: Colors.white)),
        content: Text(
          'Akan memicu build untuk ${_service!.repos.length} repository '
          'dengan workflow yang tersedia.\n\nLanjutkan?',
          style: const TextStyle(color: kMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal', style: TextStyle(color: kMuted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ya, Build Semua'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _buildingAll = true);
    final result = await _service!.buildAll();
    setState(() => _buildingAll = false);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '✅ ${result['triggered']} di-trigger • '
          '❌ ${result['failed']} gagal • '
          '⏭️ ${result['skipped']} skip',
        ),
        backgroundColor: kCard,
        behavior: SnackBarBehavior.floating,
      ),
    );

    await _service!.loadAllRuns();
  }

  List<WorkflowRun> _filteredRuns() {
    if (_service == null) return [];
    final all = _service!.runs;
    if (_filter == 1) return all.where((r) => r.isSuccess).toList();
    if (_filter == 2) return all.where((r) => r.isFailure).toList();
    if (_filter == 3) return all.where((r) => r.isQueued || r.isRunning).toList();
    return all;
  }

  @override
  Widget build(BuildContext context) {
    final service = _service;

    if (service == null || service.loading) {
      return const Center(child: CircularProgressIndicator(color: kRed));
    }

    final filtered = _filteredRuns();

    return RefreshIndicator(
      onRefresh: _refresh,
      color: kRed,
      backgroundColor: kCard,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Status Build', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            '${service.repos.length} repository • ${service.runs.length} workflow run',
            style: const TextStyle(color: kMuted, fontSize: 12),
          ),
          const SizedBox(height: 16),

          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kBorder),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _statItem('Berhasil', service.totalSuccess, kGreen),
                _statItem('Gagal', service.totalFailure, kRed),
                _statItem('Antrian', service.totalQueued, const Color(0xFFFFC107)),
                _statItem('Berjalan', service.totalRunning, const Color(0xFF42A5F5)),
              ],
            ),
          ),
          const SizedBox(height: 16),

          FilledButton.icon(
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              backgroundColor: kRed,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _buildingAll ? null : _buildAll,
            icon: _buildingAll
                ? const SizedBox(
                    width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.rocket_launch, size: 20),
            label: Text(
              _buildingAll ? 'Memproses...' : 'Build Semua Tipe (Auto)',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
          ),
          const SizedBox(height: 20),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _filterChip('Semua', 0),
                const SizedBox(width: 8),
                _filterChip('Berhasil', 1),
                const SizedBox(width: 8),
                _filterChip('Gagal', 2),
                const SizedBox(width: 8),
                _filterChip('Antrian', 3),
              ],
            ),
          ),
          const SizedBox(height: 16),

          if (filtered.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 40),
              child: Center(
                child: Text('Tidak ada workflow run', style: TextStyle(color: kMuted)),
              ),
            ),

          for (final run in filtered) _buildRunCard(run),
        ],
      ),
    );
  }

  Widget _statItem(String label, int value, Color color) {
    return Column(
      children: [
        Text(
          value.toString(),
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: color),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: kMuted, fontSize: 11)),
      ],
    );
  }

  Widget _filterChip(String label, int index) {
    final selected = _filter == index;
    return GestureDetector(
      onTap: () => setState(() => _filter = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? kRed : kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? kRed : kBorder),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : kMuted,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  Widget _buildRunCard(WorkflowRun run) {
    final color = run.isSuccess
        ? kGreen
        : run.isFailure
            ? kRed
            : run.isQueued
                ? const Color(0xFFFFC107)
                : const Color(0xFF42A5F5);

    final icon = run.isSuccess
        ? Icons.check
        : run.isFailure
            ? Icons.close
            : run.isQueued
                ? Icons.hourglass_empty
                : Icons.sync;

    return Card(
      color: kCard,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: kBorder),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: run.htmlUrl.isEmpty
            ? null
            : () => launchUrl(Uri.parse(run.htmlUrl), mode: LaunchMode.externalApplication),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      run.workflowName,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      run.repo,
                      style: const TextStyle(color: kMuted, fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  run.statusLabel,
                  style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}