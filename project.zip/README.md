# Santanic Build

Aplikasi Android untuk memicu build APK menggunakan GitHub Actions.

## Alur penggunaan
1. Login GitHub dari aplikasi. Browser dibuka otomatis ke URL verifikasi lengkap GitHub (jika didukung oleh OAuth Device Flow), sehingga kode verifikasi tidak perlu diketik manual.
2. Masukkan owner dan nama repository yang sudah memiliki GitHub Actions aktif.
3. Pilih ZIP project dan opsional file `.yml` workflow kustom.
4. Aplikasi mengirim file ZIP sebagai satu file input `source.zip`, bukan mengekstrak lalu mengunggah seluruh file source satu per satu. File workflow `.yml` ditempatkan di `.github/workflows/`.
5. GitHub Actions menjalankan build dan menyimpan APK sebagai artifact.

## Batasan arsitektur
- Tidak menggunakan backend milik aplikasi.
- GitHub Actions hanya dapat menjalankan workflow yang tersimpan di repository. Karena itu repository dan workflow `.yml` tetap diperlukan.
- File ZIP input tetap perlu tersedia bagi runner GitHub Actions. Pada implementasi ini ZIP disimpan sebagai file `source.zip` di repository. Jika source ZIP sama sekali tidak boleh disimpan di repository, diperlukan penyimpanan eksternal (misalnya object storage) dan kredensial aksesnya.
- Login GitHub tetap membutuhkan persetujuan pengguna. GitHub Device Flow dapat membuka halaman verifikasi lengkap secara otomatis, tetapi aplikasi tidak dapat melewati persetujuan OAuth.
- Riwayat disimpan lokal di perangkat dan tidak dibatasi 50 entri. Menghapus data aplikasi akan menghapus riwayat lokal.

## Profil
Developer: Xyroo  
Support: Yoga, Suika, Yanz, Fahmi


## Perbaikan kompatibilitas Android

- Menambahkan `MainActivity.kt` sesuai namespace `com.santanic.build`.
- Melengkapi Gradle Wrapper (`gradlew`, `gradlew.bat`, dan wrapper JAR).
- Menambahkan aset foreground launcher yang sebelumnya direferensikan tetapi belum ada.
- Menjadikan inisialisasi notifikasi dan background service tidak memblokir startup UI jika plugin gagal diinisialisasi.
- Menyinkronkan token ke SharedPreferences agar background isolate dapat membaca token build; secure storage tetap menjadi penyimpanan utama.
- Workflow CI tidak menjalankan dua jenis build sekaligus untuk satu project Flutter.

Catatan: arsip telah diperbaiki secara statis. Build Flutter/Android dan uji buka aplikasi di perangkat belum dapat dijalankan di lingkungan ini karena Flutter SDK dan Android SDK tidak tersedia. Token GitHub PAT tidak disertakan dalam arsip; masukkan melalui mekanisme rahasia yang aman, jangan hardcode ke source code.
