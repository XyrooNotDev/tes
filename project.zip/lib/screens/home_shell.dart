import 'package:flutter/material.dart';

import '../nav.dart';
import '../services/build_controller.dart';
import '../services/device_info_service.dart';
import '../services/github_auth.dart';
import '../services/session_manager.dart';
import '../theme.dart';
import 'history_tab.dart';
import 'home_tab.dart';
import 'settings_tab.dart';
import 'status_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.session, required this.onLogout});
  final SessionManager session;
  final VoidCallback onLogout;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  late final BuildController _controller;
  final DeviceInfoService _deviceInfo = DeviceInfoService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = BuildController(session: widget.session);
    _controller.init();
    _deviceInfo.init();
    WidgetsBinding.instance.addPostFrameCallback((_) => _validateSession());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    _deviceInfo.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _controller.reload();
  }

  Future<void> _logout() async {
    await widget.session.logout();
    widget.onLogout();
  }

  Future<void> _validateSession() async {
    final token = await widget.session.getToken();
    if (token.isEmpty) return;
    try {
      await GitHubAuth().fetchUsername(token);
    } catch (e) {
      await _logout();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Sesi berakhir, silakan login ulang.'),
            backgroundColor: kRed,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: AppNav.tabIndex,
      builder: (context, index, _) {
        return Scaffold(
          body: SafeArea(
            child: IndexedStack(
              index: index,
              children: [
                HomeTab(
                  session: widget.session,
                  onLogout: _logout,
                  deviceInfo: _deviceInfo,
                  controller: _controller,
                ),
                StatusTab(session: widget.session),
                HistoryTab(controller: _controller),
                SettingsTab(session: widget.session, onLogout: _logout),
              ],
            ),
          ),
          bottomNavigationBar: ListenableBuilder(
            listenable: _controller,
            builder: (context, _) {
              return NavigationBar(
                selectedIndex: index,
                onDestinationSelected: (i) => AppNav.tabIndex.value = i,
                backgroundColor: kCard,
                indicatorColor: kRed.withOpacity(0.15),
                elevation: 0,
                height: 70,
                destinations: [
                  NavigationDestination(
                    icon: Badge(
                      isLabelVisible: _controller.isRunning,
                      backgroundColor: kRed,
                      child: const Icon(Icons.home_outlined, color: kMuted),
                    ),
                    selectedIcon: Badge(
                      isLabelVisible: _controller.isRunning,
                      backgroundColor: kRed,
                      child: const Icon(Icons.home, color: kRed),
                    ),
                    label: 'Beranda',
                  ),
                  const NavigationDestination(
                    icon: Icon(Icons.dashboard_outlined, color: kMuted),
                    selectedIcon: Icon(Icons.dashboard, color: kRed),
                    label: 'Status',
                  ),
                  const NavigationDestination(
                    icon: Icon(Icons.history, color: kMuted),
                    selectedIcon: Icon(Icons.history, color: kRed),
                    label: 'Riwayat',
                  ),
                  NavigationDestination(
                    icon: const Icon(Icons.person_outline, color: kMuted),
                    selectedIcon: const Icon(Icons.person, color: kRed),
                    label: widget.session.username,
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}