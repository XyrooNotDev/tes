import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/analyzer_runner.dart';
import '../services/build_controller.dart';
import '../services/project_analyzer.dart';
import '../services/session_manager.dart';
import '../services/upload_tracker.dart';
import '../theme.dart';
import '../widgets/repo_selector.dart';
import '../widgets/upload_progress_card.dart';
import 'build_android_screen.dart';
import 'build_flutter_screen.dart';

class _Finding {
  const _Finding(this.sev, this.title, this.detail, this.file, this.line, this.source);

  final String sev; // error | warning | info
  final String title;
  final String detail;
  final String? file;
  final int? line;
  final String source; // Lokal | Actions

  factory _Finding.from(Map<dynamic, dynamic> m, String source) => _Finding(
        m['sev']?.toString() ?? 'info',
        m['title']?.toString() ?? '',
        m['detail']?.toString() ?? '',
        m['file']?.toString(),
        m['line'] is int ? m['line'] as int : null,
        source,
      );

  int get rank => sev == 'error' ? 0 : (sev == 'warning' ? 1 : 2);
  String get location => file == null ? '' : (line == null ? file! : '$file:$line');
}

/// Analyzer Project: cek cepat di HP, lalu analisis lengkap lewat workflow analyzer.yml di GitHub Actions.
class ProjectAnalyzerScreen extends StatefulWidget {
  const ProjectAnalyzerScreen({super.key, required this.session, required this.controller});

  final SessionManager session;
  final BuildController controller;

  @override
  State<ProjectAnalyzerScreen> createState() => _ProjectAnalyzerScreenState();
}

class _ProjectAnalyzerScreenState extends State<ProjectAnalyzerScreen> {
  final UploadTracker _upload = UploadTracker();

  String? _zipPath;
  String? _token;
  String _repo = '';
  bool _useActions = true;
  bool _deep = false;

  bool _busy = false;
  bool _cancel = false;
  bool _ciStarted = false;
  String _phase = '';
  int _percent = 0;
  String _stepLabel = '';
  String? _error;
  String? _runUrl;

  List<_Finding>? _local;
  List<_Finding>? _ci;
  List<Map<String, dynamic>> _ciSteps = const [];

  @override
  void initState() {
    super.initState();
    widget.session.getToken().then((t) {
      if (mounted) setState(() => _token = t);
    });
  }

  @override
  void dispose() {
    _cancel = true;
    _upload.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _pick() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    if (res == null || res.files.isEmpty) return;
    setState(() {
      _zipPath = res.files.first.path;
      _local = null;
      _ci = null;
      _ciSteps = const [];
      _error = null;
      _runUrl = null;
    });
  }

  Future<void> _analyze() async {
    final path = _zipPath;
    if (path == null) return;
    if (_useActions) {
      if (_repo.trim().isEmpty) {
        _snack('Pilih atau isi repository untuk analisis di GitHub Actions.');
        return;
      }
      if ((_token ?? '').isEmpty) {
        _snack('Token GitHub tidak ditemukan, silakan login ulang.');
        return;
      }
    }

    setState(() {
      _busy = true;
      _cancel = false;
      _ciStarted = false;
      _error = null;
      _local = null;
      _ci = null;
      _ciSteps = const [];
      _runUrl = null;
      _percent = 0;
      _stepLabel = '';
      _phase = 'Cek cepat di HP...';
    });

    try {
      final raw = await runAnalyzerInIsolate(path);
      final local = raw.whereType<Map>().map((m) => _Finding.from(m, 'Lokal')).toList();
      if (mounted) setState(() => _local = local);

      if (_useActions && mounted) {
        setState(() => _phase = 'Menjalankan analyzer.yml di GitHub Actions...');
        final res = await AnalyzerRunner.run(
          token: _token!,
          owner: widget.session.username,
          repo: _repo.trim(),
          zipPath: path,
          deep: _deep,
          upload: _upload,
          onProgress: (p, label) {
            if (mounted) {
              setState(() {
                _ciStarted = true;
                _percent = p;
                _stepLabel = label;
              });
            }
          },
          cancelled: () => _cancel || !mounted,
        );
        if (!mounted) return;
        setState(() {
          _ci = res.findings.map((m) => _Finding.from(m, 'Actions')).toList();
          _ciSteps = res.steps;
          _runUrl = res.runUrl;
          if (res.error != null) _error = res.error;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = 'Analisis gagal: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _ciStarted = false;
          _phase = '';
        });
      }
    }
  }

  List<_Finding> get _all =>
      [...?_local, ...?_ci]..sort((a, b) => a.rank.compareTo(b.rank));

  String _report() {
    final b = StringBuffer('LAPORAN ANALYZER — ${_zipPath?.split('/').last}\n\n');
    for (final x in _all) {
      b.writeln('[${x.sev.toUpperCase()}] (${x.source}) ${x.title}');
      if (x.location.isNotEmpty) b.writeln('  ${x.location}');
      if (x.detail.isNotEmpty) b.writeln('  ${x.detail}');
      b.writeln();
    }
    return b.toString();
  }

  Future<void> _continueToWorkflowBuild() async {
    final path = _zipPath;
    if (path == null) return;
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Pilih workflow build'),
        content: const Text('Analisis selesai. Pilih workflow GitHub Actions untuk membangun APK dari ZIP ini.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'android'), child: const Text('Android Studio')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'flutter'), child: const Text('Flutter')),
        ],
      ),
    );
    if (!mounted || choice == null) return;
    final screen = choice == 'android'
        ? BuildAndroidScreen(session: widget.session, controller: widget.controller, initialZipPath: path)
        : BuildFlutterScreen(session: widget.session, controller: widget.controller, initialZipPath: path);
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  Color _color(String sev) =>
      sev == 'error' ? kRed : (sev == 'warning' ? const Color(0xFFFFC107) : const Color(0xFF42A5F5));
  IconData _icon(String sev) =>
      sev == 'error' ? Icons.error : (sev == 'warning' ? Icons.warning_amber_rounded : Icons.info_outline);

  @override
  Widget build(BuildContext context) {
    final all = _all;
    final hasResult = _local != null;
    final errors = all.where((e) => e.sev == 'error').length;
    final warns = all.where((e) => e.sev == 'warning').length;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('Analyzer Project'),
        backgroundColor: kBg,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          if (hasResult)
            IconButton(
              tooltip: 'Salin laporan',
              icon: const Icon(Icons.copy),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: _report()));
                _snack('Laporan disalin');
              },
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Cek cepat di HP (struktur, manifest, resource, import, XML/JSON/YAML), lalu analisis lengkap lewat '
            'workflow analyzer.yml di GitHub Actions (flutter analyze / compile Gradle, dependency, rahasia tertanam).',
            style: TextStyle(color: kMuted, fontSize: 12),
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: _busy ? null : _pick,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: kInputBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                children: [
                  Icon(Icons.folder_zip_outlined, size: 38, color: _zipPath != null ? kRed : kMuted),
                  const SizedBox(height: 10),
                  Text(
                    _zipPath != null ? _zipPath!.split('/').last : 'Pilih ZIP project',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: _zipPath != null ? Colors.white : kMuted, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: _useActions,
            onChanged: _busy ? null : (v) => setState(() => _useActions = v),
            activeColor: kRed,
            title: const Text('Analisis lengkap (analyzer.yml)',
                style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
            subtitle: const Text('Dijalankan di GitHub Actions. Matikan untuk cek cepat saja (tanpa internet).',
                style: TextStyle(color: kMuted, fontSize: 11)),
          ),
          if (_useActions) ...[
            if ((_token ?? '').isNotEmpty)
              RepoSelector(
                token: _token!,
                owner: widget.session.username,
                onRepoChanged: (v) => _repo = v,
              )
            else
              const Padding(
                padding: EdgeInsets.all(12),
                child: Center(child: CircularProgressIndicator(color: kRed)),
              ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _deep,
              onChanged: _busy ? null : (v) => setState(() => _deep = v),
              activeColor: kRed,
              title: const Text('Analisis mendalam',
                  style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
              subtitle: const Text('Ditambah build debug penuh (lebih lama, menangkap error native/packaging).',
                  style: TextStyle(color: kMuted, fontSize: 11)),
            ),
          ],
          const SizedBox(height: 8),
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), backgroundColor: kRed),
            onPressed: (_busy || _zipPath == null) ? null : _analyze,
            icon: _busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.fact_check_outlined),
            label: Text(_busy ? _phase : 'Analisis Project'),
          ),
          const SizedBox(height: 12),
          UploadProgressCard(tracker: _upload),
          if (_busy && _ciStarted) _ciCard(),
          if (_error != null) ...[
            const SizedBox(height: 4),
            Text(_error!, style: const TextStyle(color: kRed, fontSize: 12)),
          ],
          if (hasResult) ...[
            const SizedBox(height: 12),
            if (_ciSteps.isNotEmpty)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final s in _ciSteps)
                    Chip(
                      backgroundColor: kCard,
                      side: BorderSide(color: (s['ok'] == true ? kGreen : kRed).withOpacity(0.6)),
                      avatar: Icon(s['ok'] == true ? Icons.check_circle : Icons.cancel,
                          size: 16, color: s['ok'] == true ? kGreen : kRed),
                      label: Text('${s['name']}', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                    ),
                ],
              ),
            const SizedBox(height: 8),
            Row(
              children: [
                _chip('Error', errors, kRed),
                const SizedBox(width: 8),
                _chip('Peringatan', warns, const Color(0xFFFFC107)),
                const SizedBox(width: 8),
                _chip('Info', all.length - errors - warns, const Color(0xFF42A5F5)),
                const Spacer(),
                if (_runUrl != null)
                  TextButton(
                    onPressed: () => launchUrl(Uri.parse(_runUrl!), mode: LaunchMode.externalApplication),
                    child: const Text('Buka run', style: TextStyle(fontSize: 12)),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            for (final x in all) _card(x),
            const SizedBox(height: 8),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52), backgroundColor: kGreen, foregroundColor: Colors.black),
              onPressed: (_busy || errors > 0) ? null : _continueToWorkflowBuild,
              icon: const Icon(Icons.rocket_launch),
              label: const Text('Lanjut Build via GitHub Actions Workflows'),
            ),
            if (errors > 0)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('Perbaiki temuan error terlebih dahulu sebelum melanjutkan build.',
                    style: TextStyle(color: kRed, fontSize: 11)),
              ),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _ciCard() {
    return Card(
      color: kCard,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: kBorder),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.fact_check_outlined, color: Color(0xFF42A5F5), size: 20),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('Menganalisis di GitHub Actions',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                ),
                Text('$_percent%',
                    style: const TextStyle(color: Color(0xFF42A5F5), fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: _percent == 0 ? null : _percent / 100,
              color: const Color(0xFF42A5F5),
              backgroundColor: kBorder,
              minHeight: 6,
              borderRadius: BorderRadius.circular(3),
            ),
            const SizedBox(height: 8),
            Text(_stepLabel, style: const TextStyle(color: kMuted, fontSize: 12)),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => setState(() => _cancel = true),
                child: const Text('Batalkan', style: TextStyle(color: kRed, fontSize: 12)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label, int n, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: c.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
        child: Text('$label $n', style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12)),
      );

  Widget _card(_Finding x) {
    final c = _color(x.sev);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withOpacity(0.45)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(_icon(x.sev), color: c, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(x.title,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                    ),
                    Text(x.source, style: const TextStyle(color: kMuted, fontSize: 10)),
                  ],
                ),
                if (x.location.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(x.location, style: TextStyle(color: c, fontSize: 11, fontFamily: 'monospace')),
                ],
                if (x.detail.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(x.detail, style: const TextStyle(color: kMuted, fontSize: 12)),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
