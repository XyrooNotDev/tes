# Santanic Build

Aplikasi Android (Flutter) untuk membangun APK lewat GitHub Actions langsung dari HP.

## Fitur
- Login GitHub, pilih repository, upload ZIP project (Android Studio / Flutter) atau buat APK dari website (WebToAPK).
- Workflow bawaan di `assets/workflows/`, atau upload file `.yml` sendiri (kecuali WebToAPK). ZIP disimpan sebagai `project.zip`.
- Hingga 3 build berjalan bersamaan (satu repository satu build), dipantau di latar belakang dengan notifikasi popup.
- Tab Progress: job, step, durasi, log; unduh dan install APK langsung dari aplikasi.
- Status: statistik dan progress build semua pengguna (repository publik).
- Analyzer Project: ZIP dianalisis lewat workflow `analyzer.yml` di GitHub Actions dengan progress seperti build (latar belakang + notifikasi popup). Hanya error yang ditampilkan; bila tidak ada error, build dilanjutkan otomatis.
- Ganti Icon / Nama / Package / Rename Semua. Domain dipisah per `https://` dan `http://` (cari di semua file, ganti satu per satu atau semuanya sekaligus).
- Pembaruan aplikasi dibaca dari `latest.json` dan APK pada GitHub Release.

## Build
```
flutter pub get
flutter build apk --release --split-per-abi --target-platform android-arm,android-arm64
```
Workflow CI: `.github/workflows/build.yml`. Pastikan folder `android/app/src/main/kotlin` ikut ter-ZIP
(berisi `MainActivity` dan `SantanicApplication` yang dirujuk manifest).

## Catatan
- Token GitHub tidak disimpan di source code.
- Hanya repository publik (dan repository sendiri) yang tampil di Status.
