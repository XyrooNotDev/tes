import 'package:flutter/material.dart';

import '../nav.dart';
import '../services/build_controller.dart';
import '../services/session_manager.dart';
import 'build_zip_screen.dart';

class BuildAndroidScreen extends StatelessWidget {
  const BuildAndroidScreen({super.key, required this.session, required this.controller});
  final SessionManager session;
  final BuildController controller;

  @override
  Widget build(BuildContext context) {
    return BuildZipScreen(
      session: session,
      controller: controller,
      title: 'Build Android Studio',
      typeKey: AppNav.buildAndroid,
      label: 'Android',
      assetPath: 'assets/workflows/build_android.yml',
      defaultWorkflowName: 'build_android.yml',
    );
  }
}
