class BuildRecord {
  const BuildRecord({
    required this.id,
    required this.type,
    required this.owner,
    required this.repo,
    required this.workflow,
    required this.startedAt,
    this.finishedAt,
    this.status = 'queued',
    this.percent = 0,
    this.step = '',
    this.runId,
    this.baselineRunId = 0,
    this.url,
    this.artifactsUrl,
    this.diagnostics = const [],
    this.isInstalled = false,
    this.runNumber,
    this.branch,
    this.sha,
    this.actor,
    this.mode = '',
    this.customWorkflow = false,
    this.jobs = const [],
    this.logTail = '',
    this.apkPath,
    this.downloadState = 'none',
    this.downloadPercent = 0,
    this.downloadError = '',
  });

  final String id;
  final String type; // ANDROID | FLUTTER | WEBTOAPK
  final String owner;
  final String repo;
  final String workflow;
  final int startedAt;
  final int? finishedAt;
  final String status; // queued | running | success | failure | cancelled
  final int percent;
  final String step;
  final int? runId;
  final int baselineRunId;
  final String? url;
  final String? artifactsUrl;
  final List<String> diagnostics;
  final bool isInstalled;

  // Detail run GitHub
  final int? runNumber;
  final String? branch;
  final String? sha;
  final String? actor;
  final String mode; // release | debug
  final bool customWorkflow; // true = .yml dari pengguna, false = bawaan assets

  /// Detail job + step: [{id,name,status,conclusion,start,end,runner,url,steps:[{n,name,status,conclusion,start,end}]}]
  final List<Map<String, dynamic>> jobs;
  final String logTail;

  // Hasil download APK (artifact) di perangkat
  final String? apkPath;
  final String downloadState; // none | downloading | done | failed
  final int downloadPercent;
  final String downloadError;

  bool get isFinished =>
      status == 'success' || status == 'failure' || status == 'cancelled';
  bool get isSuccess => status == 'success';
  bool get isDownloading => downloadState == 'downloading';
  bool get hasApk => apkPath != null && apkPath!.isNotEmpty && downloadState == 'done';

  int get elapsedMs {
    final end = finishedAt ?? DateTime.now().millisecondsSinceEpoch;
    final v = end - startedAt;
    return v < 0 ? 0 : v;
  }

  String get typeLabel {
    switch (type) {
      case 'FLUTTER':
        return 'Flutter';
      case 'WEBTOAPK':
        return 'WebToAPK';
      case 'CUSTOM':
        return 'Kustom';
      case 'ANDROID':
      default:
        return 'Android Studio';
    }
  }

  String get statusLabel {
    switch (status) {
      case 'queued':
        return 'Mengantre';
      case 'running':
        return 'Berjalan';
      case 'success':
        return 'Berhasil';
      case 'cancelled':
        return 'Dibatalkan';
      case 'failure':
      default:
        return 'Gagal';
    }
  }

  BuildRecord copyWith({
    int? finishedAt,
    String? status,
    int? percent,
    String? step,
    int? runId,
    String? url,
    String? artifactsUrl,
    List<String>? diagnostics,
    bool? isInstalled,
    int? runNumber,
    String? branch,
    String? sha,
    String? actor,
    List<Map<String, dynamic>>? jobs,
    String? logTail,
    String? apkPath,
    String? downloadState,
    int? downloadPercent,
    String? downloadError,
  }) {
    return BuildRecord(
      id: id,
      type: type,
      owner: owner,
      repo: repo,
      workflow: workflow,
      startedAt: startedAt,
      finishedAt: finishedAt ?? this.finishedAt,
      status: status ?? this.status,
      percent: percent ?? this.percent,
      step: step ?? this.step,
      runId: runId ?? this.runId,
      baselineRunId: baselineRunId,
      url: url ?? this.url,
      artifactsUrl: artifactsUrl ?? this.artifactsUrl,
      diagnostics: diagnostics ?? this.diagnostics,
      isInstalled: isInstalled ?? this.isInstalled,
      runNumber: runNumber ?? this.runNumber,
      branch: branch ?? this.branch,
      sha: sha ?? this.sha,
      actor: actor ?? this.actor,
      mode: mode,
      customWorkflow: customWorkflow,
      jobs: jobs ?? this.jobs,
      logTail: logTail ?? this.logTail,
      apkPath: apkPath ?? this.apkPath,
      downloadState: downloadState ?? this.downloadState,
      downloadPercent: downloadPercent ?? this.downloadPercent,
      downloadError: downloadError ?? this.downloadError,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'owner': owner,
        'repo': repo,
        'workflow': workflow,
        'startedAt': startedAt,
        'finishedAt': finishedAt,
        'status': status,
        'percent': percent,
        'step': step,
        'runId': runId,
        'baselineRunId': baselineRunId,
        'url': url,
        'artifactsUrl': artifactsUrl,
        'diagnostics': diagnostics,
        'isInstalled': isInstalled,
        'runNumber': runNumber,
        'branch': branch,
        'sha': sha,
        'actor': actor,
        'mode': mode,
        'customWorkflow': customWorkflow,
        'jobs': jobs,
        'logTail': logTail,
        'apkPath': apkPath,
        'downloadState': downloadState,
        'downloadPercent': downloadPercent,
        'downloadError': downloadError,
      };

  factory BuildRecord.fromJson(Map<String, dynamic> j) => BuildRecord(
        id: j['id'] as String,
        type: j['type'] as String? ?? 'ANDROID',
        owner: j['owner'] as String? ?? '',
        repo: j['repo'] as String? ?? '',
        workflow: j['workflow'] as String? ?? '',
        startedAt: (j['startedAt'] as num).toInt(),
        finishedAt: (j['finishedAt'] as num?)?.toInt(),
        status: j['status'] as String? ?? 'queued',
        percent: (j['percent'] as num?)?.toInt() ?? 0,
        step: j['step'] as String? ?? '',
        runId: (j['runId'] as num?)?.toInt(),
        baselineRunId: (j['baselineRunId'] as num?)?.toInt() ?? 0,
        url: j['url'] as String?,
        artifactsUrl: j['artifactsUrl'] as String?,
        diagnostics:
            (j['diagnostics'] as List?)?.map((e) => e.toString()).toList() ??
                const [],
        isInstalled: j['isInstalled'] as bool? ?? false,
        runNumber: (j['runNumber'] as num?)?.toInt(),
        branch: j['branch'] as String?,
        sha: j['sha'] as String?,
        actor: j['actor'] as String?,
        mode: j['mode'] as String? ?? '',
        customWorkflow: j['customWorkflow'] as bool? ?? false,
        jobs: (j['jobs'] as List?)
                ?.map((e) => Map<String, dynamic>.from(e as Map))
                .toList() ??
            const [],
        logTail: j['logTail'] as String? ?? '',
        apkPath: j['apkPath'] as String?,
        downloadState: j['downloadState'] as String? ?? 'none',
        downloadPercent: (j['downloadPercent'] as num?)?.toInt() ?? 0,
        downloadError: j['downloadError'] as String? ?? '',
      );
}
