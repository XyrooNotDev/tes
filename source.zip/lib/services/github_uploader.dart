import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'github_api_exception.dart';

class GitHubUploader {
  GitHubUploader(this.token, this.owner, this.repo);

  final String token;
  final String owner;
  final String repo;

  static const Duration _timeout = Duration(seconds: 30);

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'Content-Type': 'application/json',
      };

  Uri _u(String path) => Uri.https('api.github.com', '/repos/$owner/$repo$path');

  Map<String, dynamic> _ok(http.Response r, String what) {
    if (r.statusCode >= 200 && r.statusCode < 300) {
      if (r.body.isEmpty) return <String, dynamic>{};
      return jsonDecode(r.body) as Map<String, dynamic>;
    }
    var msg = r.reasonPhrase ?? '';
    try {
      msg = (jsonDecode(r.body) as Map<String, dynamic>)['message'] as String? ?? msg;
    } catch (_) {}
    throw GitHubApiException(r.statusCode, '$what: $msg');
  }

  Future<String> uploadZipWithBuiltinWorkflow({
    required String zipPath,
    required String assetWorkflowPath,
    required String workflowName,
    required String commitMessage,
  }) async {
    final yamlString = await rootBundle.loadString(assetWorkflowPath);
    return _uploadInternal(
      {'source.zip': zipPath},
      commitMessage,
      extraTextFiles: {'.github/workflows/$workflowName': yamlString},
    );
  }
  Future<bool> ensureRepoExists() async {
  final check = await http.get(
    _u(''),
    headers: _headers,
  ).timeout(_timeout);

  if (check.statusCode == 200) return false;

  final res = await http.post(
    Uri.parse('https://api.github.com/user/repos'),
    headers: _headers,
    body: jsonEncode({
      'name': repo,
      'auto_init': true,
      'private': false,
    }),
  ).timeout(_timeout);

  if (res.statusCode == 201) {
    await Future.delayed(const Duration(seconds: 3));
    return true;
  }

  var msg = res.reasonPhrase ?? '';
  try {
    msg = (jsonDecode(res.body) as Map<String, dynamic>)['message'] as String? ?? msg;
  } catch (_) {}
  throw GitHubApiException(res.statusCode, 'Gagal membuat repository: $msg');
}

  Future<String> uploadBuiltinWorkflowOnly({
    required String assetWorkflowPath,
    required String workflowName,
    required String commitMessage,
  }) async {
    final yamlString = await rootBundle.loadString(assetWorkflowPath);
    return _uploadInternal(
      {},
      commitMessage,
      extraTextFiles: {'.github/workflows/$workflowName': yamlString},
    );
  }

  Future<String> _uploadInternal(
    Map<String, String> files,
    String commitMessage, {
    Map<String, String> extraTextFiles = const {},
  }) async {
    final repoInfo = _ok(
      await http.get(_u(''), headers: _headers).timeout(_timeout),
      'Repo tidak ditemukan',
    );
    final branch = repoInfo['default_branch'] as String? ?? 'main';

    final ref = _ok(
      await http.get(_u('/git/refs/heads/$branch'), headers: _headers).timeout(_timeout),
      'Gagal ambil commit HEAD',
    );
    final headSha = (ref['object'] as Map<String, dynamic>)['sha'] as String;

    final headCommit = _ok(
      await http.get(_u('/git/commits/$headSha'), headers: _headers).timeout(_timeout),
      'Gagal ambil commit',
    );
    final baseTreeSha = (headCommit['tree'] as Map<String, dynamic>)['sha'] as String;

    final tree = <Map<String, String>>[];

    for (final entry in files.entries) {
      final file = File(entry.value);
      if (!await file.exists()) {
        throw GitHubApiException(404, 'File tidak ditemukan: ${entry.value}');
      }
      final length = await file.length();
      if (length > 100 * 1024 * 1024) {
        throw GitHubApiException(413, 'File ${entry.key} melebihi 100MB');
      }
      final bytes = await file.readAsBytes();
      final blob = _ok(
        await http.post(
          _u('/git/blobs'),
          headers: _headers,
          body: jsonEncode({'content': base64Encode(bytes), 'encoding': 'base64'}),
        ).timeout(_timeout),
        'Gagal upload ${entry.key}',
      );
      tree.add({'path': entry.key, 'mode': '100644', 'type': 'blob', 'sha': blob['sha'] as String});
    }

    for (final entry in extraTextFiles.entries) {
      final bytes = utf8.encode(entry.value);
      final blob = _ok(
        await http.post(
          _u('/git/blobs'),
          headers: _headers,
          body: jsonEncode({'content': base64Encode(bytes), 'encoding': 'base64'}),
        ).timeout(_timeout),
        'Gagal upload ${entry.key}',
      );
      tree.add({'path': entry.key, 'mode': '100644', 'type': 'blob', 'sha': blob['sha'] as String});
    }

    final newTree = _ok(
      await http.post(
        _u('/git/trees'),
        headers: _headers,
        body: jsonEncode({'base_tree': baseTreeSha, 'tree': tree}),
      ).timeout(_timeout),
      'Gagal membuat tree',
    );

    final newCommit = _ok(
      await http.post(
        _u('/git/commits'),
        headers: _headers,
        body: jsonEncode({
          'message': commitMessage,
          'tree': newTree['sha'],
          'parents': [headSha],
        }),
      ).timeout(_timeout),
      'Gagal membuat commit',
    );

    _ok(
      await http.patch(
        _u('/git/refs/heads/$branch'),
        headers: _headers,
        body: jsonEncode({'sha': newCommit['sha'], 'force': false}),
      ).timeout(_timeout),
      'Gagal push ke repository',
    );

    return branch;
  }
}