/// Konfigurasi aplikasi. Edit nilai di bawah ini sebelum build.
///
/// PERINGATAN KEAMANAN: token yang ditanam di aplikasi bisa diekstrak oleh siapa pun yang
/// memegang APK-nya. Gunakan token fine-grained yang HANYA punya akses ke satu repo khusus
/// (Contents + Actions: read/write), bukan token akun utama. Jangan commit file ini ke repo
/// publik berisi token asli; lebih aman memasukkannya saat build:
///   flutter build apk --dart-define=GITHUB_TOKEN=ghp_xxx --dart-define=REPO_OWNER=nama
class AppConfig {
  AppConfig._();

  /// Token akses GitHub milik pemilik aplikasi (dipakai semua pengguna).
  static const String githubToken =
      String.fromEnvironment('GITHUB_TOKEN', defaultValue: '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');

  /// Pemilik repo (username / organisasi GitHub) dan nama repo tempat semua build berjalan.
  /// Repo dibuat otomatis oleh aplikasi bila belum ada.
  static const String repoOwner =
      String.fromEnvironment('REPO_OWNER', defaultValue: 'XyrooNotDev');
  static const String repoName =
      String.fromEnvironment('REPO_NAME', defaultValue: 'santanic-build-data');

  /// Repo berisi ZIP project semua pengguna, jadi sebaiknya privat.
  static const bool repoPrivate = true;

  /// File data pengguna di dalam repo (hanya nama + credit + tanggal check-in terakhir).
  static const String usersFile = 'user.json';

  /// Credit: pengguna baru, check-in harian, dan biaya satu build.
  static const int startCredits = 5;
  static const int dailyCheckInCredits = 1;
  static const int buildCost = 1;

  /// Opsional: Web client ID Google (OAuth) untuk google_sign_in.
  static const String googleServerClientId =
      String.fromEnvironment('GOOGLE_SERVER_CLIENT_ID', defaultValue: '');

  static bool get isConfigured =>
      !githubToken.startsWith('ISI_') && !repoOwner.startsWith('ISI_') && githubToken.isNotEmpty;
}
