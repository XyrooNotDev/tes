import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'nav.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'services/build_tracker.dart';
import 'services/notification_service.dart';
import 'services/session_manager.dart';
import 'theme.dart';

void _onNotificationTap(NotificationResponse response) {
  if (response.payload == kPayloadBuildTab) {
    AppNav.tabIndex.value = AppNav.historyTab;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await NotificationService.init(onTap: _onNotificationTap);
  } catch (e, st) {
    debugPrint('Notification initialization skipped: $e\n$st');
  }
  try {
    await BuildTracker.configure();
  } catch (e, st) {
    debugPrint('Background service initialization skipped: $e\n$st');
  }

  final session = await SessionManager.load();
  final isLoggedIn = await session.isLoggedIn;

  try {
    if (await NotificationService.isLaunchedFromBuildNotif()) {
      AppNav.tabIndex.value = AppNav.historyTab;
    }
  } catch (e) {
    debugPrint('Notification launch details unavailable: $e');
  }

  runApp(SantanicApp(session: session, initialLoggedIn: isLoggedIn));
}

class SantanicApp extends StatefulWidget {
  const SantanicApp({super.key, required this.session, required this.initialLoggedIn});

  final SessionManager session;
  final bool initialLoggedIn;

  @override
  State<SantanicApp> createState() => _SantanicAppState();
}

class _SantanicAppState extends State<SantanicApp> {
  late bool _loggedIn = widget.initialLoggedIn;

  void _handleLogin() => setState(() => _loggedIn = true);

  void _handleLogout() {
    AppNav.tabIndex.value = AppNav.homeTab;
    AppNav.buildType.value = AppNav.buildAndroid;
    setState(() => _loggedIn = false);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Santanic Build',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: AnimatedSwitcher(
        duration: const Duration(milliseconds: 400),
        child: _loggedIn
            ? HomeShell(
                key: const ValueKey('HomeShell'),
                session: widget.session,
                onLogout: _handleLogout,
              )
            : LoginScreen(
                key: const ValueKey('LoginScreen'),
                session: widget.session,
                onLoggedIn: _handleLogin,
              ),
      ),
    );
  }
}