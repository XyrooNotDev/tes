import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart'; // ✅ FIX: untuk debugPrint
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/build_record.dart';
import 'build_store.dart';
import 'github_actions.dart';
import 'notification_service.dart';
import 'session_manager.dart';

class BuildTracker {
  static Future<void> configure() async {
    await FlutterBackgroundService().configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onBuildServiceStart,
        autoStart: false,
        isForegroundMode: true,
        notificationChannelId: kProgressChannelId,
        initialNotificationTitle: 'Santanic Build',
        initialNotificationContent: 'Menyiapkan build...',
        foregroundServiceNotificationId: kProgressNotifId,
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
  }

  static Future<void> start() async {
    final service = FlutterBackgroundService();
    if (await service.isRunning()) {
      service.invoke('stop');
      await Future<void>.delayed(const Duration(seconds: 1));
    }
    await service.startService();
  }
}

@pragma('vm:entry-point')
Future<void> onBuildServiceStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  bool stopped = false;
  service.on('stop').listen((_) {
    stopped = true;
  });

  try {
    await NotificationService.init();
    await _track(service, () => stopped);
  } catch (e) {
    debugPrint('BuildTracker Error: $e'); // ✅ Sekarang bisa dipakai
  } finally {
    service.stopSelf();
  }
}

Future<void> _track(ServiceInstance service, bool Function() stopped) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final token = prefs.getString(SessionManager.kToken) ?? '';
  final loaded = await BuildStore.loadCurrent();

  if (loaded == null || loaded.isFinished || token.isEmpty) return;

  var rec = loaded;
  final api = GitHubActions(token);
  final deadline = DateTime.fromMillisecondsSinceEpoch(rec.startedAt)
      .add(const Duration(minutes: 60));

  int emptyRunRetries = 0;

  await _publish(rec);

  while (!stopped()) {
    if (DateTime.now().isAfter(deadline)) {
      await _finish(service, rec.copyWith(
        status: 'failure',
        step: 'Melewati batas waktu pelacakan (Timeout 60 menit)',
      ));
      return;
    }

    try {
      if (rec.runId == null) {
        final run = await api.findRun(rec.owner, rec.repo, rec.workflow, rec.baselineRunId);
        if (run != null) {
          rec = rec.copyWith(runId: run.id, url: run.htmlUrl);
          emptyRunRetries = 0;
        } else {
          emptyRunRetries++;
          if (emptyRunRetries > 10) {
            await _finish(service, rec.copyWith(
              status: 'failure',
              step: 'Gagal menemukan workflow run di GitHub',
            ));
            return;
          }
        }
      }

      final runId = rec.runId;
      if (runId != null) {
        final p = await api.progress(rec.owner, rec.repo, runId);
        final newStatus = p.finished
            ? p.finalStatus
            : (p.status == 'queued' ? 'queued' : 'running');

        rec = rec.copyWith(
          status: newStatus,
          percent: p.percent,
          step: p.stepLabel,
          url: p.htmlUrl,
          diagnostics: p.diagnostics,
        );

        if (p.finished) {
          await _finish(service, rec);
          return;
        }
      }

      await BuildStore.saveCurrent(rec);
      service.invoke('update', rec.toJson());
      await _publish(rec);
    } catch (e) {
      debugPrint('Polling error: $e'); // ✅ Sekarang bisa dipakai
    }

    await Future<void>.delayed(const Duration(seconds: 6));
  }
}

Future<void> _publish(BuildRecord rec) {
  return NotificationService.showProgress(
    title: 'Build ${rec.typeLabel} • ${rec.repo}',
    body: rec.step.isEmpty ? 'Menunggu runner GitHub...' : rec.step,
    percent: rec.percent,
    indeterminate: rec.percent == 0,
  );
}

Future<void> _finish(ServiceInstance service, BuildRecord rec) async {
  final done = rec.copyWith(
    finishedAt: DateTime.now().millisecondsSinceEpoch,
    percent: rec.isSuccess ? 100 : rec.percent,
    status: rec.isSuccess ? 'success' : 'failure',
  );

  await BuildStore.appendHistory(done);
  await BuildStore.clearCurrent();
  await NotificationService.cancelProgress();
  await NotificationService.showDone(
    title: done.isSuccess ? 'Build selesai ✅' : 'Build gagal ❌',
    body: done.isSuccess
        ? '${done.typeLabel} • ${done.repo} berhasil dibuild. Ketuk untuk melihat.'
        : '${done.typeLabel} • ${done.repo} ${done.statusLabel.toLowerCase()}. Ketuk untuk melihat detail.',
  );
  service.invoke('update', done.toJson());
  service.stopSelf();
}