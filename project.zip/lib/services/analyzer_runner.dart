import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';

import 'artifact_service.dart';
import 'github_actions.dart';
import 'github_api_exception.dart';
import 'github_uploader.dart';
import 'upload_tracker.dart';

class AnalyzerRunResult {
  const AnalyzerRunResult({
    required this.findings,
    required this.steps,
    this.kind,
    this.error,
    this.runUrl,
  });

  final List<Map<String, dynamic>> findings;
  final List<Map<String, dynamic>> steps;
  final String? kind;
  final String? error;
  final String? runUrl;
}

/// Menjalankan workflow analyzer.yml: upload ZIP, picu, pantau, lalu baca laporan JSON-nya.
class AnalyzerRunner {
  static const String workflowName = 'analyzer.yml';
  static const String _assetPath = 'assets/workflows/analyzer.yml';

  static Future<AnalyzerRunResult> run({
    required String token,
    required String owner,
    required String repo,
    required String zipPath,
    required bool deep,
    required UploadTracker upload,
    required void Function(int percent, String label) onProgress,
    required bool Function() cancelled,
  }) async {
    upload.begin('Analyzer • $owner/$repo', const [
      'Menyiapkan repository',
      'Mengunggah project.zip',
      'Mengunggah analyzer.yml & commit',
      'Menunggu workflow siap',
      'Memicu analisis',
    ]);

    final api = GitHubActions(token);
    RunInfo? run;

    try {
      final content = await rootBundle.loadString(_assetPath);
      final uploader = GitHubUploader(token, owner, repo);

      upload.startStep(0, detail: '$owner/$repo');
      await uploader.ensureRepoExists();

      final zipSize = await File(zipPath).length();
      String mb(num bytes) => (bytes / (1024 * 1024)).toStringAsFixed(1);
      upload.startStep(1, detail: '0.0 / ${mb(zipSize)} MB', withPercent: true);

      final branch = await uploader.uploadZipWithWorkflow(
        zipPath: zipPath,
        workflowFileName: workflowName,
        workflowContent: content,
        commitMessage: 'Santanic Build: upload project.zip + analyzer',
        onFileProgress: (file, f, sent, total) =>
            upload.setFraction(f, '${mb(zipSize * f)} / ${mb(zipSize)} MB'),
        onFilesDone: () => upload.startStep(2, detail: workflowName),
      );

      upload.startStep(3, detail: workflowName);
      final ready = await api.waitForWorkflowReady(owner, repo, workflowName);
      if (!ready) {
        throw GitHubApiException(
          404,
          'Workflow $workflowName tidak terdeteksi di GitHub. Pastikan Actions aktif di repo, lalu coba lagi.',
        );
      }

      final baseline = await api.latestRunId(owner, repo, workflowName);

      upload.startStep(4, detail: deep ? 'mendalam' : 'standar');
      await api.triggerWorkflow(
        owner,
        repo,
        workflowName,
        branch,
        inputs: {'deep': deep ? 'true' : 'false'},
      );
      upload.complete();

      // Cari run yang baru dibuat.
      onProgress(0, 'Menunggu runner GitHub...');
      var tries = 0;
      while (run == null) {
        if (cancelled()) return _cancelled();
        run = await api.findRun(owner, repo, workflowName, baseline);
        if (run == null) {
          if (++tries > 40) {
            throw GitHubApiException(404, 'Run analyzer tidak ditemukan di GitHub setelah 3 menit.');
          }
          await Future<void>.delayed(const Duration(seconds: 5));
        }
      }

      // Pantau sampai selesai.
      BuildProgress? last;
      var errors = 0;
      final deadline = DateTime.now().add(const Duration(minutes: 45));
      while (true) {
        if (cancelled()) {
          try {
            await api.cancelRun(owner, repo, run.id);
          } catch (_) {}
          return _cancelled(runUrl: run.htmlUrl);
        }
        if (DateTime.now().isAfter(deadline)) {
          throw GitHubApiException(0, 'Analisis melewati batas waktu 45 menit.');
        }
        try {
          final p = await api.progress(owner, repo, run.id);
          errors = 0;
          last = p;
          onProgress(p.percent, p.stepLabel);
          if (p.finished) break;
        } catch (_) {
          if (++errors >= 12) rethrow;
        }
        await Future<void>.delayed(const Duration(seconds: 5));
      }

      // Baca laporan.
      final text = await ArtifactService(token).fetchTextFile(
        owner: owner,
        repo: repo,
        runId: run.id,
        artifactNameContains: 'analyzer-report',
        fileName: 'analysis-report.json',
      );

      if (text != null) {
        final data = jsonDecode(text);
        if (data is Map) {
          return AnalyzerRunResult(
            findings: _maps(data['findings']),
            steps: _maps(data['steps']),
            kind: data['kind']?.toString(),
            runUrl: last.htmlUrl,
          );
        }
      }

      // Laporan tidak ada: ambil cuplikan log job yang gagal.
      var detail = 'Laporan analisis tidak dibuat oleh workflow.';
      final jobId = last.failedJobId ?? (last.jobs.isEmpty ? null : (last.jobs.first['id'] as num?)?.toInt());
      if (jobId != null) {
        final tail = await api.jobLogTail(owner, repo, jobId, maxBytes: 6000);
        if (tail.isNotEmpty) {
          detail = tail.length > 1500 ? tail.substring(tail.length - 1500) : tail;
        }
      }
      return AnalyzerRunResult(
        findings: [
          {
            'sev': 'error',
            'title': 'Workflow analyzer gagal berjalan',
            'detail': detail,
            'file': null,
            'line': null,
          }
        ],
        steps: const [],
        runUrl: last.htmlUrl,
      );
    } catch (e) {
      upload.fail(e.toString().replaceFirst('Exception: ', ''));
      rethrow;
    }
  }

  static AnalyzerRunResult _cancelled({String? runUrl}) => AnalyzerRunResult(
        findings: const [],
        steps: const [],
        error: 'Analisis dibatalkan.',
        runUrl: runUrl,
      );

  static List<Map<String, dynamic>> _maps(dynamic v) {
    if (v is! List) return const [];
    return v.whereType<Map>().map((m) => m.map((k, val) => MapEntry(k.toString(), val))).toList();
  }
}
