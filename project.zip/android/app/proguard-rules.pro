# ==============================================
# Flutter Background Service
# ==============================================
-keep class id.flutter.flutter_background_service.** { *; }
-keep class id.flutter.flutter_background_service_android.** { *; }
-keep class id.flutter.flutter_background_service_plugin.** { *; }

# ==============================================
# Flutter Secure Storage
# ==============================================
-keep class com.it_nomads.fluttersecurestorage.** { *; }
-keep class androidx.security.crypto.** { *; }

# ==============================================
# Flutter Local Notifications
# ==============================================
-keep class com.dexterous.flutterlocalnotifications.** { *; }

# ==============================================
# File Picker & URL Launcher
# ==============================================
-keep class com.mr.flutter.plugin.filepicker.** { *; }
-keep class io.flutter.plugins.urllauncher.** { *; }

# ==============================================
# Battery Plus & Device Info Plus
# ==============================================
-keep class dev.fluttercommunity.plus.battery.** { *; }
-keep class dev.fluttercommunity.plus.device_info.** { *; }

# ==============================================
# HTTP Client (dart:io)
# ==============================================
-dontwarn okhttp3.**
-dontwarn okio.**

# ==============================================
# Preserve Line Numbers (untuk debugging crash)
# ==============================================
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile