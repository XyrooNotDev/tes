import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SessionManager {
  SessionManager._(this._prefs, this._secure);

  static const String kToken = 'github_token';
  static const String kUsername = 'github_username';
  static const String kIsLogin = 'is_login';

  static const String _kSecureToken = 'secure_github_token';

  final SharedPreferences _prefs;
  final FlutterSecureStorage _secure;

  static const _secureOptions = AndroidOptions(
    encryptedSharedPreferences: true,
  );

  static Future<SessionManager> load() async {
    final prefs = await SharedPreferences.getInstance();
    const secure = FlutterSecureStorage(aOptions: _secureOptions);
    return SessionManager._(prefs, secure);
  }

  Future<String> getToken() async {
    return await _secure.read(key: _kSecureToken) ?? _prefs.getString(kToken) ?? '';
  }

  String get username => _prefs.getString(kUsername) ?? 'User';

  Future<bool> get isLoggedIn async {
    final token = await getToken();
    return (_prefs.getBool(kIsLogin) ?? false) && token.isNotEmpty;
  }

  Future<void> saveSession(String token, String username) async {
    await _secure.write(key: _kSecureToken, value: token);
    // Mirror token for the background service isolate; secure storage remains primary.
    await _prefs.setString(kToken, token);
    await _prefs.setString(kUsername, username);
    await _prefs.setBool(kIsLogin, true);
  }

  Future<void> logout() async {
    await _secure.delete(key: _kSecureToken);
    await _prefs.remove(kToken);
    await _prefs.remove(kUsername);
    await _prefs.remove(kIsLogin);
  }
}