import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/build_record.dart';

class BuildStore {
  static const String _kCurrent = 'current_build';
  static const String _kHistory = 'build_history';
  static const int _maxHistory = 50;

  static Future<SharedPreferences> _fresh() async {
    final p = await SharedPreferences.getInstance();
    await p.reload();
    return p;
  }

  static Future<BuildRecord?> loadCurrent() async {
    final raw = (await _fresh()).getString(_kCurrent);
    if (raw == null) return null;
    try {
      return BuildRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      await clearCurrent();
      return null;
    }
  }

  static Future<void> saveCurrent(BuildRecord r) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kCurrent, jsonEncode(r.toJson()));
  }

  static Future<void> clearCurrent() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kCurrent);
  }

  static Future<List<BuildRecord>> loadHistory() async {
    final raw = (await _fresh()).getString(_kHistory);
    if (raw == null) return [];
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => BuildRecord.fromJson(e as Map<String, dynamic>))
          .toList();
      // ✅ FIX: Gunakan startedAt, bukan createdAt
      list.sort((a, b) => b.startedAt.compareTo(a.startedAt));
      return list;
    } catch (_) {
      return [];
    }
  }

  static Future<void> appendHistory(BuildRecord r) async {
    final list = await loadHistory();
    list.removeWhere((e) => e.id == r.id);
    list.insert(0, r);
    final trimmedList = list.take(_maxHistory).toList();

    final p = await SharedPreferences.getInstance();
    await p.setString(
      _kHistory,
      jsonEncode(trimmedList.map((e) => e.toJson()).toList()),
    );
  }

  static Future<void> clearHistory() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kHistory);
  }
}