import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'github_api_exception.dart';

class RunInfo {
  const RunInfo(this.id, this.htmlUrl);
  final int id;
  final String? htmlUrl;
}

class BuildProgress {
  const BuildProgress({
    required this.status,
    required this.conclusion,
    required this.htmlUrl,
    required this.done,
    required this.total,
    required this.current,
    this.diagnostics = const [],
  });

  final String status;
  final String? conclusion;
  final String? htmlUrl;
  final int done;
  final int total;
  final String current;
  final List<String> diagnostics;

  bool get finished => status == 'completed';

  String get finalStatus {
    if (conclusion == 'success') return 'success';
    if (conclusion == 'cancelled') return 'cancelled';
    return 'failure';
  }

  int get percent {
    if (finished) return 100;
    if (total == 0) return 0;
    return (done * 100 ~/ total).clamp(0, 99);
  }

  String get stepLabel {
    if (status == 'queued') return 'Mengantre di GitHub...';
    if (total == 0) return 'Menyiapkan runner...';
    final name = current.isEmpty ? 'Menyelesaikan' : current;
    return '$name ($done/$total)';
  }
}

class GitHubActions {
  GitHubActions(this.token);

  final String token;

  static const Duration _timeout = Duration(seconds: 20);

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  Uri _u(String owner, String repo, String path, [Map<String, String>? query]) =>
      Uri.https('api.github.com', '/repos/$owner/$repo$path', query);

  dynamic _ok(http.Response r, [String? what]) {
    if (r.statusCode >= 200 && r.statusCode < 300) {
      return r.body.isEmpty ? <String, dynamic>{} : jsonDecode(r.body);
    }
    var msg = r.reasonPhrase ?? '';
    try {
      msg = (jsonDecode(r.body) as Map<String, dynamic>)['message'] as String? ?? msg;
    } catch (_) {}
    throw GitHubApiException(r.statusCode, what != null ? '$what: $msg' : msg);
  }

  Future<void> triggerWorkflow(
  String owner,
  String repo,
  String workflow,
  String branch, {
  Map<String, String> inputs = const {},
}) async {
  final body = <String, dynamic>{'ref': branch};
  if (inputs.isNotEmpty) body['inputs'] = inputs;

  GitHubApiException? last;
  for (var i = 0; i < 4; i++) {
    try {
      final res = await http
          .post(
            _u(owner, repo, '/actions/workflows/$workflow/dispatches'),
            headers: {..._headers, 'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(_timeout);

      if (res.statusCode == 204 || res.statusCode == 200) return;
      _ok(res);
    } on GitHubApiException catch (e) {
      last = e;
      if (e.statusCode != 404 && e.statusCode != 422) rethrow;
    } catch (e) {
      last = GitHubApiException(0, 'Koneksi gagal: $e');
    }
    await Future<void>.delayed(const Duration(seconds: 3));
  }
  throw last ?? GitHubApiException(0, 'Gagal memicu workflow');
}

  Future<int> latestRunId(String owner, String repo, String workflow) async {
  try {
    final r = await http.get(
      _u(owner, repo, '/actions/workflows/$workflow/runs',
          {'event': 'workflow_dispatch', 'per_page': '1'}),
      headers: _headers,
    ).timeout(_timeout);

    if (r.statusCode != 200) {
      debugPrint('latestRunId: HTTP ${r.statusCode}');
      return 0;
    }

    final body = _ok(r) as Map<String, dynamic>;
    final runs = (body['workflow_runs'] as List).cast<Map<String, dynamic>>();
    if (runs.isEmpty) return 0;
    return (runs.first['id'] as num).toInt();
  } catch (e) {
    debugPrint('latestRunId error: $e');
    return 0;
  }
}

  Future<RunInfo?> findRun(
    String owner,
    String repo,
    String workflow,
    int baseline,
  ) async {
    final r = await http
        .get(
          _u(owner, repo, '/actions/workflows/$workflow/runs',
              {'event': 'workflow_dispatch', 'per_page': '10'}),
          headers: _headers,
        )
        .timeout(_timeout);

    final body = _ok(r) as Map<String, dynamic>;
    final runs = (body['workflow_runs'] as List).cast<Map<String, dynamic>>();

    RunInfo? best;
    for (final m in runs) {
      final id = (m['id'] as num).toInt();
      if (id > baseline && (best == null || id < best.id)) {
        best = RunInfo(id, m['html_url'] as String?);
      }
    }
    return best;
  }
  
  Future<void> triggerWorkflowWithInputs(
  String owner,
  String repo,
  String workflow,
  String branch,
  Map<String, String> inputs,
) async {
  final res = await http.post(
    _u(owner, repo, '/actions/workflows/$workflow/dispatches'),
    headers: {..._headers, 'Content-Type': 'application/json'},
    body: jsonEncode({'ref': branch, 'inputs': inputs}),
  ).timeout(_timeout);

  if (res.statusCode == 204 || res.statusCode == 200) return;
  _ok(res, 'Gagal memicu workflow');
}

  Future<bool> waitForWorkflowReady(
  String owner,
  String repo,
  String workflow, {
  int maxRetries = 12,
}) async {
  for (var i = 0; i < maxRetries; i++) {
    try {
      final res = await http.get(
        _u(owner, repo, '/actions/workflows/$workflow'),
        headers: _headers,
      ).timeout(_timeout);

      if (res.statusCode == 200) {
        debugPrint('Workflow $workflow siap (percobaan ${i + 1})');
        return true;
      }
      debugPrint('Workflow belum siap (percobaan ${i + 1}/${maxRetries}): ${res.statusCode}');
    } catch (e) {
      debugPrint('Error cek workflow: $e');
    }
    await Future<void>.delayed(const Duration(seconds: 5));
  }
  return false;
}

  Future<BuildProgress> progress(String owner, String repo, int runId) async {
    final runJson = _ok(
      await http
          .get(_u(owner, repo, '/actions/runs/$runId'), headers: _headers)
          .timeout(_timeout),
    ) as Map<String, dynamic>;

    final status = runJson['status'] as String? ?? 'queued';
    var total = 0;
    var done = 0;
    var current = '';
    final diagnostics = <String>[];

    if (status != 'queued') {
      final jobsJson = _ok(
        await http
            .get(
              _u(owner, repo, '/actions/runs/$runId/jobs', {'per_page': '30'}),
              headers: _headers,
            )
            .timeout(_timeout),
      ) as Map<String, dynamic>;

      for (final job in (jobsJson['jobs'] as List).cast<Map<String, dynamic>>()) {
        final jobName = job['name'] as String? ?? 'Job';
        final jobConclusion = job['conclusion'] as String?;

        if (jobConclusion == 'failure' || jobConclusion == 'cancelled') {
          diagnostics.add(
            'JOB GAGAL: $jobName (${(jobConclusion ?? 'unknown').toUpperCase()})',
          );
          final jobUrl = job['html_url'] as String?;
          if (jobUrl != null) diagnostics.add('Detail job: $jobUrl');
        }

        for (final step
            in ((job['steps'] as List?) ?? const []).cast<Map<String, dynamic>>()) {
          total++;
          final st = step['status'] as String?;
          if (st == 'completed') {
            done++;
            if (step['conclusion'] == 'failure') {
              diagnostics.add('STEP ERROR: $jobName / ${step['name'] ?? 'Step'}');
            }
          } else if (st == 'in_progress' && current.isEmpty) {
            current = step['name'] as String? ?? '';
          }
        }
      }
    }

    return BuildProgress(
      status: status,
      conclusion: runJson['conclusion'] as String?,
      htmlUrl: runJson['html_url'] as String?,
      done: done,
      total: total,
      current: current,
      diagnostics: diagnostics,
    );
  }

  Future<void> cancelRun(String owner, String repo, int runId) async {
    final res = await http
        .post(
          _u(owner, repo, '/actions/runs/$runId/cancel'),
          headers: _headers,
        )
        .timeout(_timeout);

    if (res.statusCode == 202) return;
    _ok(res, 'Gagal membatalkan build');
  }
}