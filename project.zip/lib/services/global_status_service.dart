import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'build_store.dart';
import 'github_actions.dart';

/// Build milik pengguna lain yang sedang berjalan / mengantre.
class ActiveRun {
  const ActiveRun({
    required this.repo,
    required this.name,
    required this.percent,
    required this.step,
    required this.queued,
  });

  final String repo;
  final String name;
  final int percent;
  final String step;
  final bool queued;
}

class UserBuildStats {
  UserBuildStats(this.login);

  final String login;
  final Set<String> repos = {};
  int success = 0;
  int failure = 0;
  int queued = 0;
  int running = 0;

  /// Repo yang punya build berjalan / antri, dan detail progress-nya.
  final Set<String> activeRepos = {};
  List<ActiveRun> active = [];

  int get total => success + failure + queued + running;
}

/// Statistik build SEMUA pengguna Santanic Build (bukan hanya akun sendiri).
///
/// Pengguna ditemukan lewat pencarian commit publik GitHub berpesan "Santanic Build"
/// (pesan commit bawaan aplikasi saat upload), ditambah repo milik akun ini dari riwayat.
/// Hanya repository publik (plus repo sendiri) yang bisa dihitung.
class GlobalStatusService extends ChangeNotifier {
  GlobalStatusService({required this.token});

  final String token;

  static const int _maxRepos = 80;
  static const int _searchPages = 4;

  bool loading = false;
  String? error;
  String phase = '';
  int doneRepos = 0;
  int totalRepos = 0;
  DateTime? updatedAt;
  List<UserBuildStats> users = [];
  bool _disposed = false;

  int get totalSuccess => users.fold(0, (a, u) => a + u.success);
  int get totalFailure => users.fold(0, (a, u) => a + u.failure);
  int get totalQueued => users.fold(0, (a, u) => a + u.queued);
  int get totalRunning => users.fold(0, (a, u) => a + u.running);

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  Future<void> load() async {
    if (loading) return;
    loading = true;
    error = null;
    users = [];
    doneRepos = 0;
    totalRepos = 0;
    phase = 'Mencari pengguna Santanic Build...';
    _notify();

    try {
      final repos = await _discoverRepos();
      totalRepos = repos.length;
      phase = 'Memeriksa status build...';
      _notify();

      final map = <String, UserBuildStats>{};
      var next = 0;

      Future<void> worker() async {
        while (true) {
          final i = next++;
          if (i >= repos.length) return;
          final full = repos[i];
          final owner = full.split('/').first;
          final counts = await _countRepo(full);
          doneRepos++;
          if (counts != null) {
            final u = map.putIfAbsent(owner.toLowerCase(), () => UserBuildStats(owner));
            u.repos.add(full);
            u.success += counts[0];
            u.failure += counts[1];
            u.queued += counts[2];
            u.running += counts[3];
            if (counts[2] + counts[3] > 0) u.activeRepos.add(full);
          }
          users = map.values.where((u) => u.total > 0).toList()
            ..sort((a, b) => b.total.compareTo(a.total));
          _notify();
        }
      }

      await Future.wait(List.generate(5, (_) => worker()));
      phase = 'Memuat progress build...';
      _notify();
      await _loadActiveFor(users);
      updatedAt = DateTime.now();
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      loading = false;
      phase = '';
      _notify();
    }
  }

  bool get hasActive => users.any((u) => u.activeRepos.isNotEmpty);

  /// Muat ulang hanya progress build aktif (ringan; dipanggil berkala saat tab Status dibuka).
  Future<void> refreshActive() async {
    if (loading) return;
    await _loadActiveFor(users);
    _notify();
  }

  Future<void> _loadActiveFor(List<UserBuildStats> list) async {
    final targets = list.where((u) => u.activeRepos.isNotEmpty).toList();
    var next = 0;
    Future<void> worker() async {
      while (true) {
        final i = next++;
        if (i >= targets.length) return;
        final u = targets[i];
        final runs = <ActiveRun>[];
        for (final repo in u.activeRepos.take(3)) {
          runs.addAll(await _fetchActiveRuns(repo));
        }
        u.active = runs;
        _notify();
      }
    }

    await Future.wait(List.generate(3, (_) => worker()));
  }

  Future<List<ActiveRun>> _fetchActiveRuns(String full) async {
    final out = <ActiveRun>[];
    final parts = full.split('/');
    if (parts.length != 2) return out;
    final api = GitHubActions(token);

    for (final status in const ['in_progress', 'queued']) {
      try {
        final uri = Uri.https('api.github.com', '/repos/$full/actions/runs', {
          'status': status,
          'event': 'workflow_dispatch',
          'per_page': '3',
        });
        final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 20));
        if (res.statusCode != 200) continue;
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final runs = (body['workflow_runs'] as List?) ?? const [];
        for (final r in runs) {
          if (r is! Map) continue;
          final id = (r['id'] as num?)?.toInt();
          if (id == null) continue;
          final name = (r['name'] ?? r['display_title'] ?? 'Build').toString();
          if (status == 'queued') {
            out.add(ActiveRun(repo: full, name: name, percent: 0, step: 'Mengantre di GitHub', queued: true));
            continue;
          }
          try {
            final p = await api.progress(parts[0], parts[1], id);
            out.add(ActiveRun(
              repo: full,
              name: name,
              percent: p.percent,
              step: p.stepLabel,
              queued: p.status == 'queued',
            ));
          } catch (_) {
            out.add(ActiveRun(repo: full, name: name, percent: 0, step: 'Berjalan', queued: false));
          }
        }
      } catch (_) {}
    }
    return out;
  }

  Future<List<String>> _discoverRepos() async {
    final found = <String>[];
    final seen = <String>{};

    void add(String full) {
      if (full.contains('/') && seen.add(full.toLowerCase())) found.add(full);
    }

    // Repo milik akun ini (termasuk privat) dari riwayat build.
    for (final r in await BuildStore.loadHistory()) {
      add('${r.owner}/${r.repo}');
    }

    String? searchError;
    outer:
    for (var page = 1; page <= _searchPages; page++) {
      final uri = Uri.https('api.github.com', '/search/commits', {
        'q': '"Santanic Build"',
        'sort': 'committer-date',
        'order': 'desc',
        'per_page': '100',
        'page': '$page',
      });
      final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 30));
      if (res.statusCode != 200) {
        if (res.statusCode == 401) {
          throw Exception('Token GitHub tidak valid. Silakan login ulang.');
        }
        if (res.statusCode == 403 || res.statusCode == 429) {
          searchError = 'Batas pencarian GitHub tercapai. Coba lagi 1 menit lagi.';
        } else {
          searchError = 'Pencarian pengguna gagal (HTTP ${res.statusCode}).';
        }
        break;
      }
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      final items = (body['items'] as List?) ?? const [];
      if (items.isEmpty) break;
      for (final it in items) {
        if (it is! Map) continue;
        final repo = it['repository'];
        if (repo is Map && repo['full_name'] is String) {
          add(repo['full_name'] as String);
          if (found.length >= _maxRepos) break outer;
        }
      }
      if (items.length < 100) break;
    }

    if (found.isEmpty && searchError != null) throw Exception(searchError);
    return found;
  }

  /// [berhasil, gagal, antrian, berjalan] untuk run workflow_dispatch; null = repo tidak bisa diakses.
  Future<List<int>?> _countRepo(String full) async {
    Future<int?> count(String status) async {
      try {
        final uri = Uri.https('api.github.com', '/repos/$full/actions/runs', {
          'status': status,
          'event': 'workflow_dispatch',
          'per_page': '1',
        });
        final res = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 20));
        if (res.statusCode == 200) {
          final body = jsonDecode(res.body) as Map<String, dynamic>;
          return (body['total_count'] as num?)?.toInt() ?? 0;
        }
        if (res.statusCode == 404 || res.statusCode == 403) return null;
        return 0;
      } catch (_) {
        return 0;
      }
    }

    final results = await Future.wait([
      count('success'),
      count('failure'),
      count('queued'),
      count('in_progress'),
    ]);
    if (results.every((e) => e == null)) return null;
    return results.map((e) => e ?? 0).toList();
  }
}
