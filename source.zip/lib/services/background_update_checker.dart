import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'update_service.dart';
import '../nav.dart';

class BackgroundUpdateChecker {
  static Timer? _timer;
  static UpdateInfo? _lastFound;

  static UpdateInfo? get lastFound => _lastFound;

  static Future<void> start({Duration interval = const Duration(hours: 6)}) async {
    _checkNow();

    _timer?.cancel();
    _timer = Timer.periodic(interval, (_) => _checkNow());
  }

  static void stop() {
    _timer?.cancel();
    _timer = null;
  }

  static Future<void> _checkNow() async {
    try {
      final info = await UpdateService.checkUpdate();
      if (info == null || !info.hasUpdate) return;

      _lastFound = info;

      await _showNotification(info);
    } catch (e) {
      debugPrint('Background update check error: $e');
    }
  }

  static Future<void> _showNotification(UpdateInfo info) async {
    final plugin = FlutterLocalNotificationsPlugin();

    const androidDetails = AndroidNotificationDetails(
      'app_update',
      'Update Aplikasi',
      channelDescription: 'Notifikasi jika ada versi baru Santanic Build',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@drawable/ic_stat_build',
      color: Color(0xFFFF1A1A),
      autoCancel: true,
    );

    await plugin.show(
      9999,
      '🚀 Update Tersedia (v${info.latestVersion})',
      'Versi baru Santanic Build sudah tersedia. Ketuk untuk update.',
      const NotificationDetails(android: androidDetails),
      payload: 'app:update',
    );
  }

  static void onUpdateNotifTapped() {
    AppNav.tabIndex.value = AppNav.profileTab;
  }
}