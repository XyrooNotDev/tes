# Santanic Build

Aplikasi Android (Flutter) untuk membangun APK lewat GitHub Actions langsung dari HP.

## Fitur
- Login GitHub, pilih repository, upload ZIP project (Android Studio / Flutter) atau buat APK dari website (WebToAPK).
- Workflow bawaan di `assets/workflows/`, atau upload file `.yml` sendiri (kecuali WebToAPK). ZIP disimpan sebagai `project.zip`.
- Hingga 3 build berjalan bersamaan (satu repository satu build), dipantau di latar belakang dengan notifikasi popup.
- Tab Progress: job, step, durasi, log; unduh dan install APK langsung dari aplikasi.
- Status: statistik dan progress build semua pengguna (repository publik).
- Alat Project: Analyzer (cek error ZIP sebelum build) dan Ganti Icon / Nama / Domain / Rename Semua.
- Pembaruan aplikasi dibaca dari `latest.json` dan APK pada GitHub Release.

## Build
```
flutter pub get
flutter build apk --release --split-per-abi --target-platform android-arm,android-arm64
```
Workflow CI: `.github/workflows/build.yml`. Pastikan folder `android/app/src/main/kotlin` ikut ter-ZIP
(berisi `MainActivity` dan `SantanicApplication` yang dirujuk manifest).

## Catatan
- Token GitHub tidak disimpan di source code.
- Hanya repository publik (dan repository sendiri) yang tampil di Status.
