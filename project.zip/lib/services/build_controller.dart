import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

import '../models/build_record.dart';
import 'artifact_service.dart';
import 'build_store.dart';
import 'build_tracker.dart';
import 'github_actions.dart';
import 'notification_service.dart';
import 'session_manager.dart';
import 'upload_tracker.dart';

class BuildController extends ChangeNotifier {
  BuildController({required this.session});

  final SessionManager session;

  /// Progress UPLOAD (ZIP/workflow/trigger) — terpisah dari progress build.
  final UploadTracker upload = UploadTracker();

  /// Maksimal build yang boleh berjalan bersamaan.
  static const int maxConcurrent = 3;

  List<BuildRecord> active = [];
  List<BuildRecord> history = [];
  StreamSubscription<dynamic>? _sub;
  Timer? _healTimer;

  // Mode aman: pelacak berjalan di dalam app (tanpa foreground service).
  bool _inApp = false;
  bool _inAppStop = false;
  final Set<String> _prevActiveIds = {};

  // Unduhan manual dari UI (tombol Unduh / Unduh ulang)
  bool downloading = false;
  double downloadProgress = 0;
  String? downloadingId;

  /// Analisis terbaru (aktif atau selesai) untuk ditampilkan di layar Analyzer.
  BuildRecord? get latestAnalyzer {
    for (final r in active.reversed) {
      if (r.isAnalyzer) return r;
    }
    for (final r in history) {
      if (r.isAnalyzer) return r;
    }
    return null;
  }

  BuildRecord? get current => active.isEmpty ? null : active.first;
  int get activeCount => active.where((r) => !r.isFinished).length;
  bool get isRunning => activeCount > 0;
  bool get canStartNew => activeCount < maxConcurrent;

  /// Satu repo hanya boleh punya satu build aktif (upload project.zip menimpa file yang sama).
  bool repoBusy(String owner, String repo) => active.any((r) =>
      !r.isFinished &&
      r.owner.toLowerCase() == owner.toLowerCase() &&
      r.repo.toLowerCase() == repo.toLowerCase());

  /// Yang ditampilkan di kartu progress: build aktif terbaru, kalau tidak ada maka build terakhir.
  BuildRecord? get display =>
      active.isNotEmpty ? active.last : (history.isEmpty ? null : history.first);

  BuildRecord? byId(String id) {
    for (final a in active) {
      if (a.id == id) return a;
    }
    for (final h in history) {
      if (h.id == id) return h;
    }
    return null;
  }

  Future<void> init() async {
    await reload();
    _sub = FlutterBackgroundService().on('update').listen((_) => reload());
  }

  Future<void> reload() async {
    active = await BuildStore.loadActive();
    history = await BuildStore.loadHistory();
    notifyListeners();
    await _notifyIfJustFinished();
    _syncHealTimer();

    if (isRunning) {
      await _ensureTracking();
      return;
    }

    // Unduhan latar belakang yang terhenti (service sudah mati) ditandai gagal supaya bisa diulang.
    if (!downloading && !_inApp) {
      final stuck = history.where((r) => r.downloadState == 'downloading').toList();
      if (stuck.isNotEmpty) {
        var serviceRunning = false;
        try {
          serviceRunning = await FlutterBackgroundService().isRunning();
        } catch (_) {}
        if (!serviceRunning) {
          for (final r in stuck) {
            await BuildStore.appendHistory(r.copyWith(
              downloadState: 'failed',
              downloadError: 'Unduhan terhenti. Ketuk "Unduh ulang".',
            ));
          }
          history = await BuildStore.loadHistory();
          notifyListeners();
        }
      }
    }
  }

  /// Penjaga: selama ada build aktif, pastikan pelacak (service / dalam app) hidup.
  void _syncHealTimer() {
    if (isRunning) {
      _healTimer ??= Timer.periodic(const Duration(seconds: 10), (_) => _ensureTracking());
    } else {
      _healTimer?.cancel();
      _healTimer = null;
    }
  }

  Future<void> _ensureTracking() async {
    if (!isRunning) return;
    if (await BuildTracker.serviceEnabled()) {
      var running = false;
      try {
        running = await FlutterBackgroundService().isRunning();
      } catch (_) {}
      if (!running) await _startServiceSafely();
    } else if (!_inApp) {
      unawaited(_runInApp());
    }
  }

  /// Cadangan: kalau build baru saja selesai dan app terbuka, pastikan popup hasil muncul.
  /// ID notifikasi sama dengan yang dipakai service, jadi tidak muncul dobel.
  Future<void> _notifyIfJustFinished() async {
    final nowIds = active.where((r) => !r.isFinished).map((r) => r.id).toSet();
    final gone = _prevActiveIds.difference(nowIds);
    _prevActiveIds
      ..clear()
      ..addAll(nowIds);

    for (final id in gone) {
      final r = byId(id);
      if (r == null || !r.isFinished || r.isAnalyzer) continue;
      try {
        if (r.isSuccess) {
          await NotificationService.showDone(
            buildKey: r.id,
            title: 'Build selesai ✅',
            body: '${r.typeLabel} • ${r.repo} berhasil dibuild.',
          );
        } else if (r.status == 'cancelled') {
          // dibatalkan pengguna: tanpa popup
        } else {
          await NotificationService.showDone(
            buildKey: r.id,
            title: 'Build gagal ❌',
            body: '${r.typeLabel} • ${r.repo} gagal. Ketuk untuk melihat detail.',
          );
        }
      } catch (e) {
        debugPrint('Notifikasi hasil gagal: $e');
      }
    }
  }

  /// Android 12+ melarang memulai foreground service dari latar belakang (bisa membuat app
  /// force close). Jadi service hanya dimulai saat app tampil di depan; kalau tidak,
  /// otomatis dimulai begitu app dibuka lagi (lihat [reload]).
  Future<void> _startServiceSafely() async {
    final state = WidgetsBinding.instance.lifecycleState;
    if (state != null && state != AppLifecycleState.resumed) return;
    try {
      await BuildTracker.start();
    } catch (e) {
      debugPrint('Gagal memulai service pelacak: $e');
    }
  }

  Future<void> _runInApp() async {
    if (_inApp) return;
    _inApp = true;
    _inAppStop = false;
    try {
      await trackBuild(
        invoke: (m, a) {
          if (m == 'update') unawaited(reload());
        },
        stopped: () => _inAppStop,
        background: false,
      );
    } catch (e) {
      debugPrint('Pelacak dalam app berhenti: $e');
    } finally {
      _inApp = false;
      await reload();
    }
  }

  Future<void> begin(BuildRecord rec) async {
    await BuildStore.upsertActive(rec);
    active = [...active.where((r) => r.id != rec.id), rec];
    _prevActiveIds.add(rec.id);
    notifyListeners();
    _syncHealTimer();

    // Popup langsung dari UI (pasti muncul, tidak bergantung pada service).
    try {
      await NotificationService.showStarted(
        title: rec.isAnalyzer ? 'Analisis dimulai 🔍' : 'Build dimulai 🚀',
        body: rec.isAnalyzer
            ? 'Memeriksa ${rec.repo} dengan analyzer.yml. Jika tidak ada error, build dilanjutkan otomatis.'
            : '${rec.typeLabel} • ${rec.repo}${rec.mode.isEmpty ? '' : ' (${rec.mode})'}. Pantau di tab Progress.',
      );
    } catch (e) {
      debugPrint('Notifikasi mulai gagal: $e');
    }

    await _ensureTracking();
  }

  /// Membatalkan salah satu build yang sedang berjalan.
  Future<void> cancelBuild(String id) async {
    BuildRecord? rec;
    for (final r in active) {
      if (r.id == id) rec = r;
    }
    if (rec == null || rec.isFinished || rec.runId == null) return;

    try {
      final token = await session.getToken();
      if (token.isEmpty) {
        throw Exception('Token tidak ditemukan, silakan login ulang.');
      }

      final api = GitHubActions(token);
      await api.cancelRun(rec.owner, rec.repo, rec.runId!);

      final cancelled = rec.copyWith(
        status: 'cancelled',
        step: 'Dibatalkan oleh pengguna',
        finishedAt: DateTime.now().millisecondsSinceEpoch,
      );

      await BuildStore.appendHistory(cancelled);
      await BuildStore.removeActive(id);
      _prevActiveIds.remove(id);
      await reload();
    } catch (e) {
      debugPrint('Gagal membatalkan build: $e');
      rethrow;
    }
  }

  /// Unduh artifact build → ekstrak APK ke penyimpanan aplikasi.
  Future<void> downloadApk(BuildRecord rec) async {
    if (downloading) return;
    downloading = true;
    downloadingId = rec.id;
    downloadProgress = 0;
    notifyListeners();

    var lastNotified = 0.0;
    try {
      final token = await session.getToken();
      if (token.isEmpty) throw Exception('Token tidak ditemukan, silakan login ulang.');

      final path = await ArtifactService(token).downloadApk(
        rec: rec,
        onProgress: (f) {
          downloadProgress = f;
          if (f - lastNotified >= 0.01 || f >= 1.0) {
            lastNotified = f;
            notifyListeners();
          }
        },
      );
      await BuildStore.appendHistory(rec.copyWith(
        apkPath: path,
        downloadState: 'done',
        downloadPercent: 100,
        downloadError: '',
      ));
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      await BuildStore.appendHistory(rec.copyWith(
        downloadState: 'failed',
        downloadError: msg,
      ));
      downloading = false;
      downloadingId = null;
      await reload();
      rethrow;
    }

    downloading = false;
    downloadingId = null;
    await reload();
  }

  Future<void> installApk(BuildRecord rec) async {
    final path = rec.apkPath;
    if (path == null || path.isEmpty) {
      throw Exception('APK belum diunduh.');
    }
    await ArtifactService.install(path);
  }

  /// Simpan APK ke folder publik Download/SantanicBuild. Mengembalikan lokasi file.
  Future<String> saveToDownloads(BuildRecord rec) async {
    final path = rec.apkPath;
    if (path == null || path.isEmpty) {
      throw Exception('APK belum diunduh.');
    }
    final name = '${rec.repo}_${rec.typeLabel.replaceAll(' ', '')}_${rec.mode.isEmpty ? 'build' : rec.mode}_${rec.runNumber ?? rec.id}.apk';
    return ArtifactService.saveToDownloads(path, name);
  }

  @override
  void dispose() {
    _sub?.cancel();
    _healTimer?.cancel();
    upload.dispose();
    super.dispose();
  }
}
