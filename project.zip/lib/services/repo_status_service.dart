import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class WorkflowRun {
  final String repo;
  final String workflowName;
  final String status;
  final String? conclusion;
  final String htmlUrl;
  final String? headBranch;
  final DateTime createdAt;
  final int runId;

  WorkflowRun({
    required this.repo,
    required this.workflowName,
    required this.status,
    required this.conclusion,
    required this.htmlUrl,
    required this.headBranch,
    required this.createdAt,
    required this.runId,
  });

  bool get isSuccess => conclusion == 'success';
  bool get isFailure => conclusion == 'failure' || conclusion == 'cancelled';
  bool get isQueued => status == 'queued';
  bool get isRunning => status == 'in_progress';
  bool get isFinished => status == 'completed';

  String get statusLabel {
    if (isQueued) return 'Antrian';
    if (isRunning) return 'Berjalan';
    if (isSuccess) return 'Berhasil';
    if (isFailure) return 'Gagal';
    return status;
  }

  factory WorkflowRun.fromJson(Map<String, dynamic> j, String repo) {
    return WorkflowRun(
      repo: repo,
      workflowName: j['name'] as String? ?? 'Workflow',
      status: j['status'] as String? ?? 'queued',
      conclusion: j['conclusion'] as String?,
      htmlUrl: j['html_url'] as String? ?? '',
      headBranch: j['head_branch'] as String?,
      createdAt: DateTime.tryParse(j['created_at'] as String? ?? '') ?? DateTime.now(),
      runId: (j['id'] as num?)?.toInt() ?? 0,
    );
  }
}

class RepoStatusService extends ChangeNotifier {
  RepoStatusService({required this.token});

  final String token;

  static const Duration _timeout = Duration(seconds: 20);

  List<String> _repos = [];
  List<WorkflowRun> _runs = [];
  bool _loading = false;
  String? _error;

  List<String> get repos => _repos;
  List<WorkflowRun> get runs => _runs;
  bool get loading => _loading;
  String? get error => _error;

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  Future<void> loadRepos() async {
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/user/repos?per_page=100&sort=updated'),
        headers: _headers,
      ).timeout(_timeout);

      if (res.statusCode != 200) {
        _error = 'Gagal ambil repo (HTTP ${res.statusCode})';
        return;
      }

      final list = (jsonDecode(res.body) as List).cast<Map<String, dynamic>>();
      _repos = list.map((e) => e['full_name'] as String).toList();
    } catch (e) {
      _error = e.toString();
    }
    notifyListeners();
  }

  Future<void> loadAllRuns() async {
    _loading = true;
    _error = null;
    notifyListeners();

    final allRuns = <WorkflowRun>[];

    for (final repo in _repos) {
      try {
        final res = await http.get(
          Uri.parse('https://api.github.com/repos/$repo/actions/runs?per_page=10'),
          headers: _headers,
        ).timeout(_timeout);

        if (res.statusCode == 200) {
          final data = jsonDecode(res.body) as Map<String, dynamic>;
          final runs = (data['workflow_runs'] as List?) ?? [];
          for (final r in runs) {
            allRuns.add(WorkflowRun.fromJson(r as Map<String, dynamic>, repo));
          }
        }
      } catch (_) {}
    }

    allRuns.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    _runs = allRuns;
    _loading = false;
    notifyListeners();
  }

  int get totalSuccess => _runs.where((r) => r.isSuccess).length;
  int get totalFailure => _runs.where((r) => r.isFailure).length;
  int get totalQueued => _runs.where((r) => r.isQueued).length;
  int get totalRunning => _runs.where((r) => r.isRunning).length;

  Future<Map<String, int>> buildAll() async {
    final result = {
      'triggered': 0,
      'failed': 0,
      'skipped': 0,
    };

    const workflows = ['build_flutter.yml', 'build_android.yml', 'web2apk.yml'];

    for (final repo in _repos) {
      List<String> availableWorkflows;
      try {
        final res = await http.get(
          Uri.parse('https://api.github.com/repos/$repo/actions/workflows'),
          headers: _headers,
        ).timeout(_timeout);

        if (res.statusCode != 200) {
          result['failed'] = result['failed']! + 1;
          continue;
        }

        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final wfs = (data['workflows'] as List?) ?? [];
        availableWorkflows = wfs.map((w) => w['path'] as String? ?? '').toList();
      } catch (_) {
        result['failed'] = result['failed']! + 1;
        continue;
      }

      for (final wf in workflows) {
        final path = '.github/workflows/$wf';
        if (!availableWorkflows.contains(path)) {
          result['skipped'] = result['skipped']! + 1;
          continue;
        }

        try {
          final res = await http.post(
            Uri.parse('https://api.github.com/repos/$repo/actions/workflows/$wf/dispatches'),
            headers: {..._headers, 'Content-Type': 'application/json'},
            body: jsonEncode({'ref': await _getDefaultBranch(repo)}),
          ).timeout(_timeout);

          if (res.statusCode == 204 || res.statusCode == 200) {
            result['triggered'] = result['triggered']! + 1;
          } else {
            result['failed'] = result['failed']! + 1;
          }
        } catch (_) {
          result['failed'] = result['failed']! + 1;
        }
      }
    }

    return result;
  }

  Future<String> _getDefaultBranch(String repo) async {
    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/repos/$repo'),
        headers: _headers,
      ).timeout(_timeout);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        return data['default_branch'] as String? ?? 'main';
      }
    } catch (_) {}
    return 'main';
  }
}