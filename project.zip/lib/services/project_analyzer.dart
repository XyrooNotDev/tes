import 'dart:isolate';
import 'dart:convert';

import 'package:xml/xml.dart';
import 'package:yaml/yaml.dart';

import 'project_zip.dart';

/// Analisis statis project (Flutter / Android Studio / Capacitor) dari file ZIP.
/// Dijalankan di isolate: kembalikan daftar temuan berupa Map sederhana.
///
/// Ini bukan kompilator: yang dicek adalah penyebab error build yang paling umum
/// (struktur, versi Gradle/AGP, manifest, resource, import, kurung, XML/JSON/YAML).
List<Map<String, dynamic>> analyzeProjectZip(String zipPath) {
  final out = <Map<String, dynamic>>[];

  void add(String sev, String title, String detail, {String? file, int? line}) {
    if (out.length >= 300) return;
    out.add({'sev': sev, 'title': title, 'detail': detail, 'file': file, 'line': line});
  }

  final ZipProject zp;
  try {
    zp = ZipProject.open(zipPath);
  } catch (e) {
    return [
      {
        'sev': 'error',
        'title': 'File ZIP tidak bisa dibaca',
        'detail': 'ZIP rusak atau bukan file ZIP valid: $e',
        'file': null,
        'line': null,
      }
    ];
  }

  final info = zp.info;
  final files = zp.files;
  String rel(String p) => info.root.isNotEmpty && p.startsWith(info.root) ? p.substring(info.root.length) : p;

  add('info', 'Jenis project: ${_kindLabel(info.kind)}',
      '${files.length} file dianalisis (folder build/.git/node_modules dilewati).');

  if (info.kind == 'unknown') {
    add('error', 'Project tidak dikenali',
        'Tidak ditemukan pubspec.yaml (Flutter), settings.gradle (Android Studio), atau capacitor.config. '
        'Pastikan ZIP berisi folder project, bukan hanya sebagian file.');
    return out;
  }

  String? pubName;
  final deps = <String>{};
  if (info.kind == 'flutter') {
    final pubPath = '${info.root}pubspec.yaml';
    final pubText = zp.text(pubPath);
    if (pubText != null) {
      try {
        final doc = loadYaml(pubText);
        if (doc is Map) {
          pubName = doc['name']?.toString();
          if (pubName == null || pubName.isEmpty) {
            add('error', 'pubspec.yaml tidak punya "name"', 'Tambahkan baris name: nama_project.',
                file: rel(pubPath));
          }
          for (final key in const ['dependencies', 'dev_dependencies']) {
            final d = doc[key];
            if (d is Map) {
              for (final e in d.entries) {
                deps.add(e.key.toString());
                final v = e.value;
                if (v is Map && v['path'] != null) {
                  final path = v['path'].toString();
                  if (path.startsWith('..')) {
                    add('warning', 'Dependency "${e.key}" memakai path di luar ZIP',
                        'path: $path tidak ikut ter-ZIP sehingga build di GitHub akan gagal (Could not find package).',
                        file: rel(pubPath));
                  }
                }
              }
            }
          }
          // Asset yang dideklarasikan harus ada.
          final flutter = doc['flutter'];
          if (flutter is Map && flutter['assets'] is List) {
            for (final a in (flutter['assets'] as List)) {
              final entry = a.toString();
              final full = '${info.root}$entry';
              final exists = entry.endsWith('/')
                  ? files.keys.any((p) => p.startsWith(full))
                  : files.containsKey(full);
              if (!exists) {
                add('error', 'Asset tidak ditemukan: $entry',
                    'Dideklarasikan di pubspec.yaml tetapi tidak ada di ZIP (build gagal: unable to find asset).',
                    file: rel(pubPath));
              }
            }
          }
        } else {
          add('error', 'pubspec.yaml tidak valid', 'Isi bukan YAML berbentuk map.', file: rel(pubPath));
        }
      } on YamlException catch (e) {
        add('error', 'pubspec.yaml tidak valid', e.message,
            file: rel(pubPath), line: e.span == null ? null : e.span!.start.line + 1);
      } catch (e) {
        add('error', 'pubspec.yaml tidak valid', '$e', file: rel(pubPath));
      }
    }

    if (!files.containsKey('${info.root}lib/main.dart')) {
      add('error', 'lib/main.dart tidak ada', 'Aplikasi Flutter butuh entry point lib/main.dart.');
    }
    if (!files.keys.any((p) => p.startsWith(info.androidRoot))) {
      add('error', 'Folder android/ tidak ada',
          'Project Flutter tidak punya folder android sehingga APK tidak bisa dibuild. '
          'Jalankan "flutter create ." di project lalu ZIP ulang.');
    }

    // Import Dart.
    final importRe = RegExp(r'''^\s*(?:import|export|part)\s+['"]([^'"]+)['"]''', multiLine: true);
    var dartScanned = 0;
    for (final entry in files.entries) {
      final path = entry.key;
      if (!path.endsWith('.dart') || !path.startsWith(info.root)) continue;
      if (++dartScanned > 3000) break;
      final f = entry.value;
      if (f.size > 1500000) continue;
      final text = textOf(f);
      for (final m in importRe.allMatches(text)) {
        final uri = m.group(1)!;
        if (uri.startsWith('dart:')) continue;
        final line = lineOfIndex(text, m.start);
        if (uri.startsWith('package:')) {
          final rest = uri.substring(8);
          final slash = rest.indexOf('/');
          if (slash < 0) continue;
          final pkg = rest.substring(0, slash);
          final inner = rest.substring(slash + 1);
          if (pkg == pubName) {
            if (!files.containsKey('${info.root}lib/$inner')) {
              add('error', 'Import tidak ditemukan: $uri',
                  'File lib/$inner tidak ada di ZIP.',
                  file: rel(path), line: line);
            }
          } else if (!deps.contains(pkg) && pkg != 'flutter') {
            add('error', 'Package "$pkg" belum ada di pubspec.yaml',
                'Di-import oleh kode tetapi tidak ada di dependencies (error: Target of URI doesn\'t exist).',
                file: rel(path), line: line);
          }
        } else if (!uri.contains(':')) {
          final resolved = _resolve(dirOf(path), uri);
          if (!files.containsKey(resolved)) {
            add('error', 'File import tidak ditemukan: $uri',
                'Path relatif mengarah ke file yang tidak ada di ZIP (huruf besar/kecil juga berpengaruh di Linux).',
                file: rel(path), line: line);
          }
        }
      }
    }
  }

  if (info.appModule.isEmpty) {
    add('error', 'AndroidManifest.xml modul aplikasi tidak ditemukan',
        'Tidak ada src/main/AndroidManifest.xml di dalam ${info.androidRoot.isEmpty ? 'root project' : info.androidRoot}.');
  } else {
    _analyzeAndroid(zp, info, add, rel);
  }

  var scanned = 0;
  for (final entry in files.entries) {
    final path = entry.key;
    final f = entry.value;
    if (!path.startsWith(info.root)) continue;
    if (f.size > 1500000) continue;
    final lower = path.toLowerCase();

    if (lower.endsWith('.dart') || lower.endsWith('.kt') || lower.endsWith('.java') || lower.endsWith('.kts')) {
      if (++scanned > 4000) continue;
      final problem = BracketChecker(textOf(f)).check();
      if (problem != null) {
        add('error', problem.message, 'Kemungkinan salah ketik / kurung kurang. Periksa area sekitar baris ini.',
            file: rel(path), line: problem.line);
      }
    } else if (lower.endsWith('.json') && !lower.endsWith('package-lock.json')) {
      try {
        jsonDecode(textOf(f));
      } on FormatException catch (e) {
        add('error', 'JSON tidak valid', e.message, file: rel(path));
      }
    } else if (lower.endsWith('.xml') && (lower.contains('/res/') || lower.endsWith('androidmanifest.xml'))) {
      try {
        XmlDocument.parse(textOf(f));
      } catch (e) {
        add('error', 'XML tidak valid', _firstLine('$e'), file: rel(path), line: _xmlLine(e));
      }
    }
  }

  final errors = out.where((e) => e['sev'] == 'error').length;
  if (errors == 0) {
    add('info', 'Tidak ada error yang terdeteksi',
        'Pemeriksaan statis lolos. Ini belum menjamin build sukses (kompilasi penuh hanya terjadi di GitHub Actions).');
  }
  return out;
}

void _analyzeAndroid(
  ZipProject zp,
  ProjectInfo info,
  void Function(String, String, String, {String? file, int? line}) add,
  String Function(String) rel,
) {
  final files = zp.files;
  final manifestPath = '${info.appModule}src/main/AndroidManifest.xml';
  final manifestText = zp.text(manifestPath) ?? '';
  final gradlePath = zp.appGradlePath();
  final gradle = gradlePath == null ? '' : (zp.text(gradlePath) ?? '');

  final wrapperProps = zp.text('${info.androidRoot}gradle/wrapper/gradle-wrapper.properties');
  String? gradleVersion;
  if (wrapperProps != null) {
    gradleVersion = RegExp(r'gradle-([0-9][0-9.]*)-(?:bin|all)\.zip').firstMatch(wrapperProps)?.group(1);
  }
  if (!files.containsKey('${info.androidRoot}gradlew')) {
    add('warning', 'gradlew tidak ada', 'Build Android Studio butuh gradlew di ${info.androidRoot.isEmpty ? 'root' : info.androidRoot}.');
  }
  if (!files.containsKey('${info.androidRoot}gradle/wrapper/gradle-wrapper.jar')) {
    add('warning', 'gradle-wrapper.jar tidak ada', 'Wrapper Gradle tidak lengkap; build bisa gagal menjalankan ./gradlew.');
  }

  // AGP
  String? agp;
  final rootGradleTexts = <String>[
    zp.text('${info.androidRoot}build.gradle') ?? '',
    zp.text('${info.androidRoot}build.gradle.kts') ?? '',
    zp.text('${info.androidRoot}settings.gradle') ?? '',
    zp.text('${info.androidRoot}settings.gradle.kts') ?? '',
    zp.text('${info.androidRoot}gradle/libs.versions.toml') ?? '',
  ].join('\n');
  agp = RegExp(r'com\.android\.tools\.build:gradle:([0-9][0-9.]*)').firstMatch(rootGradleTexts)?.group(1) ??
      RegExp(r'''com\.android\.(?:application|library)["']\)?\s*version\s*\(?["']([0-9][0-9.]*)''')
          .firstMatch(rootGradleTexts)
          ?.group(1) ??
      RegExp(r'''agp\s*=\s*["']([0-9][0-9.]*)''').firstMatch(rootGradleTexts)?.group(1);

  if (agp != null && gradleVersion != null) {
    final key = agp.split('.').take(2).join('.');
    final need = _agpMinGradle[key];
    if (need != null && _cmp(gradleVersion, need) < 0) {
      add('error', 'Gradle $gradleVersion terlalu lama untuk AGP $agp',
          'Android Gradle Plugin $key butuh Gradle minimal $need. Ubah distributionUrl di gradle-wrapper.properties.',
          file: rel('${info.androidRoot}gradle/wrapper/gradle-wrapper.properties'));
    }
  }

  // namespace wajib di AGP 8+
  final agpMajor = int.tryParse((agp ?? '').split('.').first) ?? 0;
  final namespace = ZipProject.gradleValue(gradle, 'namespace');
  final appId = ZipProject.gradleValue(gradle, 'applicationId');
  if (agpMajor >= 8 && gradlePath != null && namespace == null) {
    add('error', 'namespace belum diatur (AGP $agp)',
        'AGP 8+ wajib punya namespace "..." di android { } pada ${rel(gradlePath)} '
        '(atau Namespace not specified).',
        file: rel(gradlePath));
  }
  if (gradlePath != null && !gradle.contains('compileSdk')) {
    add('warning', 'compileSdk tidak ditemukan', 'Tambahkan compileSdk di android { }.', file: rel(gradlePath));
  }

  // pola bermasalah di gradle
  for (final gp in files.keys.where((p) =>
      p.startsWith(info.androidRoot) && (p.endsWith('.gradle') || p.endsWith('.gradle.kts')))) {
    final t = textOf(files[gp]!);
    final jc = t.indexOf('jcenter()');
    if (jc >= 0) {
      add('warning', 'jcenter() sudah dimatikan',
          'Ganti dengan mavenCentral(). Dependency lama bisa gagal diunduh.',
          file: rel(gp), line: lineOfIndex(t, jc));
    }
    final http = RegExp(r'''url\s*=?\s*(?:uri\()?\s*["']http://''').firstMatch(t);
    if (http != null) {
      add('error', 'Repository memakai http:// (tidak aman)',
          'Gradle 7+ menolak repository tanpa HTTPS (Using insecure protocols with repositories is unsupported).',
          file: rel(gp), line: lineOfIndex(t, http.start));
    }
    final kx = t.indexOf('kotlin-android-extensions');
    if (kx >= 0) {
      add('warning', 'kotlin-android-extensions sudah dihapus',
          'Plugin ini tidak ada lagi di Kotlin 1.8+. Pakai View Binding.',
          file: rel(gp), line: lineOfIndex(t, kx));
    }
  }

  // signing
  if (RegExp(r'key\.properties').hasMatch(gradle) && !files.containsKey('${info.androidRoot}key.properties')) {
    add('error', 'key.properties dirujuk tetapi tidak ada di ZIP',
        'Build release gagal (key.properties (No such file)). Sertakan file itu, atau pakai debug signing.',
        file: gradlePath == null ? null : rel(gradlePath));
  }
  final localProps = zp.text('${info.androidRoot}local.properties');
  if (localProps != null && RegExp(r'^\s*sdk\.dir\s*=', multiLine: true).hasMatch(localProps)) {
    add('warning', 'local.properties berisi sdk.dir milik PC lokal',
        'Hapus file ini dari ZIP agar tidak bentrok dengan path SDK di runner GitHub.',
        file: rel('${info.androidRoot}local.properties'));
  }

  XmlDocument? doc;
  try {
    doc = XmlDocument.parse(manifestText);
  } catch (e) {
    add('error', 'AndroidManifest.xml tidak valid', _firstLine('$e'),
        file: rel(manifestPath), line: _xmlLine(e));
  }
  if (doc == null) return;

  final apps = doc.findAllElements('application').toList();
  if (apps.isEmpty) {
    add('error', 'Manifest tidak punya <application>', 'Tambahkan elemen <application>.', file: rel(manifestPath));
    return;
  }

  final tgt = RegExp(r'targetSdk(?:Version)?\s*=?\s*(\d+)').firstMatch(gradle)?.group(1);
  final targetSdk = tgt == null ? 34 : int.parse(tgt); // flutter.targetSdkVersion = terbaru
  final pkg = namespace ??
      appId ??
      doc.rootElement.getAttribute('package') ??
      '';

  // exported (Android 12+)
  if (targetSdk >= 31) {
    for (final tag in const ['activity', 'activity-alias', 'service', 'receiver']) {
      for (final el in doc.findAllElements(tag)) {
        if (el.findElements('intent-filter').isNotEmpty && el.getAttribute('android:exported') == null) {
          add('error', '<$tag> punya intent-filter tanpa android:exported',
              'Target SDK 31+ wajib menulis android:exported="true|false" (nama: ${el.getAttribute('android:name') ?? '?'}).',
              file: rel(manifestPath));
        }
      }
    }
  }

  // launcher
  final hasLauncher = doc.findAllElements('category').any((c) =>
      c.getAttribute('android:name') == 'android.intent.category.LAUNCHER');
  if (!hasLauncher) {
    add('warning', 'Tidak ada activity LAUNCHER',
        'Aplikasi tidak punya activity yang muncul di layar utama.', file: rel(manifestPath));
  }

  // embedding v1 (dihapus dari Flutter baru)
  if (manifestText.contains('io.flutter.app.FlutterApplication') ||
      manifestText.contains('io.flutter.app.FlutterActivity')) {
    add('error', 'Memakai Flutter Android embedding v1',
        'Flutter terbaru tidak mendukung v1 embedding. Perbarui folder android dengan template v2.',
        file: rel(manifestPath));
  }

  // referensi resource
  final index = _resourceIndex(files, info.appModule);
  for (final m in RegExp(r'@(mipmap|drawable|xml|raw|layout|string|color)/([A-Za-z0-9_.]+)')
      .allMatches(manifestText)) {
    final type = m.group(1)!;
    final name = m.group(2)!;
    if (!index.contains('$type/$name')) {
      add('error', 'Resource @$type/$name tidak ditemukan',
          'Dirujuk di manifest tetapi tidak ada di res/ (aapt2: resource not found).',
          file: rel(manifestPath), line: lineOfIndex(manifestText, m.start));
    }
  }

  // kelas yang dirujuk
  if (pkg.isNotEmpty) {
    for (final tag in const ['application', 'activity', 'service', 'receiver', 'provider']) {
      for (final el in doc.findAllElements(tag)) {
        final name = el.getAttribute('android:name');
        if (name == null || name.contains(r'$')) continue;
        String? fqcn;
        if (name.startsWith('.')) {
          fqcn = '$pkg$name';
        } else if (name.startsWith('$pkg.')) {
          fqcn = name;
        }
        if (fqcn == null) continue;
        final path = fqcn.replaceAll('.', '/');
        final found = files.keys.any((p) =>
            p.startsWith(info.appModule) && (p.endsWith('/$path.kt') || p.endsWith('/$path.java')));
        if (!found) {
          // Application / activity launcher yang hilang membuat aplikasi crash saat pertama dibuka.
          final critical = tag == 'application' ||
              (tag == 'activity' &&
                  el.findAllElements('category').any((c) =>
                      c.getAttribute('android:name') == 'android.intent.category.LAUNCHER'));
          add(critical ? 'error' : 'warning', 'Kelas $fqcn tidak ditemukan',
              critical
                  ? '<$tag> merujuk kelas yang tidak ada di src/. Aplikasi akan force close saat dibuka '
                      '(ClassNotFoundException). Periksa folder src/main/kotlin atau java ikut ter-ZIP.'
                  : '<$tag> merujuk kelas yang tidak ada di src/ (bisa crash ClassNotFoundException).',
              file: rel(manifestPath));
        }
      }
    }
  }
}

/// Indeks "tipe/nama" semua resource di modul aplikasi.
Set<String> _resourceIndex(Map<String, dynamic> files, String module) {
  final out = <String>{};
  final fileRe = RegExp(r'/res/([a-z]+)(?:-[^/]*)?/([^/.]+)\.');
  const valueTypes = {
    'string': 'string',
    'color': 'color',
    'dimen': 'dimen',
    'style': 'style',
    'bool': 'bool',
    'integer': 'integer',
  };
  final valRe = RegExp(r'<(string|color|dimen|style|bool|integer)\s+name="([^"]+)"');
  for (final entry in files.entries) {
    final p = entry.key;
    if (!p.startsWith(module)) continue;
    final m = fileRe.firstMatch(p);
    if (m == null) continue;
    final type = m.group(1)!;
    if (type == 'values') {
      if (p.endsWith('.xml')) {
        final t = textOf(entry.value);
        for (final v in valRe.allMatches(t)) {
          out.add('${valueTypes[v.group(1)!]}/${v.group(2)}');
        }
      }
    } else {
      out.add('$type/${m.group(2)}');
    }
  }
  return out;
}

const Map<String, String> _agpMinGradle = {
  '7.0': '7.0',
  '7.1': '7.2',
  '7.2': '7.3.3',
  '7.3': '7.4',
  '7.4': '7.5',
  '8.0': '8.0',
  '8.1': '8.0',
  '8.2': '8.2',
  '8.3': '8.4',
  '8.4': '8.6',
  '8.5': '8.7',
  '8.6': '8.7',
  '8.7': '8.9',
  '8.8': '8.10.2',
  '8.9': '8.11.1',
  '8.10': '8.11.1',
  '8.11': '8.13',
};

int _cmp(String a, String b) {
  final x = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  final y = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
  for (var i = 0; i < 3; i++) {
    final p = i < x.length ? x[i] : 0;
    final q = i < y.length ? y[i] : 0;
    if (p != q) return p.compareTo(q);
  }
  return 0;
}

String _resolve(String baseDir, String relative) {
  final parts = <String>[...baseDir.split('/').where((e) => e.isNotEmpty)];
  for (final seg in relative.split('/')) {
    if (seg == '..') {
      if (parts.isNotEmpty) parts.removeLast();
    } else if (seg != '.' && seg.isNotEmpty) {
      parts.add(seg);
    }
  }
  return parts.join('/');
}

String _kindLabel(String k) {
  switch (k) {
    case 'flutter':
      return 'Flutter';
    case 'android':
      return 'Android Studio';
    case 'capacitor':
      return 'Capacitor';
    default:
      return 'Tidak dikenali';
  }
}

String _firstLine(String s) => s.split('\n').first;

int? _xmlLine(Object e) {
  try {
    final l = (e as dynamic).line;
    return l is int ? l : null;
  } catch (_) {
    return null;
  }
}

/// Dijalankan di fungsi top-level agar closure isolate hanya membawa data sederhana.
Future<List<dynamic>> runAnalyzerInIsolate(String zipPath) {
  return Isolate.run<List<dynamic>>(() => analyzeProjectZip(zipPath));
}
