import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/build_record.dart';
import 'artifact_service.dart';
import 'build_store.dart';
import 'github_actions.dart';
import 'notification_service.dart';
import 'session_manager.dart';

/// Pemanggil 'update' ke UI. Di service = `service.invoke`, di dalam app = reload langsung.
typedef TrackerInvoke = void Function(String method, Map<String, dynamic>? args);

class BuildTracker {
  static const String _kUseService = 'use_bg_service';

  /// true = pelacak berjalan di foreground service (tetap jalan saat app ditutup).
  /// false = mode aman: pelacak berjalan di dalam aplikasi (tanpa service).
  static Future<bool> serviceEnabled() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.reload();
      return p.getBool(_kUseService) ?? true;
    } catch (_) {
      return true;
    }
  }

  static Future<void> setServiceEnabled(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kUseService, value);
  }

  static Future<void> configure() async {
    await FlutterBackgroundService().configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onBuildServiceStart,
        autoStart: false,
        autoStartOnBoot: false, // Android 15 melarang FGS dataSync dimulai dari BOOT_COMPLETED
        isForegroundMode: true,
        notificationChannelId: kProgressChannelId,
        initialNotificationTitle: 'Santanic Build',
        initialNotificationContent: 'Menyiapkan build...',
        foregroundServiceNotificationId: kProgressNotifId,
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
  }

  static Future<void> start() async {
    final service = FlutterBackgroundService();
    if (await service.isRunning()) {
      service.invoke('stop');
      await Future<void>.delayed(const Duration(seconds: 1));
    }
    await service.startService();
  }
}

@pragma('vm:entry-point')
Future<void> onBuildServiceStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  bool stopped = false;
  service.on('stop').listen((_) {
    stopped = true;
  });

  try {
    await trackBuild(
      invoke: (m, a) => service.invoke(m, a),
      stopped: () => stopped,
      background: true,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Fatal error: $e');
  } finally {
    try {
      service.stopSelf();
    } catch (_) {}
  }
}

/// Menyimpan riwayat secara berurutan (hindari tulis bersamaan dari callback progress).
class _Persister {
  Future<void> _chain = Future<void>.value();

  void queue(BuildRecord r) {
    _chain = _chain.then((_) => BuildStore.appendHistory(r)).catchError((_) {});
  }

  Future<void> flush() => _chain;
}

/// Inti pelacakan build. [background] = berjalan di isolate service (perlu init notifikasi sendiri).
Future<void> trackBuild({
  required TrackerInvoke invoke,
  required bool Function() stopped,
  required bool background,
}) async {
  if (background) {
    try {
      await NotificationService.initBackground();
    } catch (e) {
      debugPrint('[BuildTracker] initBackground gagal: $e');
    }
  }

  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final token = prefs.getString(SessionManager.kToken) ?? '';
  final loaded = await BuildStore.loadCurrent();

  if (loaded == null || loaded.isFinished || token.isEmpty) {
    debugPrint('[BuildTracker] Tidak ada build berjalan atau token kosong');
    return;
  }

  var rec = loaded;
  final api = GitHubActions(token);
  final deadline = DateTime.fromMillisecondsSinceEpoch(rec.startedAt)
      .add(const Duration(minutes: 60));

  int emptyRunRetries = 0;
  int consecutiveErrors = 0;
  int pollCount = 0;
  const maxEmptyRetries = 50;
  const maxConsecutiveErrors = 20;

  debugPrint('[BuildTracker] Mulai tracking: ${rec.owner}/${rec.repo} • ${rec.workflow}');

  await _publish(rec);

  while (!stopped()) {
    if (DateTime.now().isAfter(deadline)) {
      final timeout = rec.copyWith(
        status: 'failure',
        step: 'Melewati batas waktu pelacakan (Timeout 60 menit)',
      );
      await _finish(invoke, timeout, token);
      await _notifyError(timeout, 'Build timeout setelah 60 menit');
      return;
    }

    try {
      if (rec.runId == null) {
        final run = await api.findRun(rec.owner, rec.repo, rec.workflow, rec.baselineRunId);
        if (run != null) {
          debugPrint('[BuildTracker] Run ditemukan: ${run.id}');
          rec = rec.copyWith(runId: run.id, url: run.htmlUrl);
          emptyRunRetries = 0;
        } else {
          emptyRunRetries++;
          if (emptyRunRetries >= maxEmptyRetries) {
            final failed = rec.copyWith(
              status: 'failure',
              step: 'Gagal menemukan workflow run di GitHub',
            );
            await _finish(invoke, failed, token);
            await _notifyError(failed, 'Workflow run tidak ditemukan setelah 5 menit');
            return;
          }
        }
      }

      final runId = rec.runId;
      if (runId != null) {
        final p = await api.progress(rec.owner, rec.repo, runId);
        final newStatus = p.finished
            ? p.finalStatus
            : (p.status == 'queued' ? 'queued' : 'running');

        // Persen tidak pernah turun (jumlah step bertambah seiring job dimulai).
        var newPercent = rec.percent;
        if (p.finished) {
          newPercent = p.finalStatus == 'success' ? 100 : rec.percent;
        } else if (p.percent > newPercent) {
          newPercent = p.percent;
        }

        // Log berjalan: ambil tiap ~3 polling (±18 detik) supaya hemat kuota API.
        var logTail = rec.logTail;
        if (!p.finished && pollCount % 3 == 0) {
          final jobId = p.runningJobId;
          if (jobId != null) {
            final t = await api.jobLogTail(rec.owner, rec.repo, jobId);
            if (t.isNotEmpty) logTail = _cap(t);
          }
        }
        if (p.finished && p.finalStatus != 'success') {
          final jobId = p.failedJobId ?? p.runningJobId;
          if (jobId != null) {
            final t = await api.jobLogTail(rec.owner, rec.repo, jobId);
            if (t.isNotEmpty) logTail = _cap(t);
          }
        }

        rec = rec.copyWith(
          status: newStatus,
          percent: newPercent,
          step: p.stepLabel,
          url: p.htmlUrl,
          diagnostics: p.diagnostics,
          jobs: p.jobs,
          runNumber: p.runNumber,
          branch: p.branch,
          sha: p.sha,
          actor: p.actor,
          logTail: logTail,
        );

        if (p.finished) {
          await _finish(invoke, rec, token);
          return;
        }
      }

      await BuildStore.saveCurrent(rec);
      invoke('update', {'id': rec.id});
      await _publish(rec);
      consecutiveErrors = 0;
    } catch (e) {
      consecutiveErrors++;
      debugPrint('[BuildTracker] Polling error ($consecutiveErrors/$maxConsecutiveErrors): $e');

      if (consecutiveErrors >= maxConsecutiveErrors) {
        final failed = rec.copyWith(
          status: 'failure',
          step: 'Koneksi ke GitHub terputus. Build dihentikan.',
        );
        await _finish(invoke, failed, token);
        await _notifyError(failed, 'Koneksi ke GitHub terputus selama 2 menit');
        return;
      }
    }

    pollCount++;
    await Future<void>.delayed(const Duration(seconds: 6));
  }

  debugPrint('[BuildTracker] Dihentikan oleh user');
}

String _cap(String s, [int max = 4000]) =>
    s.length <= max ? s : s.substring(s.length - max);

Future<void> _notifyError(BuildRecord rec, String message) async {
  try {
    await NotificationService.showError(
      title: 'Build Gagal ❌',
      body: '${rec.typeLabel} • ${rec.repo}: $message',
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal kirim notifikasi error: $e');
  }
}

Future<void> _publish(BuildRecord rec) async {
  try {
    final elapsed = _fmt(rec.elapsedMs);
    await NotificationService.showProgress(
      title: 'Build ${rec.typeLabel} • ${rec.repo}',
      body: '${rec.step.isEmpty ? 'Menunggu runner GitHub...' : rec.step}\n${rec.percent}% • $elapsed',
      percent: rec.percent,
      indeterminate: rec.percent == 0,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal update notifikasi progress: $e');
  }
}

String _fmt(int ms) {
  final s = ms ~/ 1000;
  final m = s ~/ 60;
  final sec = s % 60;
  return m > 0 ? '${m}m ${sec}s' : '${sec}s';
}

Future<void> _finish(TrackerInvoke invoke, BuildRecord rec, String token) async {
  try {
    var done = rec.copyWith(
      finishedAt: DateTime.now().millisecondsSinceEpoch,
      percent: rec.isSuccess ? 100 : rec.percent,
    );

    if (done.isSuccess && done.runId != null) {
      done = done.copyWith(
        step: 'Build selesai. Mengunduh APK...',
        downloadState: 'downloading',
        downloadPercent: 0,
        downloadError: '',
      );
    }

    debugPrint('[BuildTracker] Build selesai: ${done.status} (${done.percent}%)');

    await BuildStore.appendHistory(done);
    await BuildStore.clearCurrent();
    invoke('update', {'id': done.id});

    // Popup hasil build (heads-up).
    try {
      await NotificationService.showDone(
        title: done.isSuccess
            ? 'Build selesai ✅'
            : (done.status == 'cancelled' ? 'Build dibatalkan' : 'Build gagal ❌'),
        body: done.isSuccess
            ? '${done.typeLabel} • ${done.repo} berhasil dibuild. Mengunduh APK...'
            : '${done.typeLabel} • ${done.repo} ${done.statusLabel.toLowerCase()}. Ketuk untuk melihat detail.',
      );
    } catch (e) {
      debugPrint('[BuildTracker] Gagal kirim notifikasi done: $e');
    }

    if (!(done.isSuccess && done.runId != null)) {
      try {
        await NotificationService.cancelProgress();
      } catch (_) {}
      return;
    }

    // ===== Unduh APK otomatis di latar belakang =====
    final persister = _Persister();
    var lastPct = -10;
    try {
      final path = await ArtifactService(token).downloadApk(
        rec: done,
        onProgress: (f) {
          final pct = (f * 100).floor().clamp(0, 100);
          if (pct >= lastPct + 5) {
            lastPct = pct;
            NotificationService.showDownloadProgress(
              title: 'Unduh APK • ${done.repo}',
              percent: pct,
            ).catchError((_) {});
            persister.queue(done.copyWith(downloadPercent: pct));
            invoke('update', {'id': done.id});
          }
        },
      );
      await persister.flush();
      done = done.copyWith(
        step: 'Build selesai. APK siap diinstal.',
        apkPath: path,
        downloadState: 'done',
        downloadPercent: 100,
        downloadError: '',
      );
      await BuildStore.appendHistory(done);
      try {
        await NotificationService.cancelProgress();
      } catch (_) {}
      try {
        await NotificationService.showDone(
          title: 'APK siap diinstal ✅',
          body: '${done.typeLabel} • ${done.repo}. Ketuk lalu tekan Install APK.',
        );
      } catch (_) {}
    } catch (e) {
      await persister.flush();
      final msg = e.toString().replaceFirst('Exception: ', '');
      debugPrint('[BuildTracker] Unduh APK gagal: $msg');
      done = done.copyWith(
        step: 'Build selesai, tapi unduh APK gagal.',
        downloadState: 'failed',
        downloadError: msg,
      );
      await BuildStore.appendHistory(done);
      try {
        await NotificationService.cancelProgress();
      } catch (_) {}
      try {
        await NotificationService.showError(
          title: 'Unduh APK gagal',
          body: '${done.typeLabel} • ${done.repo}: $msg. Buka tab Progress untuk unduh ulang.',
        );
      } catch (_) {}
    }

    invoke('update', {'id': done.id});
  } catch (e) {
    debugPrint('[BuildTracker] Gagal finish: $e');
  }
}
