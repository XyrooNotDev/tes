import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/build_record.dart';
import '../nav.dart';
import '../services/error_log.dart';
import '../services/build_controller.dart';
import '../theme.dart';

const Color kAmber = Color(0xFFFFC107);

Color statusColor(BuildRecord r) {
  if (!r.isFinished) return kAmber;
  if (r.status == 'cancelled') return kMuted;
  return r.isSuccess ? kGreen : kRed;
}

/// Ubah data dinamis (hasil JSON) jadi daftar Map<String,dynamic> tanpa pernah melempar error.
List<Map<String, dynamic>> _asMapList(dynamic v) {
  if (v is! List) return const [];
  final out = <Map<String, dynamic>>[];
  for (final e in v) {
    if (e is Map) {
      out.add(e.map((k, val) => MapEntry(k.toString(), val)));
    }
  }
  return out;
}

int? _asInt(dynamic v) => v is num ? v.toInt() : null;

String _two(int v) => v.toString().padLeft(2, '0');

String formatDuration(int ms) {
  final total = (ms < 0 ? 0 : ms) ~/ 1000;
  final h = total ~/ 3600;
  final m = (total % 3600) ~/ 60;
  final s = total % 60;
  if (h > 0) return '${h}h ${_two(m)}m ${_two(s)}s';
  if (m > 0) return '${m}m ${_two(s)}s';
  return '${s}s';
}

String formatDateTime(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${_two(d.day)}/${_two(d.month)} ${_two(d.hour)}:${_two(d.minute)}:${_two(d.second)}';
}

/// Kartu progress build.
/// - [detailed] = false → ringkas (dipakai di layar build & riwayat)
/// - [detailed] = true  → lengkap: info run, semua job & step, durasi, log, aksi APK
/// - [recordId] kosong → tampilkan build berjalan / terakhir.
class BuildProgressView extends StatefulWidget {
  const BuildProgressView({
    super.key,
    required this.controller,
    this.recordId,
    this.detailed = false,
  });

  final BuildController controller;
  final String? recordId;
  final bool detailed;

  @override
  State<BuildProgressView> createState() => _BuildProgressViewState();
}

class _BuildProgressViewState extends State<BuildProgressView> {
  Timer? _ticker;

  BuildController get controller => widget.controller;

  BuildRecord? _record() =>
      widget.recordId == null ? controller.display : controller.byId(widget.recordId!);

  @override
  void initState() {
    super.initState();
    // Detik berjalan untuk durasi build yang sedang aktif.
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      final r = _record();
      if (mounted && r != null && !r.isFinished) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: error ? kRed : kCard,
        behavior: SnackBarBehavior.floating,
      ));
  }

  Future<void> _guard(Future<void> Function() action, {String? success}) async {
    try {
      await action();
      if (success != null) _snack(success);
    } catch (e) {
      _snack(e.toString().replaceFirst('Exception: ', ''), error: true);
    }
  }

  Future<void> _confirmCancel() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Batalkan Build?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Build yang sedang berjalan akan dihentikan secara paksa di GitHub Actions.',
          style: TextStyle(color: kMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Tidak', style: TextStyle(color: kMuted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ya, Batalkan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _guard(controller.cancelBuild, success: 'Build berhasil dibatalkan');
    }
  }

  void _openDetailTab() {
    Navigator.of(context).popUntil((route) => route.isFirst);
    AppNav.tabIndex.value = AppNav.progressTab;
  }

  Future<void> _openUrl(String? url) async {
    if (url == null || url.isEmpty) return;
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final r = _record();

        if (r == null) {
          return const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(
              child: Text('Belum ada riwayat build.', style: TextStyle(color: kMuted, fontSize: 14)),
            ),
          );
        }

        final color = statusColor(r);
        final progress = (r.percent / 100).clamp(0.0, 1.0);

        return Card(
          color: kCard,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: kBorder),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _header(r, color),
                const SizedBox(height: 4),
                Text(
                  '${r.typeLabel}${r.mode.isEmpty ? '' : ' • ${r.mode}'} • ${r.owner}/${r.repo}',
                  style: const TextStyle(color: kMuted, fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 20),

                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: r.isFinished ? (r.isSuccess ? 1.0 : progress) : (r.percent == 0 ? null : progress),
                          strokeWidth: 8,
                          backgroundColor: kBorder,
                          valueColor: AlwaysStoppedAnimation<Color>(color),
                          strokeCap: StrokeCap.round,
                        ),
                      ),
                      Text(
                        '${r.percent}%',
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                Center(
                  child: Text(
                    r.step.isEmpty ? 'Menunggu runner GitHub...' : r.step,
                    style: const TextStyle(color: kMuted, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 6),
                Center(
                  child: Text(
                    'Durasi ${formatDuration(r.elapsedMs)}',
                    style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ),

                if (!r.isFinished) ...[
                  const SizedBox(height: 10),
                  const Center(
                    child: Text(
                      'Berjalan di latar belakang — aman ditutup, notifikasi akan muncul saat selesai.',
                      style: TextStyle(color: kMuted, fontSize: 11),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],

                ..._apkSection(r),

                if (r.url != null && r.url!.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Center(
                    child: TextButton.icon(
                      onPressed: () => _openUrl(r.url),
                      icon: const Icon(Icons.open_in_new, size: 16, color: kMuted),
                      label: const Text('Buka di GitHub', style: TextStyle(color: kMuted, fontSize: 12)),
                    ),
                  ),
                ],

                if (!widget.detailed) ...[
                  const SizedBox(height: 4),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _openDetailTab,
                      icon: const Icon(Icons.timelapse, size: 18),
                      label: const Text('Lihat progress lengkap'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: kBorder),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                ] else ...[
                  const SizedBox(height: 16),
                  ..._safe('info', () => [_infoSection(r)]),
                  ..._safe('job', () => _jobsSection(r)),
                  ..._safe('log', () => _logSection(r)),
                  ..._safe('diagnosis', () => _diagnosticsSection(r)),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  /// Jalankan pembuat widget; kalau melempar error, tampilkan pesan kecil dan catat.
  List<Widget> _safe(String name, List<Widget> Function() build) {
    try {
      return build();
    } catch (e, st) {
      ErrorLog.record('Bagian "$name": $e', st);
      return [
        const SizedBox(height: 12),
        Text(
          'Bagian $name tidak bisa ditampilkan.',
          style: const TextStyle(color: kMuted, fontSize: 12),
        ),
      ];
    }
  }

  // ───────────────────────── Header ─────────────────────────
  Widget _header(BuildRecord r, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            r.isFinished ? 'Build ${r.statusLabel}' : 'Sedang Build...',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
          ),
        ),
        if (!r.isFinished)
          TextButton.icon(
            onPressed: r.runId == null ? null : _confirmCancel,
            icon: const Icon(Icons.stop_circle_outlined, color: kRed, size: 18),
            label: const Text('Batal', style: TextStyle(color: kRed, fontSize: 12)),
            style: TextButton.styleFrom(
              side: const BorderSide(color: kRed, width: 1),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            ),
          )
        else
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              r.statusLabel.toUpperCase(),
              style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
            ),
          ),
      ],
    );
  }

  // ───────────────────── Download / Install APK ─────────────────────
  List<Widget> _apkSection(BuildRecord r) {
    if (!r.isSuccess) return const [];

    final manual = controller.downloading && controller.downloadingId == r.id;
    final bg = r.isDownloading;
    final pct = manual ? (controller.downloadProgress * 100).round() : r.downloadPercent;

    final widgets = <Widget>[const SizedBox(height: 16)];

    if (manual || bg) {
      widgets.addAll([
        LinearProgressIndicator(
          value: pct > 0 ? pct / 100 : null,
          color: kRed,
          backgroundColor: kBorder,
          minHeight: 5,
        ),
        const SizedBox(height: 6),
        Text(
          manual ? 'Mengunduh APK... $pct%' : 'Mengunduh APK di latar belakang... $pct%',
          style: const TextStyle(color: kMuted, fontSize: 11),
          textAlign: TextAlign.center,
        ),
      ]);
      return widgets;
    }

    if (r.hasApk) {
      widgets.addAll([
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: kGreen,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _guard(() => controller.installApk(r)),
            icon: const Icon(Icons.system_update_alt, color: Colors.black),
            label: const Text('Install APK',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: () => _guard(() async {
              final where = await controller.saveToDownloads(r);
              _snack('Tersimpan di $where');
            }),
            icon: const Icon(Icons.download_done, size: 18),
            label: const Text('Simpan ke folder Download'),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: kBorder),
              padding: const EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ),
      ]);
      return widgets;
    }

    // Belum ada APK: unduhan gagal / belum pernah / artifact baru siap.
    if (r.downloadState == 'failed' && r.downloadError.isNotEmpty) {
      widgets.addAll([
        Text(
          r.downloadError,
          style: const TextStyle(color: kRed, fontSize: 12),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 8),
      ]);
    }
    widgets.add(
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: kRed,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          onPressed: r.runId == null
              ? null
              : () => _guard(() => controller.downloadApk(r), success: 'APK siap diinstal'),
          icon: const Icon(Icons.download, color: Colors.white),
          label: Text(
            r.downloadState == 'failed' ? 'Unduh ulang APK' : 'Unduh APK',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
    return widgets;
  }

  // ───────────────────────── Info run ─────────────────────────
  Widget _infoSection(BuildRecord r) {
    final rows = <MapEntry<String, String>>[
      MapEntry('Repository', '${r.owner}/${r.repo}'),
      MapEntry('Jenis', '${r.typeLabel}${r.mode.isEmpty ? '' : ' • ${r.mode}'}'),
      MapEntry('Workflow', '${r.workflow} (${r.customWorkflow ? 'kustom' : 'bawaan'})'),
      if (r.runNumber != null) MapEntry('Run', '#${r.runNumber}'),
      if (r.branch != null && r.branch!.isNotEmpty)
        MapEntry('Branch', r.sha == null ? r.branch! : '${r.branch} • ${r.sha}'),
      if (r.actor != null && r.actor!.isNotEmpty) MapEntry('Dipicu oleh', r.actor!),
      MapEntry('Mulai', formatDateTime(r.startedAt)),
      if (r.finishedAt != null) MapEntry('Selesai', formatDateTime(r.finishedAt!)),
      MapEntry('Durasi', formatDuration(r.elapsedMs)),
      if (r.hasApk) MapEntry('APK', r.apkPath!.split('/').last),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Detail Build',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kInputBg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: kBorder),
          ),
          child: Column(
            children: [
              for (final e in rows)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 92,
                        child: Text(e.key, style: const TextStyle(color: kMuted, fontSize: 12)),
                      ),
                      Expanded(
                        child: Text(
                          e.value,
                          style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  // ───────────────────────── Job & step ─────────────────────────
  List<Widget> _jobsSection(BuildRecord r) {
    if (r.jobs.isEmpty) {
      return [
        const SizedBox(height: 16),
        const Text('Job & Step',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        Text(
          r.isFinished ? 'Detail job tidak tersedia.' : 'Menunggu runner GitHub memulai job...',
          style: const TextStyle(color: kMuted, fontSize: 12),
        ),
      ];
    }

    return [
      const SizedBox(height: 16),
      const Text('Job & Step',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
      const SizedBox(height: 8),
      for (final job in r.jobs) _jobTile(r, job),
    ];
  }

  Widget _jobTile(BuildRecord r, Map<String, dynamic> job) {
    final status = job['status']?.toString() ?? 'queued';
    final conclusion = job['conclusion']?.toString();
    final steps = _asMapList(job['steps']);
    final start = _asInt(job['start']);
    final end = _asInt(job['end']);
    final now = DateTime.now().millisecondsSinceEpoch;
    final dur = start == null ? null : (end ?? now) - start;
    final runner = job['runner']?.toString();
    final doneCount = steps.where((s) => s['status'] == 'completed').length;

    final open = status == 'in_progress' || conclusion == 'failure';

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: kInputBg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: kBorder),
      ),
      clipBehavior: Clip.antiAlias,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          key: ValueKey<String>('job_${r.id}_${job['id']}'),
          initiallyExpanded: open,
          tilePadding: const EdgeInsets.symmetric(horizontal: 12),
          childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          iconColor: kMuted,
          collapsedIconColor: kMuted,
          leading: _stateIcon(status, conclusion),
          title: Text(
            job['name']?.toString() ?? 'Job',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
          ),
          subtitle: Text(
            [
              '$doneCount/${steps.length} step',
              if (dur != null) formatDuration(dur),
              if (runner != null && runner.isNotEmpty) runner,
            ].join(' • '),
            style: const TextStyle(color: kMuted, fontSize: 11),
          ),
          children: [
            for (final s in steps) _stepRow(s, now),
            if (job['url'] is String)
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton(
                  onPressed: () => _openUrl(job['url'] as String?),
                  child: const Text('Buka log lengkap job di GitHub', style: TextStyle(fontSize: 11)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _stepRow(Map<String, dynamic> s, int now) {
    final status = s['status']?.toString() ?? 'queued';
    final conclusion = s['conclusion']?.toString();
    final start = _asInt(s['start']);
    final end = _asInt(s['end']);
    final dur = start == null ? null : (end ?? now) - start;

    Color nameColor = Colors.white70;
    if (status == 'in_progress') nameColor = kAmber;
    if (conclusion == 'failure') nameColor = kRed;
    if (status == 'queued' || status == 'pending') nameColor = kMuted;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          _stateIcon(status, conclusion, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              s['name']?.toString() ?? 'Step',
              style: TextStyle(color: nameColor, fontSize: 12),
            ),
          ),
          if (dur != null && dur >= 0)
            Text(formatDuration(dur), style: const TextStyle(color: kMuted, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _stateIcon(String status, String? conclusion, {double size = 20}) {
    if (status == 'in_progress') {
      return SizedBox(
        width: size,
        height: size,
        child: const CircularProgressIndicator(strokeWidth: 2, color: kAmber),
      );
    }
    if (status == 'completed') {
      switch (conclusion) {
        case 'success':
          return Icon(Icons.check_circle, color: kGreen, size: size);
        case 'failure':
        case 'timed_out':
          return Icon(Icons.cancel, color: kRed, size: size);
        case 'skipped':
          return Icon(Icons.remove_circle_outline, color: kMuted, size: size);
        case 'cancelled':
          return Icon(Icons.block, color: kMuted, size: size);
        default:
          return Icon(Icons.help_outline, color: kMuted, size: size);
      }
    }
    return Icon(Icons.radio_button_unchecked, color: kMuted, size: size);
  }

  // ───────────────────────── Log ─────────────────────────
  List<Widget> _logSection(BuildRecord r) {
    if (r.logTail.isEmpty) return const [];
    return [
      const SizedBox(height: 16),
      Row(
        children: [
          const Expanded(
            child: Text('Log Terbaru',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
          ),
          IconButton(
            tooltip: 'Salin log',
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.copy, size: 18, color: kMuted),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: r.logTail));
              _snack('Log disalin');
            },
          ),
        ],
      ),
      const SizedBox(height: 4),
      Container(
        width: double.infinity,
        constraints: const BoxConstraints(maxHeight: 260),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF09090B),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kBorder),
        ),
        child: SingleChildScrollView(
          reverse: true,
          child: Text(
            r.logTail,
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
              color: kGreen,
              height: 1.4,
            ),
          ),
        ),
      ),
    ];
  }

  List<Widget> _diagnosticsSection(BuildRecord r) {
    if (r.diagnostics.isEmpty) return const [];
    return [
      const SizedBox(height: 16),
      const Text('Diagnosis',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
      const SizedBox(height: 8),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: kRed.withOpacity(0.08),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: kRed.withOpacity(0.4)),
        ),
        child: Text(
          r.diagnostics.join('\n'),
          style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70, height: 1.4),
        ),
      ),
    ];
  }
}
