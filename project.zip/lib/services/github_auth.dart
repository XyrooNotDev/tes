import 'dart:convert';

import 'package:http/http.dart' as http;

class GitHubAuth {
  // Batas waktu request HTTP
  static const Duration _timeout = Duration(seconds: 15);

  Future<String> fetchUsername(String token) async {
    if (token.trim().isEmpty) {
      throw Exception('Token tidak boleh kosong');
    }

    try {
      final res = await http.get(
        Uri.parse('https://api.github.com/user'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28',
        },
      ).timeout(_timeout);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        return data['login'] as String;
      } else if (res.statusCode == 401) {
        throw Exception('Token tidak valid atau sudah kedaluwarsa (HTTP 401)');
      } else {
        throw Exception('Gagal terhubung ke GitHub (HTTP ${res.statusCode})');
      }
    } on http.ClientException {
      throw Exception('Tidak ada koneksi internet atau server GitHub tidak terjangkau');
    } catch (e) {
      // Menangkap error timeout dari .timeout(_timeout)
      if (e.toString().contains('TimeoutException')) {
        throw Exception('Koneksi ke GitHub terlalu lama (Timeout)');
      }
      rethrow;
    }
  }
}