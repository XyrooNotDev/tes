import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/build_record.dart';
import 'build_store.dart';
import 'github_actions.dart';
import 'notification_service.dart';
import 'session_manager.dart';

class BuildTracker {
  static Future<void> configure() async {
    await FlutterBackgroundService().configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onBuildServiceStart,
        autoStart: false,
        isForegroundMode: true,
        notificationChannelId: kProgressChannelId,
        initialNotificationTitle: 'Santanic Build',
        initialNotificationContent: 'Menyiapkan build...',
        foregroundServiceNotificationId: kProgressNotifId,
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
  }

  static Future<void> start() async {
    final service = FlutterBackgroundService();
    if (await service.isRunning()) {
      service.invoke('stop');
      await Future<void>.delayed(const Duration(seconds: 1));
    }
    await service.startService();
  }
}

@pragma('vm:entry-point')
Future<void> onBuildServiceStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  bool stopped = false;
  service.on('stop').listen((_) {
    stopped = true;
  });

  try {
    // ✅ JANGAN panggil NotificationService.init() di sini.
    // Channel sudah dibuat di main(). Cukup langsung track.
    await _track(service, () => stopped);
  } catch (e) {
    debugPrint('[BuildTracker] Fatal error: $e');
  } finally {
    // ✅ Selalu hentikan service di akhir
    try {
      service.stopSelf();
    } catch (_) {}
  }
}

Future<void> _track(ServiceInstance service, bool Function() stopped) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final token = prefs.getString(SessionManager.kToken) ?? '';
  final loaded = await BuildStore.loadCurrent();

  if (loaded == null || loaded.isFinished || token.isEmpty) {
    debugPrint('[BuildTracker] Tidak ada build berjalan atau token kosong');
    return;
  }

  var rec = loaded;
  final api = GitHubActions(token);
  final deadline = DateTime.fromMillisecondsSinceEpoch(rec.startedAt)
      .add(const Duration(minutes: 60));

  int emptyRunRetries = 0;
  int consecutiveErrors = 0;
  const maxEmptyRetries = 30;       // 30 × 6 detik = 3 menit
  const maxConsecutiveErrors = 20;  // 20 × 6 detik = 2 menit tanpa progress

  debugPrint('[BuildTracker] Mulai tracking: ${rec.owner}/${rec.repo} • ${rec.workflow}');

  await _publish(rec);

  while (!stopped()) {
    // === Cek deadline ===
    if (DateTime.now().isAfter(deadline)) {
      final timeout = rec.copyWith(
        status: 'failure',
        step: 'Melewati batas waktu pelacakan (Timeout 60 menit)',
      );
      await _finish(service, timeout);
      await _notifyError(timeout, 'Build timeout setelah 60 menit');
      return;
    }

    try {
      // === Cari run jika belum ada ===
      if (rec.runId == null) {
        final run = await api.findRun(rec.owner, rec.repo, rec.workflow, rec.baselineRunId);
        if (run != null) {
          debugPrint('[BuildTracker] Run ditemukan: ${run.id}');
          rec = rec.copyWith(runId: run.id, url: run.htmlUrl);
          emptyRunRetries = 0;
        } else {
          emptyRunRetries++;
          debugPrint('[BuildTracker] Run belum ditemukan ($emptyRunRetries/$maxEmptyRetries)');
          if (emptyRunRetries >= maxEmptyRetries) {
            final failed = rec.copyWith(
              status: 'failure',
              step: 'Gagal menemukan workflow run di GitHub',
            );
            await _finish(service, failed);
            await _notifyError(failed, 'Workflow run tidak ditemukan setelah 3 menit');
            return;
          }
        }
      }

      // === Cek progress ===
      final runId = rec.runId;
      if (runId != null) {
        final p = await api.progress(rec.owner, rec.repo, runId);
        final newStatus = p.finished
            ? p.finalStatus
            : (p.status == 'queued' ? 'queued' : 'running');

        final newPercent = p.percent;
        if (newPercent > rec.percent) {
          consecutiveErrors = 0; // ✅ Reset error jika progress bertambah
        }

        rec = rec.copyWith(
          status: newStatus,
          percent: newPercent,
          step: p.stepLabel,
          url: p.htmlUrl,
          diagnostics: p.diagnostics,
        );

        if (p.finished) {
          await _finish(service, rec);
          return;
        }
      }

      // === Simpan & update UI ===
      await BuildStore.saveCurrent(rec);
      service.invoke('update', rec.toJson());
      await _publish(rec);
      consecutiveErrors = 0;

    } catch (e) {
      consecutiveErrors++;
      debugPrint('[BuildTracker] Polling error ($consecutiveErrors/$maxConsecutiveErrors): $e');

      // ✅ Jika error berturut-turut, tandai gagal
      if (consecutiveErrors >= maxConsecutiveErrors) {
        final failed = rec.copyWith(
          status: 'failure',
          step: 'Koneksi ke GitHub terputus. Build dihentikan.',
        );
        await _finish(service, failed);
        await _notifyError(failed, 'Koneksi ke GitHub terputus selama 2 menit');
        return;
      }
    }

    // ✅ Jeda antar polling
    await Future<void>.delayed(const Duration(seconds: 6));
  }

  debugPrint('[BuildTracker] Dihentikan oleh user (stopped=true)');
}

Future<void> _notifyError(BuildRecord rec, String message) async {
  try {
    await NotificationService.showError(
      title: 'Build Gagal ❌',
      body: '${rec.typeLabel} • ${rec.repo}: $message',
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal kirim notifikasi error: $e');
  }
}

Future<void> _publish(BuildRecord rec) async {
  try {
    await NotificationService.showProgress(
      title: 'Build ${rec.typeLabel} • ${rec.repo}',
      body: rec.step.isEmpty ? 'Menunggu runner GitHub...' : rec.step,
      percent: rec.percent,
      indeterminate: rec.percent == 0,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal update notifikasi progress: $e');
  }
}

Future<void> _finish(ServiceInstance service, BuildRecord rec) async {
  try {
    final done = rec.copyWith(
      finishedAt: DateTime.now().millisecondsSinceEpoch,
      percent: rec.isSuccess ? 100 : rec.percent,
      status: rec.isSuccess ? 'success' : 'failure',
    );

    debugPrint('[BuildTracker] Build selesai: ${done.status} (${done.percent}%)');

    // Simpan ke history & hapus current
    await BuildStore.appendHistory(done);
    await BuildStore.clearCurrent();

    // Cancel progress notifikasi
    try {
      await NotificationService.cancelProgress();
    } catch (_) {}

    // Tampilkan notifikasi selesai
    try {
      await NotificationService.showDone(
        title: done.isSuccess ? 'Build selesai ✅' : 'Build gagal ❌',
        body: done.isSuccess
            ? '${done.typeLabel} • ${done.repo} berhasil dibuild. Ketuk untuk melihat.'
            : '${done.typeLabel} • ${done.repo} ${done.statusLabel.toLowerCase()}. Ketuk untuk melihat detail.',
      );
    } catch (e) {
      debugPrint('[BuildTracker] Gagal kirim notifikasi done: $e');
    }

    // Update UI
    service.invoke('update', done.toJson());
  } catch (e) {
    debugPrint('[BuildTracker] Gagal finish: $e');
  }
}