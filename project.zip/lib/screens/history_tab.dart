import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/build_controller.dart';
import '../theme.dart';
import '../widgets/build_progress_view.dart';

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key, required this.controller});

  final BuildController controller;

  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  int _filter = 0;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.controller,
      builder: (context, _) {
        final running = widget.controller.current;
        final allItems = widget.controller.history;

        final items = allItems.where((r) {
          if (_filter == 1) return r.isSuccess;
          if (_filter == 2) return !r.isSuccess;
          return true;
        }).toList();

        final total = allItems.length;
        final success = allItems.where((r) => r.isSuccess).length;
        final failed = total - success;

        return RefreshIndicator(
          onRefresh: widget.controller.reload,
          color: kRed,
          backgroundColor: kCard,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Riwayat Build',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),

              if (running != null) ...[
                BuildProgressView(controller: widget.controller),
                const SizedBox(height: 8),
              ],

              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildFilterChip('Semua', 0),
                    const SizedBox(width: 8),
                    _buildFilterChip('Berhasil', 1),
                    const SizedBox(width: 8),
                    _buildFilterChip('Gagal', 2),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (items.isEmpty && running == null)
                const Padding(
                  padding: EdgeInsets.only(top: 48),
                  child: Center(
                    child: Text('Belum ada riwayat build', style: TextStyle(color: kMuted)),
                  ),
                ),

              for (final r in items)
                Card(
                  color: kCard,
                  margin: const EdgeInsets.only(bottom: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: kBorder, width: 1),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: r.url == null
                        ? null
                        : () => launchUrl(Uri.parse(r.url!), mode: LaunchMode.externalApplication),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: statusColor(r).withOpacity(0.15),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              r.isSuccess ? Icons.check : Icons.close,
                              color: statusColor(r),
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${r.typeLabel} Build',
                                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  timeAgo(r.finishedAt ?? r.startedAt),
                                  style: const TextStyle(color: kMuted, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                          if (r.url != null)
                            const Icon(Icons.download_outlined, color: kMuted, size: 20),
                        ],
                      ),
                    ),
                  ),
                ),

              if (allItems.isNotEmpty) ...[
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.bar_chart, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text('Total Build', style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _buildStatRow('Total Build', total, Colors.white),
                      const SizedBox(height: 8),
                      _buildStatRow('Berhasil', success, kGreen),
                      const SizedBox(height: 8),
                      _buildStatRow('Gagal', failed, kRed),
                    ],
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  Widget _buildFilterChip(String label, int index) {
    final selected = _filter == index;
    return GestureDetector(
      onTap: () => setState(() => _filter = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? kRed : kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? kRed : kBorder),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : kMuted,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            fontSize: 13,
          ),
        ),
      ),
    );
  }

  Widget _buildStatRow(String label, int value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: kMuted, fontSize: 13)),
        Text(
          value.toString(),
          style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14),
        ),
      ],
    );
  }
}