class GitHubApiException implements Exception {
  GitHubApiException(this.statusCode, this.message, {this.endpoint});

  final int statusCode;
  final String message;
  final String? endpoint;
  
  bool get isRetryable =>
      statusCode == 0 ||
      statusCode == 429 ||
      statusCode == 500 ||
      statusCode == 502 ||
      statusCode == 503 ||
      statusCode == 504;

  bool get isAuthError => statusCode == 401 || statusCode == 403;

  bool get isNotFound => statusCode == 404;

  bool get isRateLimited => statusCode == 429 || statusCode == 403;

  String get userFriendlyMessage {
    switch (statusCode) {
      case 400:
        return 'Permintaan tidak valid. Periksa kembali data yang dimasukkan.';
      case 401:
        return 'Token GitHub tidak valid atau sudah kedaluwarsa. Silakan login ulang.';
      case 403:
        return 'Akses ditolak. Pastikan token memiliki izin (scope) "repo" dan "workflow".';
      case 404:
        return 'Repository atau Workflow tidak ditemukan. Periksa kembali nama repo dan file .yml Anda.';
      case 409:
        return 'Konflik terdeteksi. Repository mungkin sedang di-update. Coba lagi.';
      case 422:
        return 'Data tidak valid (HTTP 422). Pastikan workflow file ada di repository dan sudah di-push dengan benar.';
      case 429:
        return 'Terlalu banyak permintaan ke GitHub. Tunggu beberapa saat lalu coba lagi.';
      case 0:
        return 'Koneksi internet terputus atau server GitHub tidak merespons.';
      default:
        if (statusCode >= 500) {
          return 'Server GitHub sedang bermasalah (Error $statusCode). Silakan coba lagi nanti.';
        }
        return message;
    }
  }

  String get debugMessage {
    final buffer = StringBuffer();
    buffer.write('GitHubApiException');
    buffer.write('[HTTP $statusCode]');
    if (endpoint != null) buffer.write(' $endpoint');
    buffer.write(': $message');
    return buffer.toString();
  }

  @override
  String toString() => debugMessage;
}