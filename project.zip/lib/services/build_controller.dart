import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

import '../models/build_record.dart';
import 'artifact_service.dart';
import 'build_store.dart';
import 'build_tracker.dart';
import 'github_actions.dart';
import 'upload_tracker.dart';
import 'session_manager.dart';

class BuildController extends ChangeNotifier {
  BuildController({required this.session});

  final SessionManager session;

  /// Progress UPLOAD (ZIP/workflow/trigger) — terpisah dari progress build.
  final UploadTracker upload = UploadTracker();

  BuildRecord? current;
  List<BuildRecord> history = [];
  StreamSubscription<dynamic>? _sub;

  // Unduhan manual dari UI (tombol Unduh / Unduh ulang)
  bool downloading = false;
  double downloadProgress = 0;
  String? downloadingId;

  // Mode aman: pelacak berjalan di dalam app (tanpa foreground service).
  bool _inApp = false;
  bool _inAppStop = false;

  bool get isRunning => current != null && !current!.isFinished;

  /// Yang ditampilkan di kartu progress: build berjalan, kalau tidak ada maka build terakhir.
  BuildRecord? get display => current ?? (history.isEmpty ? null : history.first);

  BuildRecord? byId(String id) {
    if (current?.id == id) return current;
    for (final h in history) {
      if (h.id == id) return h;
    }
    return null;
  }

  Future<void> init() async {
    await reload();
    _sub = FlutterBackgroundService().on('update').listen((_) => reload());
  }

  Future<void> reload() async {
    current = await BuildStore.loadCurrent();
    history = await BuildStore.loadHistory();
    notifyListeners();

    var serviceRunning = false;
    final useService = await BuildTracker.serviceEnabled();
    if (useService) {
      try {
        serviceRunning = await FlutterBackgroundService().isRunning();
      } catch (_) {}
    }

    if (isRunning) {
      if (useService) {
        // Service mati (misal dimatikan sistem) padahal build masih berjalan: lanjutkan pelacakan.
        if (!serviceRunning) await _startServiceSafely();
      } else if (!_inApp) {
        unawaited(_runInApp());
      }
      return;
    }

    // Unduhan latar belakang yang terhenti (service sudah mati) ditandai gagal supaya bisa diulang.
    if (!downloading && !serviceRunning && !_inApp) {
      final stuck = history.where((r) => r.downloadState == 'downloading').toList();
      if (stuck.isNotEmpty) {
        for (final r in stuck) {
          await BuildStore.appendHistory(r.copyWith(
            downloadState: 'failed',
            downloadError: 'Unduhan terhenti. Ketuk "Unduh ulang".',
          ));
        }
        history = await BuildStore.loadHistory();
        notifyListeners();
      }
    }
  }

  /// Android 12+ melarang memulai foreground service dari latar belakang (bisa membuat app
  /// force close). Jadi service hanya dimulai saat app tampil di depan; kalau tidak,
  /// otomatis dimulai begitu app dibuka lagi (lihat [reload]).
  Future<void> _startServiceSafely() async {
    final state = WidgetsBinding.instance.lifecycleState;
    if (state != null && state != AppLifecycleState.resumed) return;
    try {
      await BuildTracker.start();
    } catch (e) {
      debugPrint('Gagal memulai service pelacak: $e');
    }
  }

  Future<void> _runInApp() async {
    if (_inApp) return;
    _inApp = true;
    _inAppStop = false;
    try {
      await trackBuild(
        invoke: (m, a) {
          if (m == 'update') unawaited(reload());
        },
        stopped: () => _inAppStop,
        background: false,
      );
    } catch (e) {
      debugPrint('Pelacak dalam app berhenti: $e');
    } finally {
      _inApp = false;
      await reload();
    }
  }

  Future<void> begin(BuildRecord rec) async {
    current = rec;
    await BuildStore.saveCurrent(rec);
    notifyListeners();
    if (await BuildTracker.serviceEnabled()) {
      await _startServiceSafely();
    } else {
      unawaited(_runInApp());
    }
  }

  /// Membatalkan build yang sedang berjalan.
  Future<void> cancelBuild() async {
    final rec = current;
    if (rec == null || rec.isFinished || rec.runId == null) return;

    try {
      final token = await session.getToken();
      if (token.isEmpty) {
        throw Exception('Token tidak ditemukan, silakan login ulang.');
      }

      final api = GitHubActions(token);
      await api.cancelRun(rec.owner, rec.repo, rec.runId!);

      final cancelled = rec.copyWith(
        status: 'cancelled',
        step: 'Dibatalkan oleh pengguna',
        finishedAt: DateTime.now().millisecondsSinceEpoch,
      );

      // Hentikan pelacak (service maupun dalam app).
      _inAppStop = true;
      try {
        FlutterBackgroundService().invoke('stop');
      } catch (_) {}

      await BuildStore.appendHistory(cancelled);
      await BuildStore.clearCurrent();

      current = null;
      history = await BuildStore.loadHistory();
      notifyListeners();
    } catch (e) {
      debugPrint('Gagal membatalkan build: $e');
      rethrow;
    }
  }

  /// Unduh artifact build → ekstrak APK ke penyimpanan aplikasi.
  Future<void> downloadApk(BuildRecord rec) async {
    if (downloading) return;
    downloading = true;
    downloadingId = rec.id;
    downloadProgress = 0;
    notifyListeners();

    var lastNotified = 0.0;
    try {
      final token = await session.getToken();
      if (token.isEmpty) throw Exception('Token tidak ditemukan, silakan login ulang.');

      final path = await ArtifactService(token).downloadApk(
        rec: rec,
        onProgress: (f) {
          downloadProgress = f;
          if (f - lastNotified >= 0.01 || f >= 1.0) {
            lastNotified = f;
            notifyListeners();
          }
        },
      );
      await BuildStore.appendHistory(rec.copyWith(
        apkPath: path,
        downloadState: 'done',
        downloadPercent: 100,
        downloadError: '',
      ));
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      await BuildStore.appendHistory(rec.copyWith(
        downloadState: 'failed',
        downloadError: msg,
      ));
      downloading = false;
      downloadingId = null;
      await reload();
      rethrow;
    }

    downloading = false;
    downloadingId = null;
    await reload();
  }

  Future<void> installApk(BuildRecord rec) async {
    final path = rec.apkPath;
    if (path == null || path.isEmpty) {
      throw Exception('APK belum diunduh.');
    }
    await ArtifactService.install(path);
  }

  /// Simpan APK ke folder publik Download/SantanicBuild. Mengembalikan lokasi file.
  Future<String> saveToDownloads(BuildRecord rec) async {
    final path = rec.apkPath;
    if (path == null || path.isEmpty) {
      throw Exception('APK belum diunduh.');
    }
    final name = '${rec.repo}_${rec.typeLabel.replaceAll(' ', '')}_${rec.mode.isEmpty ? 'build' : rec.mode}_${rec.runNumber ?? rec.id}.apk';
    return ArtifactService.saveToDownloads(path, name);
  }

  @override
  void dispose() {
    _sub?.cancel();
    upload.dispose();
    super.dispose();
  }
}
