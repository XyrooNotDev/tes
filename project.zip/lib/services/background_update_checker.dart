import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'notification_service.dart';
import 'update_service.dart';
import '../nav.dart';

class BackgroundUpdateChecker {
  static Timer? _timer;
  static UpdateInfo? _lastFound;

  static UpdateInfo? get lastFound => _lastFound;

  static Future<void> start({Duration interval = const Duration(hours: 6)}) async {
    _checkNow();
    _timer?.cancel();
    _timer = Timer.periodic(interval, (_) => _checkNow());
  }

  static void stop() {
    _timer?.cancel();
    _timer = null;
  }

  static Future<void> _checkNow() async {
    try {
      final info = await UpdateService.checkUpdate();
      if (info == null || !info.hasUpdate) return;

      _lastFound = info;

      await NotificationService.showUpdateAvailable(
        title: '🚀 Update Tersedia (v${info.latestVersion})',
        body: 'Versi baru Santanic Build sudah tersedia. Ketuk untuk update.',
      );
    } catch (e) {
      debugPrint('Background update check error: $e');
    }
  }

  static void onUpdateNotifTapped() {
    AppNav.tabIndex.value = AppNav.profileTab;
  }
}