import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/build_record.dart';
import '../services/build_controller.dart';
import '../theme.dart';

Color statusColor(BuildRecord r) {
  if (!r.isFinished) return const Color(0xFFFFC107);
  return r.isSuccess ? kGreen : kRed;
}

class BuildProgressView extends StatelessWidget {
  const BuildProgressView({super.key, required this.controller});

  final BuildController controller;

  Future<void> _confirmCancel(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Batalkan Build?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Build yang sedang berjalan akan dihentikan secara paksa di GitHub Actions.',
          style: TextStyle(color: kMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Tidak', style: TextStyle(color: kMuted)),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: kRed),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Ya, Batalkan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      try {
        await controller.cancelBuild();
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Build berhasil dibatalkan'),
              backgroundColor: kCard,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Gagal membatalkan: ${e.toString().replaceFirst('Exception: ', '')}'),
              backgroundColor: kRed,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        final r = controller.display;

        if (r == null) {
          return const Center(
            child: Text(
              'Belum ada riwayat build.',
              style: TextStyle(color: kMuted, fontSize: 14),
            ),
          );
        }

        final color = statusColor(r);
        final progress = (r.percent / 100).clamp(0.0, 1.0);

        return Card(
          color: kCard,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: Color(0xFF22222A)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        r.isFinished ? 'Build Selesai' : 'Sedang Build...',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    if (!r.isFinished)
                      TextButton.icon(
                        onPressed: () => _confirmCancel(context),
                        icon: const Icon(Icons.stop_circle_outlined, color: kRed, size: 18),
                        label: const Text('Batal', style: TextStyle(color: kRed, fontSize: 12)),
                        style: TextButton.styleFrom(
                          side: const BorderSide(color: kRed, width: 1),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        ),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          r.statusLabel.toUpperCase(),
                          style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${r.typeLabel} • ${r.owner}/${r.repo}',
                  style: const TextStyle(color: kMuted, fontSize: 12),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 24),
                Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: r.isFinished ? 1.0 : (r.percent == 0 ? null : progress),
                          strokeWidth: 8,
                          backgroundColor: const Color(0xFF22222A),
                          valueColor: AlwaysStoppedAnimation<Color>(color),
                          strokeCap: StrokeCap.round,
                        ),
                      ),
                      Text(
                        '${r.percent}%',
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                Center(
                  child: Text(
                    r.step.isEmpty ? 'Menunggu runner GitHub...' : r.step,
                    style: const TextStyle(color: kMuted, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 20),

                // ✅ Null-safe untuk diagnostics
                if (r.diagnostics.isNotEmpty) ...[
                  const Text(
                    'Live Log',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    constraints: const BoxConstraints(maxHeight: 150),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF09090B),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: const Color(0xFF22222A)),
                    ),
                    child: SingleChildScrollView(
                      child: SelectableText(
                        r.diagnostics.join('\n'),
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 11,
                          color: Color(0xFF00E676),
                          height: 1.4,
                        ),
                      ),
                    ),
                  ),
                ],

                // ✅ Null-safe untuk url
                if (r.url != null && r.url!.isNotEmpty && r.isFinished) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: r.isSuccess ? kGreen : kRed,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        final url = r.url;
                        if (url != null && url.isNotEmpty) {
                          launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                        }
                      },
                      icon: Icon(r.isSuccess ? Icons.download : Icons.open_in_new, color: Colors.black),
                      label: Text(
                        r.isSuccess ? 'Download APK' : 'Buka di GitHub',
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}