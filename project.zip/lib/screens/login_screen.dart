import 'package:flutter/material.dart';

import '../services/github_auth.dart';
import '../services/session_manager.dart';
import '../theme.dart'; // Pastikan kRed, kCard, kMuted, dll terdefinisi di sini

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.session, required this.onLoggedIn});

  final SessionManager session;
  final VoidCallback onLoggedIn;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _auth = GitHubAuth();
  final _tokenController = TextEditingController();

  String _status = '';
  bool _busy = false;
  bool _obscureToken = true;

  @override
  void dispose() {
    _tokenController.dispose();
    super.dispose();
  }

  String _clean(Object e) => e.toString().replaceFirst('Exception: ', '');

  Future<void> _finish(String token, String username) async {
    await widget.session.saveSession(token, username);
    if (!mounted) return;
    widget.onLoggedIn();
  }

  Future<void> _loginWithToken() async {
    final token = _tokenController.text.trim();
    if (token.isEmpty) {
      setState(() => _status = 'Token tidak boleh kosong');
      return;
    }

    setState(() {
      _busy = true;
      _status = '';
    });

    try {
      final user = await _auth.fetchUsername(token);

      if (mounted) setState(() => _status = 'Login berhasil! Mengambil data...');

      // 2. Simpan session
      await _finish(token, user);
    } catch (e) {
      if (mounted) {
        setState(() => _status = 'Error: Token tidak valid atau ${_clean(e)}');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg, // ✅ Diperbaiki: kBg sesuai theme.dart Anda
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: Column(
              children: [
                // Logo
                ClipRRect(
                  borderRadius: BorderRadius.circular(24),
                  child: Image.asset(
                    'assets/images/logo_santanic.jpg',
                    width: 120,
                    height: 120,
                    errorBuilder: (_, __, ___) => Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: kBorder),
                      ),
                      child: const Icon(Icons.android, size: 60, color: kRed),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Judul
                const Text(
                  'SANTANIC',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1.5,
                  ),
                ),
                const Text(
                  'BUILD',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: kRed,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Build APK Android\ndengan GitHub Actions',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: kMuted, fontSize: 14, height: 1.5),
                ),
                const SizedBox(height: 40),

                // Card Login
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kBorder, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Header Card
                      const Row(
                        children: [
                          Icon(Icons.security, color: Colors.white, size: 24),
                          SizedBox(width: 12),
                          Text(
                            'Login GitHub',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Masuk dengan Personal Access Token (PAT)',
                        style: TextStyle(color: kMuted, fontSize: 12),
                      ),
                      const SizedBox(height: 24),

                      // Input Token
                      TextField(
                        controller: _tokenController,
                        obscureText: _obscureToken,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Token GitHub',
                          hintStyle: const TextStyle(color: kMuted),
                          filled: true,
                          fillColor: kInputBg, // ✅ Menggunakan warna dari theme
                          prefixIcon: const Icon(Icons.key, color: kMuted, size: 20),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureToken ? Icons.visibility_off : Icons.visibility,
                              color: kMuted,
                            ),
                            onPressed: () {
                              setState(() => _obscureToken = !_obscureToken);
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Tombol Login
                      FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: kRed,
                          minimumSize: const Size.fromHeight(50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: _busy ? null : _loginWithToken,
                        child: _busy
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text(
                                'Login',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                              ),
                      ),

                      // Status / Error Message
                      if (_status.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        Text(
                          _status,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: _status.startsWith('Error') ? Colors.redAccent : kGreen,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 32),

                // Footer
                const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.check_circle, color: kGreen, size: 16),
                    SizedBox(width: 8),
                    Text(
                      'Session akan disimpan untuk penggunaan berikutnya',
                      style: TextStyle(color: kGreen, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}