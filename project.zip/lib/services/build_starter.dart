import 'dart:io';

import '../models/build_record.dart';
import 'build_controller.dart';
import 'github_actions.dart';
import 'github_api_exception.dart';
import 'github_uploader.dart';
import 'permission_helper.dart';
import 'session_manager.dart';
import 'workflow_resolver.dart';

class BuildStarter {
  /// Alur build ZIP (Android Studio / Flutter):
  /// 1. pilih workflow (.yml pengguna, atau bawaan assets bila tidak ada)
  /// 2. upload project.zip + workflow ke repo
  /// 3. tunggu workflow terdeteksi → picu → serahkan pelacakan ke service latar belakang
  ///
  /// Mengembalikan peringatan (mis. izin notifikasi ditolak) atau null.
  static Future<String?> startZipBuild({
    required SessionManager session,
    required BuildController controller,
    required String type,
    required String owner,
    required String repo,
    required String zipPath,
    required String mode,
    required String assetPath,
    required String defaultWorkflowName,
    required String label,
    String? customYmlPath,
    required void Function(String text) onStatus,
  }) async {
    String? warning;
    final up = controller.upload;
    up.begin('$label • $owner/$repo', const [
      'Memeriksa izin & workflow',
      'Menyiapkan repository',
      'Mengunggah project.zip',
      'Mengunggah workflow & commit',
      'Menunggu workflow siap',
      'Memicu build',
    ]);

    try {
      onStatus('Mengunggah...');
      up.startStep(0, detail: 'Memeriksa izin...');
      final notifOk = await PermissionHelper.ensureNotifications();
      if (!notifOk) {
        warning = 'Izin notifikasi ditolak: progress build tidak akan muncul sebagai popup.';
      }
      await PermissionHelper.requestBatteryExemptionOnce();

      up.startStep(0, detail: customYmlPath == null ? 'Workflow bawaan' : 'Workflow kustom');
      final wf = await WorkflowResolver.resolve(
        customPath: customYmlPath,
        assetPath: assetPath,
        defaultName: defaultWorkflowName,
      );

      final token = await session.getToken();
      if (token.isEmpty) throw Exception('Token tidak ditemukan, silakan login ulang.');
      final uploader = GitHubUploader(token, owner, repo);

      up.startStep(1, detail: '$owner/$repo');
      final created = await uploader.ensureRepoExists();
      if (created) up.startStep(1, detail: 'Repo baru dibuat');

      final zipSize = await File(zipPath).length();
      String mb(num bytes) => (bytes / (1024 * 1024)).toStringAsFixed(1);

      up.startStep(2, detail: '0.0 / ${mb(zipSize)} MB', withPercent: true);
      final branch = await uploader.uploadZipWithWorkflow(
        zipPath: zipPath,
        workflowFileName: wf.fileName,
        workflowContent: wf.content,
        commitMessage:
            'Santanic Build: upload project.zip + ${wf.isCustom ? 'workflow kustom' : 'workflow $label'}',
        onFileProgress: (file, f, sent, total) =>
            up.setFraction(f, '${mb(zipSize * f)} / ${mb(zipSize)} MB'),
        onFilesDone: () => up.startStep(3, detail: wf.fileName),
      );

      up.startStep(4, detail: wf.fileName);
      final actions = GitHubActions(token);
      final ready = await actions.waitForWorkflowReady(owner, repo, wf.fileName);
      if (!ready) {
        throw GitHubApiException(
          404,
          'Workflow ${wf.fileName} tidak terdeteksi di GitHub. Pastikan Actions aktif di repo, lalu coba lagi.',
        );
      }

      final baseline = await actions.latestRunId(owner, repo, wf.fileName);

      up.startStep(5, detail: mode);
      await actions.triggerWorkflow(
        owner,
        repo,
        wf.fileName,
        branch,
        inputs: wf.buildInputs(mode),
      );

      await controller.begin(BuildRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: type,
        owner: owner,
        repo: repo,
        workflow: wf.fileName,
        startedAt: DateTime.now().millisecondsSinceEpoch,
        baselineRunId: baseline,
        step: 'Menunggu runner GitHub...',
        mode: mode,
        customWorkflow: wf.isCustom,
      ));

      up.complete();
      return warning;
    } catch (e) {
      up.fail(e.toString().replaceFirst('Exception: ', ''));
      rethrow;
    }
  }
}
