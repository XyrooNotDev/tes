class GitHubApiException implements Exception {
  GitHubApiException(this.statusCode, this.message);

  final int statusCode;
  final String message;

  bool get isRetryable =>
      statusCode == 0 ||
      statusCode == 429 ||
      statusCode == 500 ||
      statusCode == 502 ||
      statusCode == 503 ||
      statusCode == 504;

  /// Pesan error yang ramah pengguna (untuk ditampilkan di UI/Notifikasi)
  String get userFriendlyMessage {
    switch (statusCode) {
      case 401:
        return 'Token GitHub tidak valid atau sudah kedaluwarsa. Silakan login ulang.';
      case 403:
        return 'Akses ditolak. Pastikan token memiliki izin (scope) "repo" dan "workflow".';
      case 404:
        return 'Repository atau Workflow tidak ditemukan. Periksa kembali nama repo dan file .yml Anda.';
      case 429:
        return 'Terlalu banyak permintaan ke GitHub. Tunggu beberapa saat lalu coba lagi.';
      case 0:
        return 'Koneksi internet terputus atau server GitHub tidak merespons.';
      default:
        if (statusCode >= 500) {
          return 'Server GitHub sedang bermasalah (Error $statusCode). Silakan coba lagi nanti.';
        }
        return message;
    }
  }

  @override
  String toString() => 'GitHubApiException(HTTP $statusCode): $message';
}