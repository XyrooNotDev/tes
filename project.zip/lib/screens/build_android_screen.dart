import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/build_record.dart';
import '../nav.dart';
import '../services/build_controller.dart';
import '../services/github_actions.dart';
import '../services/github_api_exception.dart';
import '../services/github_uploader.dart';
import '../services/notification_service.dart';
import '../services/session_manager.dart';
import '../theme.dart';
import '../widgets/build_progress_view.dart';
import '../widgets/repo_selector.dart';

class BuildAndroidScreen extends StatefulWidget {
  const BuildAndroidScreen({super.key, required this.session, required this.controller});
  final SessionManager session;
  final BuildController controller;

  @override
  State<BuildAndroidScreen> createState() => _BuildAndroidScreenState();
}

class _BuildAndroidScreenState extends State<BuildAndroidScreen> {
  late final TextEditingController _owner = TextEditingController(text: widget.session.username);
  final _repo = TextEditingController();
  String? _zipPath;
  String? _token;
  bool _busy = false;
  String _busyText = '';
  String _buildType = 'release';

  static const String _workflowName = 'build_android.yml';
  static const String _assetPath = 'assets/workflows/build_android.yml';

  @override
  void initState() {
    super.initState();
    _loadToken();
  }

  Future<void> _loadToken() async {
    final t = await widget.session.getToken();
    if (mounted) setState(() => _token = t);
  }

  @override
  void dispose() {
    _owner.dispose();
    _repo.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: kCard,
        behavior: SnackBarBehavior.floating,
      ));
  }

  Future<void> _notifyError(String message) async {
    await NotificationService.showError(
      title: 'Build Gagal Dimulai ❌',
      body: message.length > 100 ? '${message.substring(0, 100)}...' : message,
    );
  }

  Future<void> _pickZip() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
    );
    if (res == null || res.files.isEmpty) return;
    setState(() => _zipPath = res.files.first.path);
  }

  Future<void> _start() async {
    final owner = _owner.text.trim();
    final repo = _repo.text.trim();

    if (owner.isEmpty || repo.isEmpty) {
      _snack('Lengkapi Username dan Repository!');
      return;
    }
    if (_zipPath == null) {
      _snack('Pilih file ZIP project Android!');
      return;
    }
    if (widget.controller.isRunning) {
      _snack('Masih ada build berjalan.');
      return;
    }

    setState(() {
      _busy = true;
      _busyText = 'Menyiapkan repository...';
    });

    try {
      await NotificationService.requestPermission();
      final token = await widget.session.getToken();
      final uploader = GitHubUploader(token, owner, repo);

      final created = await uploader.ensureRepoExists();
      if (created && mounted) {
        setState(() => _busyText = 'Repo dibuat, mengunggah...');
      }

      if (mounted) setState(() => _busyText = 'Mengunggah project.zip + workflow...');
      final branch = await uploader.uploadZipWithBuiltinWorkflow(
        zipPath: _zipPath!,
        assetWorkflowPath: _assetPath,
        workflowName: _workflowName,
        commitMessage: 'Santanic Build: upload project.zip + workflow Android',
      );

      if (mounted) setState(() => _busyText = 'Menunggu workflow siap...');
      final actions = GitHubActions(token);
      final ready = await actions.waitForWorkflowReady(owner, repo, _workflowName);
      if (!ready) {
        throw GitHubApiException(404, 'Workflow tidak terdeteksi di GitHub. Coba lagi dalam 30 detik.');
      }

      final baseline = await actions.latestRunId(owner, repo, _workflowName);

      if (mounted) setState(() => _busyText = 'Memicu workflow ($_buildType)...');
      await actions.triggerWorkflow(
        owner, repo, _workflowName, branch,
        inputs: {'build_type': _buildType},
      );

      await widget.controller.begin(BuildRecord(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: AppNav.buildAndroid,
        owner: owner,
        repo: repo,
        workflow: _workflowName,
        startedAt: DateTime.now().millisecondsSinceEpoch,
        baselineRunId: baseline,
        step: 'Menunggu runner GitHub...',
      ));

      _snack('Build Android ($_buildType) dimulai!');
      setState(() => _zipPath = null);
    } on GitHubApiException catch (e) {
      _snack('Gagal: ${e.message}');
      await _notifyError(e.message);
    } catch (e) {
      _snack('Gagal: ${e.toString().replaceFirst('Exception: ', '')}');
      await _notifyError(e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('Build Android Studio'),
        backgroundColor: kBg,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: ListenableBuilder(
        listenable: widget.controller,
        builder: (context, _) {
          final display = widget.controller.display;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (display != null) ...[
                BuildProgressView(controller: widget.controller),
                const SizedBox(height: 16),
              ],

              const Text('Username GitHub', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              TextField(
                controller: _owner,
                readOnly: true,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.person_outline),
                  filled: true,
                  fillColor: kInputBg,
                ),
              ),
              const SizedBox(height: 16),

              const Text('Repository', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              if (_token != null && _token!.isNotEmpty)
                RepoSelector(
                  token: _token!,
                  owner: _owner.text,
                  onRepoChanged: (v) => _repo.text = v,
                )
              else
                const Center(child: Padding(
                  padding: EdgeInsets.all(16),
                  child: CircularProgressIndicator(color: kRed),
                )),
              const SizedBox(height: 20),

              const Text('Mode Build', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _buildTypeChip(
                      label: '🚀 Release',
                      selected: _buildType == 'release',
                      onTap: () => setState(() => _buildType = 'release'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildTypeChip(
                      label: '🐛 Debug',
                      selected: _buildType == 'debug',
                      onTap: () => setState(() => _buildType = 'debug'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              const Text('File Project', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 8),
              InkWell(
                onTap: _busy ? null : _pickZip,
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: kInputBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: kBorder),
                  ),
                  child: Column(
                    children: [
                      Icon(Icons.cloud_upload_outlined, size: 40, color: _zipPath != null ? kRed : kMuted),
                      const SizedBox(height: 12),
                      Text(
                        _zipPath != null
                            ? 'ZIP: ${_zipPath!.split('/').last}'
                            : 'Upload ZIP Project Android',
                        style: TextStyle(color: _zipPath != null ? Colors.white : kMuted, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Akan disimpan sebagai project.zip',
                        style: TextStyle(fontSize: 11, color: kMuted),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              FilledButton.icon(
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(56),
                  backgroundColor: kRed,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _busy ? null : _start,
                icon: _busy
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.rocket_launch, size: 20),
                label: Text(
                  _busy ? _busyText : 'Mulai Build ${_buildType == 'release' ? 'Release' : 'Debug'}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              const SizedBox(height: 24),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTypeChip({
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: selected ? kRed.withOpacity(0.15) : kCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? kRed : kBorder),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? kRed : kMuted,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }
}