import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../services/session_manager.dart';
import '../theme.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key, required this.session, required this.onLogout});
  final SessionManager session;
  final VoidCallback onLogout;

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  Map<String, dynamic>? _githubProfile;
  bool _isLoadingProfile = true;

  @override
  void initState() {
    super.initState();
    _fetchGitHubProfile();
  }

  Future<void> _fetchGitHubProfile() async {
    try {
      final token = await widget.session.getToken();
      if (token.isEmpty) return;

      final res = await http.get(
        Uri.parse('https://api.github.com/user'),
        headers: {
          'Authorization': 'Bearer $token',
          'Accept': 'application/vnd.github+json',
        },
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        if (mounted) {
          setState(() {
            _githubProfile = jsonDecode(res.body) as Map<String, dynamic>;
            _isLoadingProfile = false;
          });
        }
      } else {
        if (mounted) setState(() => _isLoadingProfile = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isLoadingProfile = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Profil', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),

        Card(
          color: kCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: kBorder),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: _isLoadingProfile
                ? const Center(child: CircularProgressIndicator(color: kRed))
                : _githubProfile == null
                    ? const Center(child: Text('Gagal memuat profil GitHub', style: TextStyle(color: kMuted)))
                    : Column(
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 32,
                                backgroundColor: kInputBg,
                                backgroundImage: NetworkImage(_githubProfile!['avatar_url'] ?? ''),
                                onBackgroundImageError: (_, __) {},
                                child: _githubProfile!['avatar_url'] == null
                                    ? const Icon(Icons.person, color: kMuted, size: 32)
                                    : null,
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _githubProfile!['name'] ?? widget.session.username,
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      '@${_githubProfile!['login'] ?? widget.session.username}',
                                      style: const TextStyle(color: kMuted, fontSize: 13),
                                    ),
                                    if (_githubProfile!['bio'] != null) ...[
                                      const SizedBox(height: 6),
                                      Text(
                                        _githubProfile!['bio'],
                                        style: const TextStyle(color: kMuted, fontSize: 12, fontStyle: FontStyle.italic),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              const Icon(Icons.verified, color: kGreen),
                            ],
                          ),
                          const SizedBox(height: 20),
                          const Divider(color: kBorder, height: 1),
                          const SizedBox(height: 16),
                          
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              _buildStatItem('Repositori', _githubProfile!['public_repos']?.toString() ?? '0'),
                              _buildStatItem('Pengikut', _githubProfile!['followers']?.toString() ?? '0'),
                              _buildStatItem('Mengikuti', _githubProfile!['following']?.toString() ?? '0'),
                            ],
                          ),
                        ],
                      ),
          ),
        ),
        const SizedBox(height: 20),

        Card(
          color: kCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: kBorder),
          ),
          child: const Column(
            children: [
              ListTile(
                leading: Icon(Icons.info_outline, color: kMuted),
                title: Text('Versi Aplikasi'),
                subtitle: Text('Santanic Build v1.1.2'),
              ),
              Divider(height: 1, color: kBorder),
              ListTile(
                leading: Icon(Icons.code, color: kMuted),
                title: Text('Developer'),
                subtitle: Text('Xyroo'),
              ),
              Divider(height: 1, color: kBorder),
              ListTile(
                leading: Icon(Icons.support_agent, color: kMuted),
                title: Text('Support'),
                subtitle: Text('Yoga • Suika • Yanz • Fahmi'),
              ),
              Divider(height: 1, color: kBorder),
              ListTile(
                leading: Icon(Icons.storage, color: kMuted),
                title: Text('Riwayat Build'),
                subtitle: Text('Disimpan permanen di perangkat sampai kamu menghapus data aplikasi'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),

        OutlinedButton.icon(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(50),
            foregroundColor: kRed,
            side: const BorderSide(color: kRed),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          onPressed: widget.onLogout,
          icon: const Icon(Icons.logout),
          label: const Text('Keluar dari GitHub', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(color: kMuted, fontSize: 12),
        ),
      ],
    );
  }
}