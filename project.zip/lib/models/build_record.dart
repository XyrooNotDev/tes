class BuildRecord {
  const BuildRecord({
    required this.id,
    required this.type,
    required this.owner,
    required this.repo,
    required this.workflow,
    required this.startedAt,
    this.finishedAt,
    this.status = 'queued',
    this.percent = 0,
    this.step = '',
    this.runId,
    this.baselineRunId = 0,
    this.url,
    this.artifactsUrl,   // ✅ URL download artifact (zip)
    this.diagnostics = const [],
    this.isInstalled = false, // ✅ Status install APK
  });

  final String id;
  final String type; // ANDROID | FLUTTER | WEBTOAPK
  final String owner;
  final String repo;
  final String workflow;
  final int startedAt;
  final int? finishedAt;
  final String status; // queued | running | success | failure | cancelled
  final int percent;
  final String step;
  final int? runId;
  final int baselineRunId;
  final String? url;
  final String? artifactsUrl;
  final List<String> diagnostics;
  final bool isInstalled;

  bool get isFinished =>
      status == 'success' || status == 'failure' || status == 'cancelled';
  bool get isSuccess => status == 'success';

  String get typeLabel {
    switch (type) {
      case 'FLUTTER':
        return 'Flutter';
      case 'WEBTOAPK':
        return 'WebToAPK';
      case 'ANDROID':
      default:
        return 'Android Studio';
    }
  }

  String get statusLabel {
    switch (status) {
      case 'queued':
        return 'Mengantre';
      case 'running':
        return 'Berjalan';
      case 'success':
        return 'Berhasil';
      case 'cancelled':
        return 'Dibatalkan';
      case 'failure':
      default:
        return 'Gagal';
    }
  }

  BuildRecord copyWith({
    int? finishedAt,
    String? status,
    int? percent,
    String? step,
    int? runId,
    String? url,
    String? artifactsUrl,
    List<String>? diagnostics,
    bool? isInstalled,
  }) {
    return BuildRecord(
      id: id,
      type: type,
      owner: owner,
      repo: repo,
      workflow: workflow,
      startedAt: startedAt,
      finishedAt: finishedAt ?? this.finishedAt,
      status: status ?? this.status,
      percent: percent ?? this.percent,
      step: step ?? this.step,
      runId: runId ?? this.runId,
      baselineRunId: baselineRunId,
      url: url ?? this.url,
      artifactsUrl: artifactsUrl ?? this.artifactsUrl,
      diagnostics: diagnostics ?? this.diagnostics,
      isInstalled: isInstalled ?? this.isInstalled,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'owner': owner,
        'repo': repo,
        'workflow': workflow,
        'startedAt': startedAt,
        'finishedAt': finishedAt,
        'status': status,
        'percent': percent,
        'step': step,
        'runId': runId,
        'baselineRunId': baselineRunId,
        'url': url,
        'artifactsUrl': artifactsUrl,
        'diagnostics': diagnostics,
        'isInstalled': isInstalled,
      };

  factory BuildRecord.fromJson(Map<String, dynamic> j) => BuildRecord(
        id: j['id'] as String,
        type: j['type'] as String? ?? 'ANDROID',
        owner: j['owner'] as String? ?? '',
        repo: j['repo'] as String? ?? '',
        workflow: j['workflow'] as String? ?? '',
        startedAt: (j['startedAt'] as num).toInt(),
        finishedAt: (j['finishedAt'] as num?)?.toInt(),
        status: j['status'] as String? ?? 'queued',
        percent: (j['percent'] as num?)?.toInt() ?? 0,
        step: j['step'] as String? ?? '',
        runId: (j['runId'] as num?)?.toInt(),
        baselineRunId: (j['baselineRunId'] as num?)?.toInt() ?? 0,
        url: j['url'] as String?,
        artifactsUrl: j['artifactsUrl'] as String?,
        diagnostics:
            (j['diagnostics'] as List?)?.map((e) => e.toString()).toList() ??
                const [],
        isInstalled: j['isInstalled'] as bool? ?? false,
      );
}