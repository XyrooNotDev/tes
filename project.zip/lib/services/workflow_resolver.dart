import 'dart:io';

import 'package:flutter/services.dart';
import 'package:yaml/yaml.dart';

/// Hasil pemilihan workflow: .yml milik pengguna, atau bawaan dari assets.
class ResolvedWorkflow {
  const ResolvedWorkflow({
    required this.fileName,
    required this.content,
    required this.isCustom,
    required this.inputNames,
  });

  /// Nama file di .github/workflows/
  final String fileName;
  final String content;
  final bool isCustom;

  /// Nama input yang dideklarasikan di workflow_dispatch.
  final Set<String> inputNames;

  /// Input yang dikirim saat memicu workflow. Workflow kustom hanya menerima
  /// input yang memang dideklarasikan (input asing membuat GitHub menolak dengan 422).
  Map<String, String> buildInputs(String mode) {
    final out = <String, String>{};
    if (!isCustom || inputNames.contains('build_type')) out['build_type'] = mode;
    for (final n in const ['source_zip', 'zip_name', 'zip_path', 'zip_file']) {
      if (isCustom && inputNames.contains(n)) out[n] = 'project.zip';
    }
    return out;
  }
}

class WorkflowResolver {
  static const Set<String> _fillable = {
    'build_type',
    'source_zip',
    'zip_name',
    'zip_path',
    'zip_file',
  };

  /// [customPath] kosong/null → pakai file bawaan di [assetPath].
  static Future<ResolvedWorkflow> resolve({
    String? customPath,
    required String assetPath,
    required String defaultName,
  }) async {
    if (customPath == null || customPath.isEmpty) {
      final content = await rootBundle.loadString(assetPath);
      final info = inspect(content);
      return ResolvedWorkflow(
        fileName: defaultName,
        content: content,
        isCustom: false,
        inputNames: info,
      );
    }

    final file = File(customPath);
    if (!await file.exists()) {
      throw Exception('File .yml tidak ditemukan di perangkat.');
    }
    String content;
    try {
      content = await file.readAsString();
    } catch (_) {
      throw Exception('File .yml tidak bisa dibaca (bukan teks UTF-8).');
    }
    final inputs = inspect(content, strictInputs: true);
    return ResolvedWorkflow(
      fileName: safeFileName(customPath),
      content: content,
      isCustom: true,
      inputNames: inputs,
    );
  }

  static String safeFileName(String path) {
    var name = path.replaceAll('\\', '/').split('/').last.trim();
    name = name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final lower = name.toLowerCase();
    if (name.isEmpty || name == '.yml' || name == '.yaml') return 'custom_build.yml';
    if (!lower.endsWith('.yml') && !lower.endsWith('.yaml')) name = '$name.yml';
    return name;
  }

  /// Validasi isi workflow dan kembalikan nama-nama input workflow_dispatch.
  /// Melempar Exception berpesan jelas kalau workflow tidak bisa dipicu dari aplikasi.
  static Set<String> inspect(String content, {bool strictInputs = false}) {
    dynamic doc;
    try {
      doc = loadYaml(content);
    } catch (e) {
      final first = e.toString().split('\n').first;
      throw Exception('Isi .yml tidak valid: $first');
    }
    if (doc is! Map) {
      throw Exception('Isi .yml bukan workflow GitHub Actions yang valid.');
    }
    if (!doc.containsKey('jobs')) {
      throw Exception('Workflow tidak punya bagian "jobs:".');
    }

    final dynamic on = doc.containsKey('on') ? doc['on'] : doc[true];
    var hasDispatch = false;
    final inputs = <String>{};
    final missing = <String>[];

    if (on is String) {
      hasDispatch = on == 'workflow_dispatch';
    } else if (on is List) {
      hasDispatch = on.contains('workflow_dispatch');
    } else if (on is Map) {
      hasDispatch = on.containsKey('workflow_dispatch');
      final wd = on['workflow_dispatch'];
      if (wd is Map && wd['inputs'] is Map) {
        final map = wd['inputs'] as Map;
        for (final key in map.keys) {
          final name = key.toString();
          inputs.add(name);
          final def = map[key];
          if (def is Map) {
            final isRequired = def['required'] == true;
            final hasDefault = def.containsKey('default');
            if (isRequired && !hasDefault && !_fillable.contains(name)) {
              missing.add(name);
            }
          }
        }
      }
    }

    if (!hasDispatch) {
      throw Exception(
        'Workflow harus punya trigger "workflow_dispatch" supaya bisa dijalankan dari aplikasi.',
      );
    }
    if (strictInputs && missing.isNotEmpty) {
      throw Exception(
        'Workflow punya input wajib tanpa nilai default: ${missing.join(', ')}. '
        'Beri "default:" pada input itu di file .yml.',
      );
    }
    return inputs;
  }
}
