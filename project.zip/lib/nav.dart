import 'package:flutter/foundation.dart';

class AppNav {
  static const int homeTab = 0;
  static const int statusTab = 1;
  static const int historyTab = 2;
  static const int profileTab = 3;

  static const String buildAndroid = 'ANDROID';
  static const String buildFlutter = 'FLUTTER';
  static const String buildWebToApk = 'WEBTOAPK';
  static const String buildCustom = 'CUSTOM';

  static final ValueNotifier<int> tabIndex = ValueNotifier<int>(homeTab);
  static final ValueNotifier<String> buildType = ValueNotifier<String>(buildAndroid);
}