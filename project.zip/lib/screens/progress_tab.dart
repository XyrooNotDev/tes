import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/build_controller.dart';
import '../services/error_log.dart';
import '../theme.dart';
import '../widgets/build_progress_view.dart';
import '../widgets/upload_progress_card.dart';

/// Tab Progress: detail penuh build yang berjalan (atau yang terakhir).
class ProgressTab extends StatelessWidget {
  const ProgressTab({super.key, required this.controller});

  final BuildController controller;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([controller, controller.upload]),
      builder: (context, _) {
        final has = controller.display != null;
        final uploading = controller.upload.visible;
        return RefreshIndicator(
          onRefresh: controller.reload,
          color: kRed,
          backgroundColor: kCard,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Progress Build', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                controller.isRunning
                    ? 'Build sedang berjalan • diperbarui otomatis'
                    : 'Detail build terakhir',
                style: const TextStyle(color: kMuted, fontSize: 12),
              ),
              const SizedBox(height: 16),
              const _ErrorReport(),
              UploadProgressCard(tracker: controller.upload),
              if (has)
                BuildProgressView(controller: controller, detailed: true)
              else if (!uploading)
                const Padding(
                  padding: EdgeInsets.only(top: 64),
                  child: Column(
                    children: [
                      Icon(Icons.timelapse, size: 56, color: kMuted),
                      SizedBox(height: 12),
                      Text('Belum ada build', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      SizedBox(height: 4),
                      Text(
                        'Mulai build dari tab Beranda, progress lengkapnya muncul di sini.',
                        style: TextStyle(color: kMuted, fontSize: 12),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}


/// Menampilkan error tampilan terakhir (kalau ada) supaya penyebab masalah bisa disalin.
class _ErrorReport extends StatelessWidget {
  const _ErrorReport();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: ErrorLog.last,
      builder: (context, text, _) {
        if (text == null || text.isEmpty) return const SizedBox.shrink();
        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: kRed.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: kRed.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                ErrorLog.autoDisabledService
                    ? 'Crash terdeteksi — mode latar belakang dimatikan otomatis'
                    : 'Laporan error terakhir',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
              ),
              const SizedBox(height: 6),
              Text(
                text,
                maxLines: 16,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 10, fontFamily: 'monospace'),
              ),
              Row(
                children: [
                  TextButton(
                    onPressed: () => Clipboard.setData(ClipboardData(text: text)),
                    child: const Text('Salin', style: TextStyle(fontSize: 12)),
                  ),
                  TextButton(
                    onPressed: ErrorLog.clear,
                    child: const Text('Tutup', style: TextStyle(color: kMuted, fontSize: 12)),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
