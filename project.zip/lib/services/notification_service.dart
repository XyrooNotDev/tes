import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

// === Channel ID (v2: channel lama tidak bisa diubah importance-nya, jadi dibuat ulang) ===
const String kProgressChannelId = 'build_progress_v2';
const String kDoneChannelId = 'build_done_v2';
const String kErrorChannelId = 'build_error_v2';
const String kUpdateChannelId = 'app_update_v2';

// === Notif ID ===
const int kProgressNotifId = 888;
const int kDoneNotifId = 889;
const int kErrorNotifId = 890;
const int kUpdateNotifId = 891;

// === Payload ===
const String kPayloadBuildTab = 'tab:build'; // membuka tab Progress
const String kPayloadUpdateTab = 'app:update';

const String _kIcon = '@drawable/ic_stat_build';

final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

class NotificationService {
  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  /// Dipanggil dari isolate UI (main).
  static Future<void> init({DidReceiveNotificationResponseCallback? onTap}) async {
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings(_kIcon),
    );

    await notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: onTap,
    );

    // Hapus channel versi lama.
    for (final old in const ['build_progress', 'build_done', 'build_error', 'app_update']) {
      try {
        await _android?.deleteNotificationChannel(old);
      } catch (_) {}
    }

    // Progress: heads-up saat pertama muncul, update berikutnya senyap.
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kProgressChannelId,
      'Progress Build',
      description: 'Progress build GitHub Actions yang sedang berjalan',
      importance: Importance.high,
      playSound: false,
      enableVibration: false,
      showBadge: false,
    ));

    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kDoneChannelId,
      'Build Selesai',
      description: 'Pemberitahuan saat build selesai atau gagal (muncul sebagai popup)',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    ));

    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kErrorChannelId,
      'Build Error',
      description: 'Pemberitahuan saat build gagal dimulai atau error (muncul sebagai popup)',
      importance: Importance.max,
      playSound: true,
      enableVibration: true,
    ));

    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kUpdateChannelId,
      'Update Aplikasi',
      description: 'Pemberitahuan jika ada versi baru Santanic Build',
      importance: Importance.high,
    ));

    await requestPermission();
  }

  /// Dipanggil dari isolate background service. Tidak meminta izin (butuh Activity).
  static Future<void> initBackground() async {
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings(_kIcon),
    );
    await notifications.initialize(initSettings);
  }

  static Future<void> requestPermission() async {
    await _android?.requestNotificationsPermission();
  }

  // ============================================
  // PROGRESS BUILD (ongoing)
  // ============================================
  static Future<void> showProgress({
    required String title,
    required String body,
    required int percent,
    required bool indeterminate,
  }) {
    return notifications.show(
      kProgressNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kProgressChannelId,
          'Progress Build',
          channelDescription: 'Progress build GitHub Actions yang sedang berjalan',
          importance: Importance.high,
          priority: Priority.high,
          ongoing: true,
          autoCancel: false,
          onlyAlertOnce: true,
          showProgress: true,
          maxProgress: 100,
          progress: percent,
          indeterminate: indeterminate,
          playSound: false,
          enableVibration: false,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          category: AndroidNotificationCategory.progress,
          visibility: NotificationVisibility.public,
          ticker: title,
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  /// Progress unduhan APK (memakai ID notif yang sama dengan notifikasi foreground service).
  static Future<void> showDownloadProgress({
    required String title,
    required int percent,
  }) {
    return showProgress(
      title: title,
      body: 'Mengunduh APK... $percent%',
      percent: percent,
      indeterminate: false,
    );
  }

  static Future<void> cancelProgress() => notifications.cancel(kProgressNotifId);

  // ============================================
  // BUILD SELESAI (sukses/gagal) - popup heads-up
  // ============================================
  static Future<void> showDone({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kDoneNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kDoneChannelId,
          'Build Selesai',
          channelDescription: 'Pemberitahuan saat build selesai atau gagal (muncul sebagai popup)',
          importance: Importance.max,
          priority: Priority.max,
          autoCancel: true,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          category: AndroidNotificationCategory.status,
          visibility: NotificationVisibility.public,
          ticker: title,
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  // ============================================
  // BUILD ERROR (gagal dimulai / timeout) - popup heads-up
  // ============================================
  static Future<void> showError({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kErrorNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kErrorChannelId,
          'Build Error',
          channelDescription: 'Pemberitahuan saat build gagal dimulai atau error (muncul sebagai popup)',
          importance: Importance.max,
          priority: Priority.max,
          autoCancel: true,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          category: AndroidNotificationCategory.error,
          visibility: NotificationVisibility.public,
          ticker: title,
          styleInformation: BigTextStyleInformation(body),
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  static Future<void> cancelError() => notifications.cancel(kErrorNotifId);

  // ============================================
  // UPDATE APLIKASI (versi baru)
  // ============================================
  static Future<void> showUpdateAvailable({
    required String title,
    required String body,
  }) {
    return notifications.show(
      kUpdateNotifId,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          kUpdateChannelId,
          'Update Aplikasi',
          channelDescription: 'Pemberitahuan jika ada versi baru Santanic Build',
          importance: Importance.high,
          priority: Priority.high,
          autoCancel: true,
          icon: _kIcon,
          color: Color(0xFF00E676),
          category: AndroidNotificationCategory.recommendation,
        ),
      ),
      payload: kPayloadUpdateTab,
    );
  }

  static Future<void> cancelUpdate() => notifications.cancel(kUpdateNotifId);

  // ============================================
  // CEK LAUNCH DARI NOTIFIKASI
  // ============================================
  static Future<bool> isLaunchedFromBuildNotif() async {
    final details = await notifications.getNotificationAppLaunchDetails();
    return (details?.didNotificationLaunchApp ?? false) &&
        details?.notificationResponse?.payload == kPayloadBuildTab;
  }

  static Future<bool> isLaunchedFromUpdateNotif() async {
    final details = await notifications.getNotificationAppLaunchDetails();
    return (details?.didNotificationLaunchApp ?? false) &&
        details?.notificationResponse?.payload == kPayloadUpdateTab;
  }
}
