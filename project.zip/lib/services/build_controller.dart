import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

import '../models/build_record.dart';
import 'build_store.dart';
import 'build_tracker.dart';
import 'github_actions.dart';
import 'session_manager.dart';

class BuildController extends ChangeNotifier {
  BuildController({required this.session});

  final SessionManager session;

  BuildRecord? current;
  List<BuildRecord> history = [];
  StreamSubscription<dynamic>? _sub;

  bool get isRunning => current != null && !current!.isFinished;

  /// Yang ditampilkan di kartu progress: build berjalan, kalau tidak ada maka build terakhir.
  BuildRecord? get display => current ?? (history.isEmpty ? null : history.first);

  Future<void> init() async {
    await reload();
    _sub = FlutterBackgroundService().on('update').listen((_) => reload());
  }

  Future<void> reload() async {
    current = await BuildStore.loadCurrent();
    history = await BuildStore.loadHistory();
    notifyListeners();
    // Service mati (misal dimatikan sistem) padahal build masih berjalan: lanjutkan pelacakan.
    if (isRunning) {
      try {
        if (!await FlutterBackgroundService().isRunning()) {
          await FlutterBackgroundService().startService();
        }
      } catch (_) {}
    }
  }

  Future<void> begin(BuildRecord rec) async {
    current = rec;
    await BuildStore.saveCurrent(rec);
    notifyListeners();
    await BuildTracker.start();
  }

  /// ✅ Method baru: Membatalkan build yang sedang berjalan.
  Future<void> cancelBuild() async {
    final rec = current;
    if (rec == null || rec.isFinished || rec.runId == null) return;

    try {
      // 1. Ambil token dari session (async karena menggunakan secure storage)
      final token = await session.getToken();
      if (token.isEmpty) {
        throw Exception('Token tidak ditemukan, silakan login ulang.');
      }

      // 2. Panggil API GitHub untuk membatalkan run
      final api = GitHubActions(token);
      await api.cancelRun(rec.owner, rec.repo, rec.runId!);

      // 3. Update status build di lokal
      final cancelled = rec.copyWith(
        status: 'cancelled',
        step: 'Dibatalkan oleh pengguna',
        finishedAt: DateTime.now().millisecondsSinceEpoch,
      );

      // 4. Pindahkan dari current ke history
      await BuildStore.appendHistory(cancelled);
      await BuildStore.clearCurrent();

      current = null;
      history = await BuildStore.loadHistory();
      notifyListeners();
    } catch (e) {
      // Jika gagal membatalkan, tetap update UI dengan pesan error
      debugPrint('Gagal membatalkan build: $e');
      rethrow; // Biarkan UI yang menangkap dan menampilkan SnackBar
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}