import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../services/workflow_resolver.dart';
import '../theme.dart';

/// Kartu pilihan workflow: upload .yml sendiri, atau otomatis pakai bawaan (assets).
class YmlPicker extends StatelessWidget {
  const YmlPicker({
    super.key,
    required this.path,
    required this.builtinName,
    required this.onChanged,
    this.enabled = true,
  });

  /// Path .yml pilihan pengguna; null = pakai bawaan.
  final String? path;

  /// Nama workflow bawaan yang dipakai kalau tidak upload.
  final String builtinName;
  final ValueChanged<String?> onChanged;
  final bool enabled;

  Future<void> _pick(BuildContext context) async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
    );
    if (res == null || res.files.isEmpty) return;
    final picked = res.files.first;
    final p = picked.path;
    if (p == null) return;

    final lower = picked.name.toLowerCase();
    if (!lower.endsWith('.yml') && !lower.endsWith('.yaml')) {
      if (context.mounted) _snack(context, 'Pilih file berekstensi .yml atau .yaml');
      return;
    }

    // Validasi langsung supaya salah file ketahuan sebelum build.
    try {
      await WorkflowResolver.resolve(
        customPath: p,
        assetPath: '',
        defaultName: builtinName,
      );
    } catch (e) {
      if (context.mounted) _snack(context, e.toString().replaceFirst('Exception: ', ''));
      return;
    }
    onChanged(p);
  }

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: kCard,
        behavior: SnackBarBehavior.floating,
      ));
  }

  @override
  Widget build(BuildContext context) {
    final custom = path != null;
    final name = custom ? path!.split('/').last : builtinName;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kInputBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: custom ? kGreen.withOpacity(0.6) : kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                custom ? Icons.description : Icons.auto_awesome,
                color: custom ? kGreen : kMuted,
                size: 22,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      custom ? 'Workflow kustom' : 'Otomatis (workflow bawaan)',
                      style: TextStyle(
                        color: custom ? kGreen : Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      name,
                      style: const TextStyle(color: kMuted, fontSize: 12),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: enabled ? () => _pick(context) : null,
                  icon: const Icon(Icons.upload_file, size: 18),
                  label: Text(custom ? 'Ganti .yml' : 'Upload .yml'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: kBorder),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
              if (custom) ...[
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'Pakai bawaan',
                  onPressed: enabled ? () => onChanged(null) : null,
                  icon: const Icon(Icons.close, color: kRed),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Text(
            custom
                ? 'File .yml ini diunggah ke .github/workflows/ dan dijalankan. Wajib punya trigger workflow_dispatch.'
                : 'Tanpa upload, aplikasi memakai workflow bawaan dari assets secara otomatis.',
            style: const TextStyle(fontSize: 11, color: kMuted),
          ),
        ],
      ),
    );
  }
}
