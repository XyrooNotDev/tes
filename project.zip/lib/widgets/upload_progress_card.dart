import 'package:flutter/material.dart';

import '../services/upload_tracker.dart';
import '../theme.dart';

/// Kartu progress UPLOAD (terpisah dari kartu progress build).
class UploadProgressCard extends StatelessWidget {
  const UploadProgressCard({super.key, required this.tracker});

  final UploadTracker tracker;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: tracker,
      builder: (context, _) {
        if (!tracker.visible) return const SizedBox.shrink();

        final failed = tracker.error != null;
        final color = failed ? kRed : (tracker.done ? kGreen : const Color(0xFF42A5F5));
        final pct = (tracker.overall * 100).round();

        return Card(
          color: kCard,
          margin: const EdgeInsets.only(bottom: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: color.withOpacity(0.5)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      failed
                          ? Icons.error_outline
                          : (tracker.done ? Icons.cloud_done : Icons.cloud_upload),
                      color: color,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            failed
                                ? 'Upload gagal'
                                : (tracker.done ? 'Upload selesai' : 'Mengunggah ke GitHub'),
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
                          ),
                          if (tracker.title.isNotEmpty)
                            Text(
                              tracker.title,
                              style: const TextStyle(color: kMuted, fontSize: 11),
                              overflow: TextOverflow.ellipsis,
                            ),
                        ],
                      ),
                    ),
                    if (!failed)
                      Text('$pct%',
                          style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
                    if (failed || tracker.done)
                      IconButton(
                        tooltip: 'Tutup',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.close, size: 18, color: kMuted),
                        onPressed: tracker.dismiss,
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: failed ? null : tracker.overall,
                  color: color,
                  backgroundColor: kBorder,
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(3),
                ),
                const SizedBox(height: 12),
                for (var i = 0; i < tracker.steps.length; i++) _stepRow(i),
                if (failed) ...[
                  const SizedBox(height: 8),
                  Text(
                    tracker.error!,
                    style: const TextStyle(color: kRed, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _stepRow(int i) {
    final failed = tracker.error != null;
    final isDone = tracker.done || i < tracker.current;
    final isActive = !tracker.done && i == tracker.current;

    Widget icon;
    if (isDone) {
      icon = const Icon(Icons.check_circle, color: kGreen, size: 18);
    } else if (isActive && failed) {
      icon = const Icon(Icons.cancel, color: kRed, size: 18);
    } else if (isActive) {
      icon = const SizedBox(
        width: 16,
        height: 16,
        child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF42A5F5)),
      );
    } else {
      icon = const Icon(Icons.radio_button_unchecked, color: kMuted, size: 18);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 20, child: Center(child: icon)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              tracker.steps[i],
              style: TextStyle(
                color: isActive ? Colors.white : (isDone ? Colors.white70 : kMuted),
                fontSize: 12,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ),
          if (isActive && !failed && tracker.detail.isNotEmpty)
            Flexible(
              child: Text(
                tracker.detail,
                style: const TextStyle(color: kMuted, fontSize: 11),
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.end,
              ),
            ),
        ],
      ),
    );
  }
}
