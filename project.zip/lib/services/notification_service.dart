import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

const String kProgressChannelId = 'build_progress';
const String kDoneChannelId = 'build_done';
const int kProgressNotifId = 888;
const int kDoneNotifId = 889;

/// Payload notifikasi: saat diketuk, app langsung membuka tab Build.
const String kPayloadBuildTab = 'tab:build';

const String _kIcon = '@drawable/ic_stat_build';

final FlutterLocalNotificationsPlugin notifications = FlutterLocalNotificationsPlugin();

class NotificationService {
  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      notifications.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  /// Inisialisasi plugin, channel, dan minta izin (Android 13+)
  static Future<void> init({DidReceiveNotificationResponseCallback? onTap}) async {
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings(_kIcon),
    );

    await notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: onTap,
    );

    // Buat Channel Progress
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kProgressChannelId,
      'Progress Build',
      description: 'Progress build GitHub Actions yang sedang berjalan',
      importance: Importance.high,
      playSound: false,
      enableVibration: false,
      showBadge: false,
    ));

    // Buat Channel Selesai
    await _android?.createNotificationChannel(const AndroidNotificationChannel(
      kDoneChannelId,
      'Build Selesai',
      description: 'Pemberitahuan saat build selesai atau gagal',
      importance: Importance.high,
    ));

    // Minta izin notifikasi (WAJIB untuk Android 13+ / API 33+)
    await requestPermission();
  }

  static Future<void> requestPermission() async {
    // Android 13+ (API 33)
    await _android?.requestNotificationsPermission();
    
  }

  /// Menampilkan notifikasi progress build (ongoing, tidak bisa di-swipe)
  static Future<void> showProgress({
    required String title,
    required String body,
    required int percent,
    required bool indeterminate,
  }) {
    return notifications.show(
      kProgressNotifId,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails(
          kProgressChannelId,
          'Progress Build',
          channelDescription: 'Progress build GitHub Actions yang sedang berjalan',
          importance: Importance.high,
          priority: Priority.high,
          ongoing: true,          // Tidak bisa di-swipe
          autoCancel: false,      // Tidak hilang saat diketuk
          onlyAlertOnce: true,    // Hanya bunyi/getar sekali di awal
          showProgress: true,
          maxProgress: 100,
          progress: percent,
          indeterminate: indeterminate, // True jika percent == 0
          playSound: false,
          enableVibration: false,
          icon: _kIcon,
          color: const Color(0xFFFF0000),
          // Kategori service agar tidak dibunuh sistem saat Doze Mode
          category: AndroidNotificationCategory.service, 
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  static Future<void> cancelProgress() => notifications.cancel(kProgressNotifId);

  /// Notifikasi saat build selesai (sukses/gagal)
  static Future<void> showDone({required String title, required String body}) {
    return notifications.show(
      kDoneNotifId,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          kDoneChannelId,
          'Build Selesai',
          channelDescription: 'Pemberitahuan saat build selesai atau gagal',
          importance: Importance.high,
          priority: Priority.high,
          autoCancel: true,       // Hilang saat diketuk
          icon: _kIcon,
          color: Color(0xFFFF0000),
          category: AndroidNotificationCategory.status,
        ),
      ),
      payload: kPayloadBuildTab,
    );
  }

  static Future<bool> isLaunchedFromBuildNotif() async {
    final details = await notifications.getNotificationAppLaunchDetails();
    return (details?.didNotificationLaunchApp ?? false) &&
        details?.notificationResponse?.payload == kPayloadBuildTab;
  }
}