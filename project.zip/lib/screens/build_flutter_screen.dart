import 'package:flutter/material.dart';

import '../nav.dart';
import '../services/build_controller.dart';
import '../services/session_manager.dart';
import 'build_zip_screen.dart';

class BuildFlutterScreen extends StatelessWidget {
  const BuildFlutterScreen({super.key, required this.session, required this.controller});
  final SessionManager session;
  final BuildController controller;

  @override
  Widget build(BuildContext context) {
    return BuildZipScreen(
      session: session,
      controller: controller,
      title: 'Build Flutter',
      typeKey: AppNav.buildFlutter,
      label: 'Flutter',
      assetPath: 'assets/workflows/build_flutter.yml',
      defaultWorkflowName: 'build_flutter.yml',
    );
  }
}
