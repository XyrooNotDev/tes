import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/build_record.dart';
import 'artifact_service.dart';
import 'build_store.dart';
import 'github_actions.dart';
import 'notification_service.dart';
import 'session_manager.dart';

/// Pemanggil 'update' ke UI. Di service = `service.invoke`, di dalam app = reload langsung.
typedef TrackerInvoke = void Function(String method, Map<String, dynamic>? args);

class BuildTracker {
  static const String _kUseService = 'use_bg_service';

  /// true = pelacak berjalan di foreground service (tetap jalan saat app ditutup).
  /// false = mode aman: pelacak berjalan di dalam aplikasi (tanpa service).
  static Future<bool> serviceEnabled() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.reload();
      return p.getBool(_kUseService) ?? true;
    } catch (_) {
      return true;
    }
  }

  static Future<void> setServiceEnabled(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_kUseService, value);
  }

  static Future<void> configure() async {
    await FlutterBackgroundService().configure(
      androidConfiguration: AndroidConfiguration(
        onStart: onBuildServiceStart,
        autoStart: false,
        autoStartOnBoot: false, // Android 15 melarang FGS dataSync dimulai dari BOOT_COMPLETED
        isForegroundMode: true,
        notificationChannelId: kProgressChannelId,
        initialNotificationTitle: 'Santanic Build',
        initialNotificationContent: 'Menyiapkan build...',
        foregroundServiceNotificationId: kProgressNotifId,
      ),
      iosConfiguration: IosConfiguration(autoStart: false),
    );
  }

  /// Memulai service bila belum jalan. Service yang sudah berjalan otomatis mengambil
  /// build baru pada siklus berikutnya (tidak perlu restart).
  static Future<void> start() async {
    final service = FlutterBackgroundService();
    if (await service.isRunning()) return;
    await service.startService();
  }
}

@pragma('vm:entry-point')
Future<void> onBuildServiceStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  bool stopped = false;
  service.on('stop').listen((_) {
    stopped = true;
  });

  try {
    await trackBuild(
      invoke: (m, a) => service.invoke(m, a),
      stopped: () => stopped,
      background: true,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Fatal error: $e');
  } finally {
    try {
      service.stopSelf();
    } catch (_) {}
  }
}

/// Menyimpan riwayat secara berurutan (hindari tulis bersamaan dari callback progress).
class _Persister {
  Future<void> _chain = Future<void>.value();

  void queue(BuildRecord r) {
    _chain = _chain.then((_) => BuildStore.appendHistory(r)).catchError((_) {});
  }

  Future<void> flush() => _chain;
}

class _RecState {
  _RecState(this.rec);

  BuildRecord rec;
  int emptyRunRetries = 0;
  int errors = 0;
  int polls = 0;
  bool finishing = false;
}

/// Inti pelacakan: memantau SEMUA build aktif (maks 3 sekaligus) dalam satu loop.
/// [background] = berjalan di isolate service (perlu init notifikasi sendiri).
Future<void> trackBuild({
  required TrackerInvoke invoke,
  required bool Function() stopped,
  required bool background,
}) async {
  if (background) {
    try {
      await NotificationService.initBackground();
    } catch (e) {
      debugPrint('[BuildTracker] initBackground gagal: $e');
    }
  }

  final prefs = await SharedPreferences.getInstance();
  await prefs.reload();
  final token = prefs.getString(SessionManager.kToken) ?? '';
  if (token.isEmpty) {
    debugPrint('[BuildTracker] Token kosong');
    return;
  }

  final api = GitHubActions(token);
  final states = <String, _RecState>{};
  var pendingFinish = 0;
  var idleRounds = 0;
  const maxEmptyRetries = 50;
  const maxConsecutiveErrors = 20;

  void startFinish(_RecState st, BuildRecord rec, {String? errorMessage}) {
    st.finishing = true;
    pendingFinish++;
    unawaited(() async {
      try {
        await _finish(invoke, rec, token);
        if (errorMessage != null) await _notifyError(rec, errorMessage);
      } catch (e) {
        debugPrint('[BuildTracker] finish error: $e');
      } finally {
        pendingFinish--;
      }
    }());
  }

  debugPrint('[BuildTracker] Mulai tracking');

  while (!stopped()) {
    final stored = await BuildStore.loadActive();
    final live = stored.where((r) => !r.isFinished).toList();
    final liveIds = live.map((e) => e.id).toSet();

    states.removeWhere((id, st) => !liveIds.contains(id) && !st.finishing);
    for (final r in live) {
      final st = states.putIfAbsent(r.id, () => _RecState(r));
      if (!st.finishing) st.rec = r;
    }

    if (live.isEmpty && pendingFinish == 0) {
      idleRounds++;
      if (idleRounds >= 2) break;
    } else {
      idleRounds = 0;
    }

    for (final st in states.values.toList()) {
      if (st.finishing) continue;
      var rec = st.rec;

      final deadline = DateTime.fromMillisecondsSinceEpoch(rec.startedAt)
          .add(const Duration(minutes: 60));
      if (DateTime.now().isAfter(deadline)) {
        final t = rec.copyWith(
          status: 'failure',
          step: 'Melewati batas waktu pelacakan (Timeout 60 menit)',
        );
        st.rec = t;
        startFinish(st, t, errorMessage: 'Build timeout setelah 60 menit');
        continue;
      }

      try {
        if (rec.runId == null) {
          final run = await api.findRun(rec.owner, rec.repo, rec.workflow, rec.baselineRunId);
          if (run != null) {
            rec = rec.copyWith(runId: run.id, url: run.htmlUrl);
            st.emptyRunRetries = 0;
          } else {
            st.emptyRunRetries++;
            if (st.emptyRunRetries >= maxEmptyRetries) {
              final failed = rec.copyWith(
                status: 'failure',
                step: 'Gagal menemukan workflow run di GitHub',
              );
              st.rec = failed;
              startFinish(st, failed,
                  errorMessage: 'Workflow run tidak ditemukan setelah 5 menit');
              continue;
            }
          }
        }

        final runId = rec.runId;
        if (runId != null) {
          final p = await api.progress(rec.owner, rec.repo, runId);
          final newStatus = p.finished
              ? p.finalStatus
              : (p.status == 'queued' ? 'queued' : 'running');

          // Persen tidak pernah turun (jumlah step bertambah seiring job dimulai).
          var newPercent = rec.percent;
          if (p.finished) {
            newPercent = p.finalStatus == 'success' ? 100 : rec.percent;
          } else if (p.percent > newPercent) {
            newPercent = p.percent;
          }

          // Log berjalan: ambil tiap ~3 polling supaya hemat kuota API.
          var logTail = rec.logTail;
          if (!p.finished && st.polls % 3 == 0) {
            final jobId = p.runningJobId;
            if (jobId != null) {
              final t = await api.jobLogTail(rec.owner, rec.repo, jobId);
              if (t.isNotEmpty) logTail = _cap(t);
            }
          }
          if (p.finished && p.finalStatus != 'success') {
            final jobId = p.failedJobId ?? p.runningJobId;
            if (jobId != null) {
              final t = await api.jobLogTail(rec.owner, rec.repo, jobId);
              if (t.isNotEmpty) logTail = _cap(t);
            }
          }

          rec = rec.copyWith(
            status: newStatus,
            percent: newPercent,
            step: p.stepLabel,
            url: p.htmlUrl,
            diagnostics: p.diagnostics,
            jobs: p.jobs,
            runNumber: p.runNumber,
            branch: p.branch,
            sha: p.sha,
            actor: p.actor,
            logTail: logTail,
          );

          if (p.finished) {
            st.rec = rec;
            startFinish(st, rec);
            continue;
          }
        }

        st.rec = rec;
        await BuildStore.updateActiveIfPresent(rec);
        invoke('update', {'id': rec.id});
        st.errors = 0;
      } catch (e) {
        st.errors++;
        debugPrint('[BuildTracker] Polling error ${rec.repo} (${st.errors}/$maxConsecutiveErrors): $e');
        if (st.errors >= maxConsecutiveErrors) {
          final failed = rec.copyWith(
            status: 'failure',
            step: 'Koneksi ke GitHub terputus. Build dihentikan.',
          );
          st.rec = failed;
          startFinish(st, failed, errorMessage: 'Koneksi ke GitHub terputus selama 2 menit');
        }
      }
      st.polls++;
    }

    final liveRecs = states.values.where((s) => !s.finishing).map((s) => s.rec).toList();
    if (liveRecs.isNotEmpty) await _publishAll(liveRecs);

    await Future<void>.delayed(const Duration(seconds: 6));
  }

  debugPrint('[BuildTracker] Selesai / dihentikan');
}

String _cap(String s, [int max = 4000]) =>
    s.length <= max ? s : s.substring(s.length - max);

Future<void> _notifyError(BuildRecord rec, String message) async {
  try {
    await NotificationService.showError(
      title: 'Build Gagal ❌',
      body: '${rec.typeLabel} • ${rec.repo}: $message',
      buildKey: rec.id,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal kirim notifikasi error: $e');
  }
}

/// Satu notifikasi progress untuk semua build yang berjalan.
Future<void> _publishAll(List<BuildRecord> recs) async {
  try {
    if (recs.length == 1) {
      final rec = recs.first;
      await NotificationService.showProgress(
        title: 'Build ${rec.typeLabel} • ${rec.repo}',
        body:
            '${rec.step.isEmpty ? 'Menunggu runner GitHub...' : rec.step}\n${rec.percent}% • ${_fmt(rec.elapsedMs)}',
        percent: rec.percent,
        indeterminate: rec.percent == 0,
      );
      return;
    }
    final avg = recs.fold<int>(0, (a, r) => a + r.percent) ~/ recs.length;
    final lines = recs.map((r) => '• ${r.typeLabel} ${r.repo}: ${r.percent}%').join('\n');
    await NotificationService.showProgress(
      title: '${recs.length} build berjalan',
      body: lines,
      percent: avg,
      indeterminate: avg == 0,
    );
  } catch (e) {
    debugPrint('[BuildTracker] Gagal update notifikasi progress: $e');
  }
}

String _fmt(int ms) {
  final s = ms ~/ 1000;
  final m = s ~/ 60;
  final sec = s % 60;
  return m > 0 ? '${m}m ${sec}s' : '${sec}s';
}

Future<void> _cancelProgressIfIdle() async {
  try {
    final a = await BuildStore.loadActive();
    if (a.where((r) => !r.isFinished).isEmpty) {
      await NotificationService.cancelProgress();
    }
  } catch (_) {}
}

Future<void> _finish(TrackerInvoke invoke, BuildRecord rec, String token) async {
  try {
    var done = rec.copyWith(
      finishedAt: DateTime.now().millisecondsSinceEpoch,
      percent: rec.isSuccess ? 100 : rec.percent,
    );

    if (done.isSuccess && done.runId != null) {
      done = done.copyWith(
        step: 'Build selesai. Mengunduh APK...',
        downloadState: 'downloading',
        downloadPercent: 0,
        downloadError: '',
      );
    }

    debugPrint('[BuildTracker] Build selesai: ${done.status} (${done.percent}%)');

    await BuildStore.appendHistory(done);
    await BuildStore.removeActive(done.id);
    invoke('update', {'id': done.id});

    // Popup hasil build (heads-up).
    try {
      await NotificationService.showDone(
        buildKey: done.id,
        title: done.isSuccess
            ? 'Build selesai ✅'
            : (done.status == 'cancelled' ? 'Build dibatalkan' : 'Build gagal ❌'),
        body: done.isSuccess
            ? '${done.typeLabel} • ${done.repo} berhasil dibuild. Mengunduh APK...'
            : '${done.typeLabel} • ${done.repo} ${done.statusLabel.toLowerCase()}. Ketuk untuk melihat detail.',
      );
    } catch (e) {
      debugPrint('[BuildTracker] Gagal kirim notifikasi done: $e');
    }

    if (!(done.isSuccess && done.runId != null)) {
      await _cancelProgressIfIdle();
      return;
    }

    final persister = _Persister();
    var lastPct = -10;
    try {
      final path = await ArtifactService(token).downloadApk(
        rec: done,
        onProgress: (f) {
          final pct = (f * 100).floor().clamp(0, 100);
          if (pct >= lastPct + 5) {
            lastPct = pct;
            NotificationService.showDownloadProgress(
              title: 'Unduh APK • ${done.repo}',
              percent: pct,
            ).catchError((_) {});
            persister.queue(done.copyWith(downloadPercent: pct));
            invoke('update', {'id': done.id});
          }
        },
      );
      await persister.flush();
      done = done.copyWith(
        step: 'Build selesai. APK siap diinstal.',
        apkPath: path,
        downloadState: 'done',
        downloadPercent: 100,
        downloadError: '',
      );
      await BuildStore.appendHistory(done);
      await _cancelProgressIfIdle();
      try {
        await NotificationService.showDone(
          buildKey: '${done.id}_apk',
          title: 'APK siap diinstal ✅',
          body: '${done.typeLabel} • ${done.repo}. Ketuk lalu tekan Install APK.',
        );
      } catch (_) {}
    } catch (e) {
      await persister.flush();
      final msg = e.toString().replaceFirst('Exception: ', '');
      debugPrint('[BuildTracker] Unduh APK gagal: $msg');
      done = done.copyWith(
        step: 'Build selesai, tapi unduh APK gagal.',
        downloadState: 'failed',
        downloadError: msg,
      );
      await BuildStore.appendHistory(done);
      await _cancelProgressIfIdle();
      try {
        await NotificationService.showError(
          buildKey: '${done.id}_dl',
          title: 'Unduh APK gagal',
          body: '${done.typeLabel} • ${done.repo}: $msg. Buka tab Progress untuk unduh ulang.',
        );
      } catch (_) {}
    }

    invoke('update', {'id': done.id});
  } catch (e) {
    debugPrint('[BuildTracker] Gagal finish: $e');
  }
}
