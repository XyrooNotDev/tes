import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/project_analyzer.dart';
import '../theme.dart';
import '../services/session_manager.dart';
import '../services/build_controller.dart';
import 'build_flutter_screen.dart';
import 'build_android_screen.dart';

class _Finding {
  const _Finding(this.sev, this.title, this.detail, this.file, this.line);

  final String sev; // error | warning | info
  final String title;
  final String detail;
  final String? file;
  final int? line;

  factory _Finding.from(Map<dynamic, dynamic> m) => _Finding(
        m['sev']?.toString() ?? 'info',
        m['title']?.toString() ?? '',
        m['detail']?.toString() ?? '',
        m['file']?.toString(),
        m['line'] is int ? m['line'] as int : null,
      );

  int get rank => sev == 'error' ? 0 : (sev == 'warning' ? 1 : 2);
  String get location => file == null ? '' : (line == null ? file! : '$file:$line');
}

/// Analyzer Project: periksa ZIP project sebelum dibuild untuk mencari penyebab error umum.
class ProjectAnalyzerScreen extends StatefulWidget {
  const ProjectAnalyzerScreen({super.key, required this.session, required this.controller});

  final SessionManager session;
  final BuildController controller;

  @override
  State<ProjectAnalyzerScreen> createState() => _ProjectAnalyzerScreenState();
}

class _ProjectAnalyzerScreenState extends State<ProjectAnalyzerScreen> {
  String? _zipPath;
  bool _busy = false;
  String? _error;
  List<_Finding>? _findings;

  Future<void> _pick() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    if (res == null || res.files.isEmpty) return;
    setState(() {
      _zipPath = res.files.first.path;
      _findings = null;
      _error = null;
    });
  }

  Future<void> _analyze() async {
    final path = _zipPath;
    if (path == null) return;
    setState(() {
      _busy = true;
      _error = null;
      _findings = null;
    });
    try {
      final raw = await runAnalyzerInIsolate(path);
      final list = raw.whereType<Map>().map((m) => _Finding.from(m)).toList()
        ..sort((a, b) => a.rank.compareTo(b.rank));
      if (mounted) setState(() => _findings = list);
    } catch (e) {
      if (mounted) setState(() => _error = 'Analisis gagal: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _continueToWorkflowBuild() async {
    final path = _zipPath;
    if (path == null) return;
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Pilih workflow build'),
        content: const Text('Analisis selesai. Pilih workflow GitHub Actions untuk membangun APK dari ZIP ini.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'android'), child: const Text('Android Studio')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'flutter'), child: const Text('Flutter')),
        ],
      ),
    );
    if (!mounted || choice == null) return;
    final screen = choice == 'android'
        ? BuildAndroidScreen(session: widget.session, controller: widget.controller, initialZipPath: path)
        : BuildFlutterScreen(session: widget.session, controller: widget.controller, initialZipPath: path);
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  String _report() {
    final f = _findings ?? const <_Finding>[];
    final b = StringBuffer('LAPORAN ANALYZER — ${_zipPath?.split('/').last}\n\n');
    for (final x in f) {
      b.writeln('[${x.sev.toUpperCase()}] ${x.title}');
      if (x.location.isNotEmpty) b.writeln('  ${x.location}');
      b.writeln('  ${x.detail}\n');
    }
    return b.toString();
  }

  Color _color(String sev) => sev == 'error' ? kRed : (sev == 'warning' ? const Color(0xFFFFC107) : const Color(0xFF42A5F5));
  IconData _icon(String sev) =>
      sev == 'error' ? Icons.error : (sev == 'warning' ? Icons.warning_amber_rounded : Icons.info_outline);

  @override
  Widget build(BuildContext context) {
    final f = _findings;
    final errors = f?.where((e) => e.sev == 'error').length ?? 0;
    final warns = f?.where((e) => e.sev == 'warning').length ?? 0;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        title: const Text('Analyzer Project'),
        backgroundColor: kBg,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          if (f != null)
            IconButton(
              tooltip: 'Salin laporan',
              icon: const Icon(Icons.copy),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: _report()));
                if (context.mounted) {
                  ScaffoldMessenger.of(context)
                    ..hideCurrentSnackBar()
                    ..showSnackBar(const SnackBar(content: Text('Laporan disalin')));
                }
              },
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Periksa ZIP project sebelum build. Setelah lolos pemeriksaan, lanjutkan ke GitHub Actions Workflows '
            'untuk membangun APK. Pemeriksaan lokal tidak mengubah file project.',
            style: TextStyle(color: kMuted, fontSize: 12),
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: _busy ? null : _pick,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: kInputBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                children: [
                  Icon(Icons.folder_zip_outlined, size: 38, color: _zipPath != null ? kRed : kMuted),
                  const SizedBox(height: 10),
                  Text(
                    _zipPath != null ? _zipPath!.split('/').last : 'Pilih ZIP project',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: _zipPath != null ? Colors.white : kMuted, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), backgroundColor: kRed),
            onPressed: (_busy || _zipPath == null) ? null : _analyze,
            icon: _busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.fact_check_outlined),
            label: Text(_busy ? 'Menganalisis...' : 'Analisis Project'),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: kRed, fontSize: 12)),
          ],
          if (f != null) ...[
            const SizedBox(height: 20),
            Row(
              children: [
                _chip('Error', errors, kRed),
                const SizedBox(width: 8),
                _chip('Peringatan', warns, const Color(0xFFFFC107)),
                const SizedBox(width: 8),
                _chip('Info', f.length - errors - warns, const Color(0xFF42A5F5)),
              ],
            ),
            const SizedBox(height: 12),
            for (final x in f) _card(x),
            const SizedBox(height: 8),
            FilledButton.icon(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52), backgroundColor: kGreen, foregroundColor: Colors.black),
              onPressed: errors > 0 ? null : _continueToWorkflowBuild,
              icon: const Icon(Icons.rocket_launch),
              label: const Text('Lanjut Build via GitHub Actions Workflows'),
            ),
            if (errors > 0)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('Perbaiki temuan error terlebih dahulu sebelum melanjutkan build.', style: TextStyle(color: kRed, fontSize: 11)),
              ),
          ],
        ],
      ),
    );
  }

  Widget _chip(String label, int n, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: c.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
        child: Text('$label $n', style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 12)),
      );

  Widget _card(_Finding x) {
    final c = _color(x.sev);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: c.withOpacity(0.45)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(_icon(x.sev), color: c, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(x.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                if (x.location.isNotEmpty) ...[
                  const SizedBox(height: 3),
                  Text(x.location, style: TextStyle(color: c, fontSize: 11, fontFamily: 'monospace')),
                ],
                const SizedBox(height: 4),
                Text(x.detail, style: const TextStyle(color: kMuted, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
